--
-- PostgreSQL database dump
--

\restrict h5a6lqTPO6VljiuTpIfJ0IkMjwm9nEXnk5CYNCNCgV56eVdqDDnz3CczCbSEqnw

-- Dumped from database version 16.14
-- Dumped by pg_dump version 16.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Achievements; Type: TABLE; Schema: public; Owner: game_app
--

CREATE TABLE public."Achievements" (
    "Id" uuid NOT NULL,
    "AchievementKey" text NOT NULL,
    "Title" text NOT NULL,
    "Description" text NOT NULL,
    "Category" text NOT NULL,
    "Icon" text NOT NULL,
    "MaxProgress" integer NOT NULL,
    "RewardsJson" text NOT NULL,
    "Order" integer NOT NULL
);


ALTER TABLE public."Achievements" OWNER TO game_app;

--
-- Name: Announcements; Type: TABLE; Schema: public; Owner: game_app
--

CREATE TABLE public."Announcements" (
    "Id" uuid NOT NULL,
    "Title" text NOT NULL,
    "Content" text NOT NULL,
    "Type" text NOT NULL,
    "Priority" integer NOT NULL,
    "IsActive" boolean NOT NULL,
    "Channel" text NOT NULL,
    "Region" text NOT NULL,
    "MinVersion" text,
    "MaxVersion" text,
    "StartAt" timestamp with time zone NOT NULL,
    "EndAt" timestamp with time zone,
    "CreatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."Announcements" OWNER TO game_app;

--
-- Name: ClientVersions; Type: TABLE; Schema: public; Owner: game_app
--

CREATE TABLE public."ClientVersions" (
    "Id" uuid NOT NULL,
    "Version" text NOT NULL,
    "Channel" text NOT NULL,
    "Platform" text NOT NULL,
    "DownloadUrl" text NOT NULL,
    "Checksum" text NOT NULL,
    "SizeBytes" bigint NOT NULL,
    "IsMandatory" boolean NOT NULL,
    "IsActive" boolean NOT NULL,
    "MinOsVersion" text,
    "ReleaseNotes" text,
    "CreatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."ClientVersions" OWNER TO game_app;

--
-- Name: FriendRelations; Type: TABLE; Schema: public; Owner: game_app
--

CREATE TABLE public."FriendRelations" (
    "Id" uuid NOT NULL,
    "PlayerId" uuid NOT NULL,
    "FriendId" uuid NOT NULL,
    "Alias" text NOT NULL,
    "CreatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."FriendRelations" OWNER TO game_app;

--
-- Name: FriendRequests; Type: TABLE; Schema: public; Owner: game_app
--

CREATE TABLE public."FriendRequests" (
    "Id" uuid NOT NULL,
    "SenderId" uuid NOT NULL,
    "ReceiverId" uuid NOT NULL,
    "Status" text NOT NULL,
    "CreatedAt" timestamp with time zone NOT NULL,
    "RespondedAt" timestamp with time zone
);


ALTER TABLE public."FriendRequests" OWNER TO game_app;

--
-- Name: GameEvents; Type: TABLE; Schema: public; Owner: game_app
--

CREATE TABLE public."GameEvents" (
    "Id" uuid NOT NULL,
    "EventKey" text NOT NULL,
    "Title" text NOT NULL,
    "Description" text NOT NULL,
    "Type" text NOT NULL,
    "Status" text NOT NULL,
    "RewardsJson" text NOT NULL,
    "StartAt" timestamp with time zone NOT NULL,
    "EndAt" timestamp with time zone,
    "CreatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."GameEvents" OWNER TO game_app;

--
-- Name: MailAttachments; Type: TABLE; Schema: public; Owner: game_app
--

CREATE TABLE public."MailAttachments" (
    "Id" uuid NOT NULL,
    "MailId" uuid NOT NULL,
    "ItemId" text NOT NULL,
    "Quantity" bigint NOT NULL,
    "IsClaimed" boolean NOT NULL,
    "ClaimedAt" timestamp with time zone
);


ALTER TABLE public."MailAttachments" OWNER TO game_app;

--
-- Name: Mails; Type: TABLE; Schema: public; Owner: game_app
--

CREATE TABLE public."Mails" (
    "Id" uuid NOT NULL,
    "ReceiverId" uuid,
    "MailType" text NOT NULL,
    "Title" text NOT NULL,
    "Content" text NOT NULL,
    "AttachmentJson" text NOT NULL,
    "IsRead" boolean NOT NULL,
    "IsDeleted" boolean NOT NULL,
    "ExpiresAt" timestamp with time zone,
    "CreatedAt" timestamp with time zone NOT NULL,
    "ReadAt" timestamp with time zone
);


ALTER TABLE public."Mails" OWNER TO game_app;

--
-- Name: PlayerAchievements; Type: TABLE; Schema: public; Owner: game_app
--

CREATE TABLE public."PlayerAchievements" (
    "Id" uuid NOT NULL,
    "PlayerId" uuid NOT NULL,
    "AchievementId" uuid NOT NULL,
    "Progress" integer NOT NULL,
    "IsUnlocked" boolean NOT NULL,
    "UnlockedAt" timestamp with time zone
);


ALTER TABLE public."PlayerAchievements" OWNER TO game_app;

--
-- Name: PlayerEventProgresses; Type: TABLE; Schema: public; Owner: game_app
--

CREATE TABLE public."PlayerEventProgresses" (
    "Id" uuid NOT NULL,
    "PlayerId" uuid NOT NULL,
    "EventId" uuid NOT NULL,
    "Progress" integer NOT NULL,
    "Target" integer NOT NULL,
    "IsCompleted" boolean NOT NULL,
    "IsRewarded" boolean NOT NULL,
    "UpdatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."PlayerEventProgresses" OWNER TO game_app;

--
-- Name: PlayerMatchHistories; Type: TABLE; Schema: public; Owner: game_app
--

CREATE TABLE public."PlayerMatchHistories" (
    "Id" uuid NOT NULL,
    "PlayerId" uuid NOT NULL,
    "SessionId" uuid NOT NULL,
    "Mode" text NOT NULL,
    "MapId" text NOT NULL,
    "Team" text,
    "Result" text NOT NULL,
    "Kills" integer NOT NULL,
    "Deaths" integer NOT NULL,
    "Assists" integer NOT NULL,
    "Score" integer NOT NULL,
    "DurationSeconds" integer NOT NULL,
    "PlayedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."PlayerMatchHistories" OWNER TO game_app;

--
-- Name: PlayerRankings; Type: TABLE; Schema: public; Owner: game_app
--

CREATE TABLE public."PlayerRankings" (
    "Id" uuid NOT NULL,
    "PlayerId" uuid NOT NULL,
    "Mode" text NOT NULL,
    "Rank" integer NOT NULL,
    "Rating" integer NOT NULL,
    "TotalMatches" integer NOT NULL,
    "Wins" integer NOT NULL,
    "Losses" integer NOT NULL,
    "Draws" integer NOT NULL,
    "WinStreak" integer NOT NULL,
    "MaxWinStreak" integer NOT NULL,
    "UpdatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."PlayerRankings" OWNER TO game_app;

--
-- Name: Reports; Type: TABLE; Schema: public; Owner: game_app
--

CREATE TABLE public."Reports" (
    "Id" uuid NOT NULL,
    "ReporterId" uuid NOT NULL,
    "ReportedPlayerId" uuid,
    "ReportType" text NOT NULL,
    "Content" text NOT NULL,
    "EvidenceJson" text NOT NULL,
    "Status" text NOT NULL,
    "HandledBy" uuid,
    "HandleNote" text,
    "CreatedAt" timestamp with time zone NOT NULL,
    "HandledAt" timestamp with time zone
);


ALTER TABLE public."Reports" OWNER TO game_app;

--
-- Name: SupportTickets; Type: TABLE; Schema: public; Owner: game_app
--

CREATE TABLE public."SupportTickets" (
    "Id" uuid NOT NULL,
    "PlayerId" uuid,
    "TicketType" text NOT NULL,
    "Subject" text NOT NULL,
    "Content" text NOT NULL,
    "Status" text NOT NULL,
    "Priority" text NOT NULL,
    "AssignedTo" uuid,
    "InternalNote" text,
    "CreatedAt" timestamp with time zone NOT NULL,
    "UpdatedAt" timestamp with time zone,
    "ResolvedAt" timestamp with time zone,
    "AssignedAdminId" uuid
);


ALTER TABLE public."SupportTickets" OWNER TO game_app;

--
-- Name: TicketReplies; Type: TABLE; Schema: public; Owner: game_app
--

CREATE TABLE public."TicketReplies" (
    "Id" uuid NOT NULL,
    "TicketId" uuid NOT NULL,
    "PlayerId" uuid,
    "AdminId" uuid,
    "Content" text NOT NULL,
    "IsInternal" boolean NOT NULL,
    "CreatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."TicketReplies" OWNER TO game_app;

--
-- Name: __EFMigrationsHistory; Type: TABLE; Schema: public; Owner: game_app
--

CREATE TABLE public."__EFMigrationsHistory" (
    "MigrationId" character varying(150) NOT NULL,
    "ProductVersion" character varying(32) NOT NULL
);


ALTER TABLE public."__EFMigrationsHistory" OWNER TO game_app;

--
-- Name: account; Type: TABLE; Schema: public; Owner: game_app
--

CREATE TABLE public.account (
    id uuid NOT NULL,
    account_type character varying(32) NOT NULL,
    email character varying(255),
    steam_id character varying(64),
    eos_id character varying(128),
    status character varying(32) NOT NULL,
    last_login_at timestamp with time zone,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone,
    password_hash character varying(256)
);


ALTER TABLE public.account OWNER TO game_app;

--
-- Name: admin_audit_log; Type: TABLE; Schema: public; Owner: game_app
--

CREATE TABLE public.admin_audit_log (
    id uuid NOT NULL,
    admin_user_id uuid,
    action character varying(128) NOT NULL,
    target_type character varying(64) NOT NULL,
    target_id character varying(128),
    reason text,
    before_json jsonb,
    after_json jsonb,
    ip_address character varying(64),
    user_agent text,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE public.admin_audit_log OWNER TO game_app;

--
-- Name: admin_user; Type: TABLE; Schema: public; Owner: game_app
--

CREATE TABLE public.admin_user (
    id uuid NOT NULL,
    username character varying(64) NOT NULL,
    password_hash character varying(256) NOT NULL,
    role character varying(32) NOT NULL,
    status character varying(32) NOT NULL,
    failed_login_count integer NOT NULL,
    locked_until timestamp with time zone,
    last_login_at timestamp with time zone,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone
);


ALTER TABLE public.admin_user OWNER TO game_app;

--
-- Name: ban_record; Type: TABLE; Schema: public; Owner: game_app
--

CREATE TABLE public.ban_record (
    id uuid NOT NULL,
    account_id uuid NOT NULL,
    player_id uuid,
    reason text NOT NULL,
    starts_at timestamp with time zone NOT NULL,
    ends_at timestamp with time zone,
    created_by uuid,
    created_at timestamp with time zone NOT NULL,
    revoked_at timestamp with time zone,
    revoked_by uuid,
    revoke_reason text
);


ALTER TABLE public.ban_record OWNER TO game_app;

--
-- Name: crash_report; Type: TABLE; Schema: public; Owner: game_app
--

CREATE TABLE public.crash_report (
    id uuid NOT NULL,
    player_id uuid,
    client_version character varying(64),
    platform character varying(32),
    crash_type character varying(64),
    title character varying(255),
    description text,
    dump_url text,
    log_url text,
    metadata_json jsonb NOT NULL,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE public.crash_report OWNER TO game_app;

--
-- Name: daily_stats; Type: TABLE; Schema: public; Owner: game_app
--

CREATE TABLE public.daily_stats (
    date timestamp with time zone NOT NULL,
    new_users integer NOT NULL,
    active_users integer NOT NULL,
    new_accounts integer NOT NULL,
    total_matches integer NOT NULL,
    total_play_time_seconds bigint NOT NULL,
    total_revenue bigint NOT NULL,
    region character varying(32) NOT NULL,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE public.daily_stats OWNER TO game_app;

--
-- Name: device_login; Type: TABLE; Schema: public; Owner: game_app
--

CREATE TABLE public.device_login (
    id uuid NOT NULL,
    account_id uuid NOT NULL,
    device_id_hash character varying(256) NOT NULL,
    device_name character varying(128),
    platform character varying(32),
    last_login_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE public.device_login OWNER TO game_app;

--
-- Name: game_config; Type: TABLE; Schema: public; Owner: game_app
--

CREATE TABLE public.game_config (
    id uuid NOT NULL,
    config_key character varying(128) NOT NULL,
    version character varying(64) NOT NULL,
    content_json jsonb NOT NULL,
    status character varying(32) NOT NULL,
    checksum character varying(128) NOT NULL,
    channel character varying(32) NOT NULL,
    region character varying(32) NOT NULL,
    min_client_version character varying(64),
    max_client_version character varying(64),
    created_by uuid,
    published_by uuid,
    published_at timestamp with time zone,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone
);


ALTER TABLE public.game_config OWNER TO game_app;

--
-- Name: game_config_publish_log; Type: TABLE; Schema: public; Owner: game_app
--

CREATE TABLE public.game_config_publish_log (
    id uuid NOT NULL,
    config_key character varying(128) NOT NULL,
    from_version character varying(64),
    to_version character varying(64) NOT NULL,
    operator_id uuid,
    reason text,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE public.game_config_publish_log OWNER TO game_app;

--
-- Name: game_room; Type: TABLE; Schema: public; Owner: game_app
--

CREATE TABLE public.game_room (
    id uuid NOT NULL,
    owner_player_id uuid NOT NULL,
    mode character varying(64) NOT NULL,
    map_id character varying(64) NOT NULL,
    region character varying(32) NOT NULL,
    max_players integer NOT NULL,
    visibility character varying(32) NOT NULL,
    password_hash character varying(256),
    status character varying(32) NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone,
    closed_at timestamp with time zone
);


ALTER TABLE public.game_room OWNER TO game_app;

--
-- Name: game_room_player; Type: TABLE; Schema: public; Owner: game_app
--

CREATE TABLE public.game_room_player (
    id uuid NOT NULL,
    room_id uuid NOT NULL,
    player_id uuid NOT NULL,
    slot_index integer NOT NULL,
    team character varying(32),
    is_ready boolean NOT NULL,
    joined_at timestamp with time zone NOT NULL,
    left_at timestamp with time zone
);


ALTER TABLE public.game_room_player OWNER TO game_app;

--
-- Name: game_server_event; Type: TABLE; Schema: public; Owner: game_app
--

CREATE TABLE public.game_server_event (
    id uuid NOT NULL,
    server_id uuid NOT NULL,
    event_type character varying(64) NOT NULL,
    payload_json jsonb NOT NULL,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE public.game_server_event OWNER TO game_app;

--
-- Name: game_server_instance; Type: TABLE; Schema: public; Owner: game_app
--

CREATE TABLE public.game_server_instance (
    id uuid NOT NULL,
    session_id uuid,
    mode character varying(64),
    map_id character varying(64),
    region character varying(32),
    build_version character varying(64),
    ip character varying(64) NOT NULL,
    port integer NOT NULL,
    process_id integer,
    container_id character varying(128),
    runtime_token_hash character varying(256),
    runtime_token_expires_at timestamp with time zone,
    status character varying(32) NOT NULL,
    started_at timestamp with time zone NOT NULL,
    ready_at timestamp with time zone,
    allocated_at timestamp with time zone,
    ended_at timestamp with time zone,
    last_heartbeat_at timestamp with time zone,
    exit_code integer,
    crash_reason text,
    log_path text,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone
);


ALTER TABLE public.game_server_instance OWNER TO game_app;

--
-- Name: game_session; Type: TABLE; Schema: public; Owner: game_app
--

CREATE TABLE public.game_session (
    id uuid NOT NULL,
    source_type character varying(32) NOT NULL,
    source_id uuid,
    mode character varying(64) NOT NULL,
    map_id character varying(64) NOT NULL,
    region character varying(32) NOT NULL,
    status character varying(32) NOT NULL,
    server_id uuid,
    server_ip character varying(64),
    server_port integer,
    build_version character varying(64),
    max_players integer NOT NULL,
    retry_count integer NOT NULL,
    created_at timestamp with time zone NOT NULL,
    allocated_at timestamp with time zone,
    started_at timestamp with time zone,
    ended_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.game_session OWNER TO game_app;

--
-- Name: inventory_item; Type: TABLE; Schema: public; Owner: game_app
--

CREATE TABLE public.inventory_item (
    id uuid NOT NULL,
    player_id uuid NOT NULL,
    item_id character varying(128) NOT NULL,
    quantity bigint NOT NULL,
    expires_at timestamp with time zone,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


ALTER TABLE public.inventory_item OWNER TO game_app;

--
-- Name: inventory_log; Type: TABLE; Schema: public; Owner: game_app
--

CREATE TABLE public.inventory_log (
    id uuid NOT NULL,
    player_id uuid NOT NULL,
    item_id character varying(128) NOT NULL,
    quantity_delta bigint NOT NULL,
    quantity_before bigint NOT NULL,
    quantity_after bigint NOT NULL,
    reason character varying(64) NOT NULL,
    biz_type character varying(64),
    biz_id character varying(128),
    operator_id uuid,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE public.inventory_log OWNER TO game_app;

--
-- Name: match_player_result; Type: TABLE; Schema: public; Owner: game_app
--

CREATE TABLE public.match_player_result (
    id uuid NOT NULL,
    match_result_id uuid NOT NULL,
    player_id uuid NOT NULL,
    team character varying(32),
    result character varying(32) NOT NULL,
    kills integer NOT NULL,
    deaths integer NOT NULL,
    assists integer NOT NULL,
    score integer NOT NULL,
    exp_delta bigint NOT NULL,
    reward_json jsonb NOT NULL,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE public.match_player_result OWNER TO game_app;

--
-- Name: match_result; Type: TABLE; Schema: public; Owner: game_app
--

CREATE TABLE public.match_result (
    id uuid NOT NULL,
    session_id uuid NOT NULL,
    server_id uuid NOT NULL,
    mode character varying(64) NOT NULL,
    map_id character varying(64) NOT NULL,
    duration_seconds integer NOT NULL,
    result_json jsonb NOT NULL,
    idempotency_key character varying(128) NOT NULL,
    created_at timestamp with time zone NOT NULL,
    "GameSessionId" uuid
);


ALTER TABLE public.match_result OWNER TO game_app;

--
-- Name: matchmaking_ticket; Type: TABLE; Schema: public; Owner: game_app
--

CREATE TABLE public.matchmaking_ticket (
    id uuid NOT NULL,
    player_id uuid NOT NULL,
    mode character varying(64) NOT NULL,
    region character varying(32) NOT NULL,
    mmr integer DEFAULT 1000 NOT NULL,
    status character varying(32) NOT NULL,
    matched_session_id uuid,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone,
    cancelled_at timestamp with time zone,
    timeout_at timestamp with time zone
);


ALTER TABLE public.matchmaking_ticket OWNER TO game_app;

--
-- Name: order_record; Type: TABLE; Schema: public; Owner: game_app
--

CREATE TABLE public.order_record (
    id uuid NOT NULL,
    player_id uuid NOT NULL,
    platform character varying(32) NOT NULL,
    platform_order_id character varying(128),
    status character varying(32) NOT NULL,
    amount bigint NOT NULL,
    currency character varying(16) NOT NULL,
    item_json jsonb NOT NULL,
    created_at timestamp with time zone NOT NULL,
    paid_at timestamp with time zone,
    completed_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.order_record OWNER TO game_app;

--
-- Name: player_character; Type: TABLE; Schema: public; Owner: game_app
--

CREATE TABLE public.player_character (
    id uuid NOT NULL,
    player_id uuid NOT NULL,
    character_name character varying(24) NOT NULL,
    zodiac character varying(32) NOT NULL,
    primary_element character varying(32) NOT NULL,
    five_camp character varying(32) NOT NULL,
    fixed_skill_group_id character varying(64) NOT NULL,
    core_attributes_json jsonb NOT NULL,
    level integer DEFAULT 1 NOT NULL,
    is_selected boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone NOT NULL,
    last_used_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone
);


ALTER TABLE public.player_character OWNER TO game_app;

--
-- Name: player_event_log; Type: TABLE; Schema: public; Owner: game_app
--

CREATE TABLE public.player_event_log (
    id uuid NOT NULL,
    player_id uuid NOT NULL,
    event_type character varying(64) NOT NULL,
    payload_json jsonb NOT NULL,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE public.player_event_log OWNER TO game_app;

--
-- Name: player_feedback; Type: TABLE; Schema: public; Owner: game_app
--

CREATE TABLE public.player_feedback (
    id uuid NOT NULL,
    player_id uuid,
    nickname character varying(64),
    email character varying(255),
    feedback_type character varying(64) NOT NULL,
    title character varying(255),
    content text NOT NULL,
    status character varying(32) NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone,
    handled_by uuid,
    handled_at timestamp with time zone,
    handle_note text
);


ALTER TABLE public.player_feedback OWNER TO game_app;

--
-- Name: player_identity; Type: TABLE; Schema: public; Owner: game_app
--

CREATE TABLE public.player_identity (
    id uuid NOT NULL,
    account_id uuid NOT NULL,
    player_id uuid NOT NULL,
    display_name character varying(64) NOT NULL,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE public.player_identity OWNER TO game_app;

--
-- Name: player_profile; Type: TABLE; Schema: public; Owner: game_app
--

CREATE TABLE public.player_profile (
    player_id uuid NOT NULL,
    nickname character varying(64) NOT NULL,
    avatar character varying(255),
    level integer DEFAULT 1 NOT NULL,
    exp bigint DEFAULT 0 NOT NULL,
    nickname_updated_at timestamp with time zone,
    created_at timestamp with time zone NOT NULL,
    last_login_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.player_profile OWNER TO game_app;

--
-- Name: player_session; Type: TABLE; Schema: public; Owner: game_app
--

CREATE TABLE public.player_session (
    id uuid NOT NULL,
    game_session_id uuid NOT NULL,
    player_id uuid NOT NULL,
    team character varying(32),
    slot_index integer,
    status character varying(32) NOT NULL,
    session_token_hash character varying(256) NOT NULL,
    session_token_expires_at timestamp with time zone NOT NULL,
    reconnect_token_hash character varying(256),
    reconnect_token_expires_at timestamp with time zone,
    joined_at timestamp with time zone,
    left_at timestamp with time zone,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE public.player_session OWNER TO game_app;

--
-- Name: player_settings; Type: TABLE; Schema: public; Owner: game_app
--

CREATE TABLE public.player_settings (
    player_id uuid NOT NULL,
    settings_json jsonb NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


ALTER TABLE public.player_settings OWNER TO game_app;

--
-- Name: player_statistics; Type: TABLE; Schema: public; Owner: game_app
--

CREATE TABLE public.player_statistics (
    player_id uuid NOT NULL,
    total_matches integer NOT NULL,
    wins integer NOT NULL,
    losses integer NOT NULL,
    draws integer NOT NULL,
    kills integer NOT NULL,
    deaths integer NOT NULL,
    assists integer NOT NULL,
    score bigint NOT NULL,
    play_time_seconds bigint NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


ALTER TABLE public.player_statistics OWNER TO game_app;

--
-- Name: player_unlock; Type: TABLE; Schema: public; Owner: game_app
--

CREATE TABLE public.player_unlock (
    id uuid NOT NULL,
    player_id uuid NOT NULL,
    unlock_type character varying(32) NOT NULL,
    unlock_id character varying(128) NOT NULL,
    source character varying(64) NOT NULL,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE public.player_unlock OWNER TO game_app;

--
-- Name: port_allocation; Type: TABLE; Schema: public; Owner: game_app
--

CREATE TABLE public.port_allocation (
    port integer NOT NULL,
    status character varying(32) NOT NULL,
    server_id uuid,
    allocated_at timestamp with time zone,
    released_at timestamp with time zone
);


ALTER TABLE public.port_allocation OWNER TO game_app;

--
-- Name: port_allocation_port_seq; Type: SEQUENCE; Schema: public; Owner: game_app
--

ALTER TABLE public.port_allocation ALTER COLUMN port ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.port_allocation_port_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: refresh_token; Type: TABLE; Schema: public; Owner: game_app
--

CREATE TABLE public.refresh_token (
    id uuid NOT NULL,
    account_id uuid NOT NULL,
    token_hash character varying(256) NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    revoked_at timestamp with time zone,
    created_at timestamp with time zone NOT NULL,
    created_by_ip character varying(64),
    user_agent text
);


ALTER TABLE public.refresh_token OWNER TO game_app;

--
-- Name: retention_cohort; Type: TABLE; Schema: public; Owner: game_app
--

CREATE TABLE public.retention_cohort (
    id uuid NOT NULL,
    cohort_date timestamp with time zone NOT NULL,
    d0 integer NOT NULL,
    d1 integer NOT NULL,
    d3 integer NOT NULL,
    d7 integer NOT NULL,
    d14 integer NOT NULL,
    d30 integer NOT NULL,
    region character varying(32) NOT NULL
);


ALTER TABLE public.retention_cohort OWNER TO game_app;

--
-- Name: session_event; Type: TABLE; Schema: public; Owner: game_app
--

CREATE TABLE public.session_event (
    id uuid NOT NULL,
    game_session_id uuid NOT NULL,
    event_type character varying(64) NOT NULL,
    payload_json jsonb NOT NULL,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE public.session_event OWNER TO game_app;

--
-- Name: wallet_balance; Type: TABLE; Schema: public; Owner: game_app
--

CREATE TABLE public.wallet_balance (
    id uuid NOT NULL,
    player_id uuid NOT NULL,
    currency_type character varying(32) NOT NULL,
    balance bigint NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


ALTER TABLE public.wallet_balance OWNER TO game_app;

--
-- Name: wallet_ledger; Type: TABLE; Schema: public; Owner: game_app
--

CREATE TABLE public.wallet_ledger (
    id uuid NOT NULL,
    player_id uuid NOT NULL,
    currency_type character varying(32) NOT NULL,
    amount bigint NOT NULL,
    balance_before bigint NOT NULL,
    balance_after bigint NOT NULL,
    biz_type character varying(64) NOT NULL,
    biz_id character varying(128) NOT NULL,
    idempotency_key character varying(128) NOT NULL,
    operator_id uuid,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE public.wallet_ledger OWNER TO game_app;

--
-- Data for Name: Achievements; Type: TABLE DATA; Schema: public; Owner: game_app
--

COPY public."Achievements" ("Id", "AchievementKey", "Title", "Description", "Category", "Icon", "MaxProgress", "RewardsJson", "Order") FROM stdin;
\.


--
-- Data for Name: Announcements; Type: TABLE DATA; Schema: public; Owner: game_app
--

COPY public."Announcements" ("Id", "Title", "Content", "Type", "Priority", "IsActive", "Channel", "Region", "MinVersion", "MaxVersion", "StartAt", "EndAt", "CreatedAt") FROM stdin;
\.


--
-- Data for Name: ClientVersions; Type: TABLE DATA; Schema: public; Owner: game_app
--

COPY public."ClientVersions" ("Id", "Version", "Channel", "Platform", "DownloadUrl", "Checksum", "SizeBytes", "IsMandatory", "IsActive", "MinOsVersion", "ReleaseNotes", "CreatedAt") FROM stdin;
\.


--
-- Data for Name: FriendRelations; Type: TABLE DATA; Schema: public; Owner: game_app
--

COPY public."FriendRelations" ("Id", "PlayerId", "FriendId", "Alias", "CreatedAt") FROM stdin;
\.


--
-- Data for Name: FriendRequests; Type: TABLE DATA; Schema: public; Owner: game_app
--

COPY public."FriendRequests" ("Id", "SenderId", "ReceiverId", "Status", "CreatedAt", "RespondedAt") FROM stdin;
\.


--
-- Data for Name: GameEvents; Type: TABLE DATA; Schema: public; Owner: game_app
--

COPY public."GameEvents" ("Id", "EventKey", "Title", "Description", "Type", "Status", "RewardsJson", "StartAt", "EndAt", "CreatedAt") FROM stdin;
\.


--
-- Data for Name: MailAttachments; Type: TABLE DATA; Schema: public; Owner: game_app
--

COPY public."MailAttachments" ("Id", "MailId", "ItemId", "Quantity", "IsClaimed", "ClaimedAt") FROM stdin;
\.


--
-- Data for Name: Mails; Type: TABLE DATA; Schema: public; Owner: game_app
--

COPY public."Mails" ("Id", "ReceiverId", "MailType", "Title", "Content", "AttachmentJson", "IsRead", "IsDeleted", "ExpiresAt", "CreatedAt", "ReadAt") FROM stdin;
\.


--
-- Data for Name: PlayerAchievements; Type: TABLE DATA; Schema: public; Owner: game_app
--

COPY public."PlayerAchievements" ("Id", "PlayerId", "AchievementId", "Progress", "IsUnlocked", "UnlockedAt") FROM stdin;
\.


--
-- Data for Name: PlayerEventProgresses; Type: TABLE DATA; Schema: public; Owner: game_app
--

COPY public."PlayerEventProgresses" ("Id", "PlayerId", "EventId", "Progress", "Target", "IsCompleted", "IsRewarded", "UpdatedAt") FROM stdin;
\.


--
-- Data for Name: PlayerMatchHistories; Type: TABLE DATA; Schema: public; Owner: game_app
--

COPY public."PlayerMatchHistories" ("Id", "PlayerId", "SessionId", "Mode", "MapId", "Team", "Result", "Kills", "Deaths", "Assists", "Score", "DurationSeconds", "PlayedAt") FROM stdin;
\.


--
-- Data for Name: PlayerRankings; Type: TABLE DATA; Schema: public; Owner: game_app
--

COPY public."PlayerRankings" ("Id", "PlayerId", "Mode", "Rank", "Rating", "TotalMatches", "Wins", "Losses", "Draws", "WinStreak", "MaxWinStreak", "UpdatedAt") FROM stdin;
\.


--
-- Data for Name: Reports; Type: TABLE DATA; Schema: public; Owner: game_app
--

COPY public."Reports" ("Id", "ReporterId", "ReportedPlayerId", "ReportType", "Content", "EvidenceJson", "Status", "HandledBy", "HandleNote", "CreatedAt", "HandledAt") FROM stdin;
\.


--
-- Data for Name: SupportTickets; Type: TABLE DATA; Schema: public; Owner: game_app
--

COPY public."SupportTickets" ("Id", "PlayerId", "TicketType", "Subject", "Content", "Status", "Priority", "AssignedTo", "InternalNote", "CreatedAt", "UpdatedAt", "ResolvedAt", "AssignedAdminId") FROM stdin;
\.


--
-- Data for Name: TicketReplies; Type: TABLE DATA; Schema: public; Owner: game_app
--

COPY public."TicketReplies" ("Id", "TicketId", "PlayerId", "AdminId", "Content", "IsInternal", "CreatedAt") FROM stdin;
\.


--
-- Data for Name: __EFMigrationsHistory; Type: TABLE DATA; Schema: public; Owner: game_app
--

COPY public."__EFMigrationsHistory" ("MigrationId", "ProductVersion") FROM stdin;
20260516082541_InitialGameSchema	10.0.8
20260522001309_AddPlayerCharactersAndDevAccounts	10.0.8
\.


--
-- Data for Name: account; Type: TABLE DATA; Schema: public; Owner: game_app
--

COPY public.account (id, account_type, email, steam_id, eos_id, status, last_login_at, created_at, updated_at, password_hash) FROM stdin;
4b16b960-f07a-40e1-a6ec-176a188e0dd1	GUEST	\N	\N	\N	ACTIVE	2026-06-27 12:22:07.075286+00	2026-06-27 12:22:06.90626+00	\N	\N
50777d4f-69c4-494b-a6a8-f636b0e9cd6d	GUEST	\N	\N	\N	ACTIVE	2026-06-27 12:22:07.111443+00	2026-06-27 12:22:07.108313+00	\N	\N
4d3230fd-98b2-4744-9eb3-4c36b976d456	GUEST	\N	\N	\N	ACTIVE	2026-06-27 12:24:19.662541+00	2026-06-27 12:24:19.656003+00	\N	\N
9140cd6e-36df-47fe-a8a4-87d05d2ea139	GUEST	\N	\N	\N	ACTIVE	2026-06-27 12:24:19.740157+00	2026-06-27 12:24:19.734234+00	\N	\N
c02f78ba-d494-4766-b29c-5c31106196cd	GUEST	\N	\N	\N	ACTIVE	2026-06-27 12:25:50.190523+00	2026-06-27 12:25:50.185585+00	\N	\N
508d668e-314a-4cd8-b1be-05ccced44e1e	GUEST	\N	\N	\N	ACTIVE	2026-06-27 12:25:50.295289+00	2026-06-27 12:25:50.283803+00	\N	\N
3300e0b3-c7f7-47ef-8ac1-f8f313970e8d	GUEST	\N	\N	\N	ACTIVE	2026-06-27 12:27:50.929044+00	2026-06-27 12:27:50.923211+00	\N	\N
61bfafcb-ff17-44e6-9edd-5034a9d31084	GUEST	\N	\N	\N	ACTIVE	2026-06-27 12:27:50.997725+00	2026-06-27 12:27:50.995431+00	\N	\N
870e21fb-7265-4c8e-a224-ab9dd615d171	GUEST	\N	\N	\N	ACTIVE	2026-06-27 12:29:08.825022+00	2026-06-27 12:29:08.81916+00	\N	\N
359e7001-7e4e-4869-94e9-6dd22b77959d	GUEST	\N	\N	\N	ACTIVE	2026-06-27 12:29:08.9059+00	2026-06-27 12:29:08.900033+00	\N	\N
1561ba88-1bf0-41da-b40c-0245b5448151	GUEST	\N	\N	\N	ACTIVE	2026-06-27 12:31:49.725918+00	2026-06-27 12:31:49.723138+00	\N	\N
28193923-dd13-4ff5-983c-3da2272616ef	GUEST	\N	\N	\N	ACTIVE	2026-06-27 12:31:49.821376+00	2026-06-27 12:31:49.816424+00	\N	\N
fb3159b9-69cf-49c3-a324-3547b3658cd6	GUEST	\N	\N	\N	ACTIVE	2026-06-27 12:33:53.827447+00	2026-06-27 12:33:53.821961+00	\N	\N
e3807e41-2c00-412b-91ba-8bccb152cb07	GUEST	\N	\N	\N	ACTIVE	2026-06-27 12:33:53.925109+00	2026-06-27 12:33:53.919916+00	\N	\N
b1d0e11e-c572-4d0f-9a2c-9a1fd5028c2b	GUEST	\N	\N	\N	ACTIVE	2026-06-27 12:52:29.173174+00	2026-06-27 12:52:29.167357+00	\N	\N
35538fb3-d1da-466f-afbe-4592afeb8efb	GUEST	\N	\N	\N	ACTIVE	2026-06-27 12:52:29.257457+00	2026-06-27 12:52:29.248183+00	\N	\N
9697b5fd-31f5-417f-b384-83c721bb0489	GUEST	\N	\N	\N	ACTIVE	2026-06-27 12:53:37.402165+00	2026-06-27 12:53:37.399949+00	\N	\N
66406375-f377-463e-b17f-77bf6bac43eb	GUEST	\N	\N	\N	ACTIVE	2026-06-27 12:53:37.463265+00	2026-06-27 12:53:37.460082+00	\N	\N
e09a7963-5996-4145-9a8e-6ffad121f3a6	GUEST	\N	\N	\N	ACTIVE	2026-06-27 12:56:00.934445+00	2026-06-27 12:56:00.932414+00	\N	\N
7c02b31c-ddca-4ea6-a6a0-c7e0a492afa8	GUEST	\N	\N	\N	ACTIVE	2026-06-27 12:56:01.003191+00	2026-06-27 12:56:00.997673+00	\N	\N
d812d3d9-fafb-4e39-a3e2-e5e0a8f617b5	GUEST	\N	\N	\N	ACTIVE	2026-06-27 12:57:28.070892+00	2026-06-27 12:57:28.068529+00	\N	\N
007acf25-7d1a-45c7-aa26-46da18acca34	GUEST	\N	\N	\N	ACTIVE	2026-06-27 12:57:28.132154+00	2026-06-27 12:57:28.130085+00	\N	\N
640077ad-1fd9-4f78-b215-bfa348010b4a	GUEST	\N	\N	\N	ACTIVE	2026-06-27 12:59:00.044654+00	2026-06-27 12:59:00.04248+00	\N	\N
2d4e931f-5364-431b-9904-6df2c4c2eecb	GUEST	\N	\N	\N	ACTIVE	2026-06-27 12:59:00.114006+00	2026-06-27 12:59:00.108424+00	\N	\N
bd4d705a-ccd9-453b-8d47-92215545c924	GUEST	\N	\N	\N	ACTIVE	2026-06-27 12:59:28.963196+00	2026-06-27 12:59:28.958314+00	\N	\N
3970fbed-f3a0-4e04-bf3d-a4334b24c11d	GUEST	\N	\N	\N	ACTIVE	2026-06-27 12:59:29.022402+00	2026-06-27 12:59:29.020412+00	\N	\N
\.


--
-- Data for Name: admin_audit_log; Type: TABLE DATA; Schema: public; Owner: game_app
--

COPY public.admin_audit_log (id, admin_user_id, action, target_type, target_id, reason, before_json, after_json, ip_address, user_agent, created_at) FROM stdin;
\.


--
-- Data for Name: admin_user; Type: TABLE DATA; Schema: public; Owner: game_app
--

COPY public.admin_user (id, username, password_hash, role, status, failed_login_count, locked_until, last_login_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: ban_record; Type: TABLE DATA; Schema: public; Owner: game_app
--

COPY public.ban_record (id, account_id, player_id, reason, starts_at, ends_at, created_by, created_at, revoked_at, revoked_by, revoke_reason) FROM stdin;
\.


--
-- Data for Name: crash_report; Type: TABLE DATA; Schema: public; Owner: game_app
--

COPY public.crash_report (id, player_id, client_version, platform, crash_type, title, description, dump_url, log_url, metadata_json, created_at) FROM stdin;
019f090a-4f26-74a1-9112-2ea3293e6d3c	\N	\N	Windows	CLIENT_CRASH	Uploaded CrashContext.runtime-xml	Crash upload stored. Payload bytes: 222874.	local://crash-uploads/20260627122458_b2efedabaeea40c8b48cae7128037a87_CrashContext.runtime-xml	\N	{"FilePath": "E:/work/Game/DivineBeastsArena/DBA_GameClient/Saved/Crashes/UECC-Windows-F80A8AF2401B95CFE4B073BBB5CC15A2_0000/CrashContext.runtime-xml", "fileName": "CrashContext.runtime-xml", "acceptedAt": "2026-06-27T12:24:58.402991+00:00", "storagePath": "/app/crash-uploads", "payloadBytes": 222874, "storedFileName": "20260627122458_b2efedabaeea40c8b48cae7128037a87_CrashContext.runtime-xml"}	2026-06-27 12:24:58.402991+00
019f090a-4f2f-7e7d-ae93-99e59b4382b8	\N	\N	Windows	CLIENT_LOG	Uploaded DivineBeastsArena.log	Crash upload stored. Payload bytes: 929438.	\N	local://crash-uploads/20260627122458_dced1fa6039443968678546e5c416bad_DivineBeastsArena.log	{"FilePath": "E:/work/Game/DivineBeastsArena/DBA_GameClient/Saved/Crashes/UECC-Windows-F80A8AF2401B95CFE4B073BBB5CC15A2_0000/DivineBeastsArena.log", "fileName": "DivineBeastsArena.log", "acceptedAt": "2026-06-27T12:24:58.4114531+00:00", "storagePath": "/app/crash-uploads", "payloadBytes": 929438, "storedFileName": "20260627122458_dced1fa6039443968678546e5c416bad_DivineBeastsArena.log"}	2026-06-27 12:24:58.411453+00
019f090a-4f26-714a-ac09-4c087f5863d0	\N	\N	Windows	CLIENT_CRASH	Uploaded CrashReportClient.ini	Crash upload stored. Payload bytes: 239.	local://crash-uploads/20260627122458_21656a31b14c411b8e5ccb618618d41b_CrashReportClient.ini	\N	{"FilePath": "E:/work/Game/DivineBeastsArena/DBA_GameClient/Saved/Crashes/UECC-Windows-C684B07A4A25DC08A713C5A661825F5B_0000/CrashReportClient.ini", "fileName": "CrashReportClient.ini", "acceptedAt": "2026-06-27T12:24:58.3628262+00:00", "storagePath": "/app/crash-uploads", "payloadBytes": 239, "storedFileName": "20260627122458_21656a31b14c411b8e5ccb618618d41b_CrashReportClient.ini"}	2026-06-27 12:24:58.362826+00
019f090a-4f26-7d97-a517-d10ddd71900f	\N	\N	Windows	MINIDUMP	Uploaded UEMinidump.dmp	Crash upload stored. Payload bytes: 504466.	local://crash-uploads/20260627122458_47c60e3e12dd4a3e886849b4f3eead8b_UEMinidump.dmp	\N	{"FilePath": "E:/work/Game/DivineBeastsArena/DBA_GameClient/Saved/Crashes/UECC-Windows-C684B07A4A25DC08A713C5A661825F5B_0000/UEMinidump.dmp", "fileName": "UEMinidump.dmp", "acceptedAt": "2026-06-27T12:24:58.4039595+00:00", "storagePath": "/app/crash-uploads", "payloadBytes": 504466, "storedFileName": "20260627122458_47c60e3e12dd4a3e886849b4f3eead8b_UEMinidump.dmp"}	2026-06-27 12:24:58.403959+00
019f090a-4f26-7161-b734-ac300f62d8fe	\N	\N	Windows	CLIENT_CRASH	Uploaded CrashContext.runtime-xml	Crash upload stored. Payload bytes: 15726.	local://crash-uploads/20260627122458_344b7e74e56f458885bd7e9059020de6_CrashContext.runtime-xml	\N	{"FilePath": "E:/work/Game/DivineBeastsArena/DBA_GameClient/Saved/Crashes/UECC-Windows-C684B07A4A25DC08A713C5A661825F5B_0000/CrashContext.runtime-xml", "fileName": "CrashContext.runtime-xml", "acceptedAt": "2026-06-27T12:24:58.3627411+00:00", "storagePath": "/app/crash-uploads", "payloadBytes": 15726, "storedFileName": "20260627122458_344b7e74e56f458885bd7e9059020de6_CrashContext.runtime-xml"}	2026-06-27 12:24:58.362741+00
019f090a-4f26-7481-923f-0ce7e3221d42	\N	\N	Windows	CLIENT_LOG	Uploaded manual-server-20260627-100559.log	Crash upload stored. Payload bytes: 38485.	\N	local://crash-uploads/20260627122458_846c91c7caf94f3c8d76582b73045d1a_manual-server-20260627-100559.log	{"FilePath": "E:/work/Game/DivineBeastsArena/DBA_GameClient/Saved/Crashes/UECC-Windows-C684B07A4A25DC08A713C5A661825F5B_0000/manual-server-20260627-100559.log", "fileName": "manual-server-20260627-100559.log", "acceptedAt": "2026-06-27T12:24:58.3628627+00:00", "storagePath": "/app/crash-uploads", "payloadBytes": 38485, "storedFileName": "20260627122458_846c91c7caf94f3c8d76582b73045d1a_manual-server-20260627-100559.log"}	2026-06-27 12:24:58.362862+00
019f090a-4f26-7a81-8254-e3edf7f414aa	\N	\N	Windows	CLIENT_CRASH	Uploaded CrashReportClient.ini	Crash upload stored. Payload bytes: 239.	local://crash-uploads/20260627122458_241fb584be8d4cefaaa35b6ddde22fde_CrashReportClient.ini	\N	{"FilePath": "E:/work/Game/DivineBeastsArena/DBA_GameClient/Saved/Crashes/UECC-Windows-F80A8AF2401B95CFE4B073BBB5CC15A2_0000/CrashReportClient.ini", "fileName": "CrashReportClient.ini", "acceptedAt": "2026-06-27T12:24:58.3628629+00:00", "storagePath": "/app/crash-uploads", "payloadBytes": 239, "storedFileName": "20260627122458_241fb584be8d4cefaaa35b6ddde22fde_CrashReportClient.ini"}	2026-06-27 12:24:58.362862+00
019f090a-4f48-7195-af7e-3386257f7b73	\N	\N	Windows	MINIDUMP	Uploaded UEMinidump.dmp	Crash upload stored. Payload bytes: 2671777.	local://crash-uploads/20260627122458_d1b7fc34ec4845d986197e4da5f1df94_UEMinidump.dmp	\N	{"FilePath": "E:/work/Game/DivineBeastsArena/DBA_GameClient/Saved/Crashes/UECC-Windows-F80A8AF2401B95CFE4B073BBB5CC15A2_0000/UEMinidump.dmp", "fileName": "UEMinidump.dmp", "acceptedAt": "2026-06-27T12:24:58.4316523+00:00", "storagePath": "/app/crash-uploads", "payloadBytes": 2671777, "storedFileName": "20260627122458_d1b7fc34ec4845d986197e4da5f1df94_UEMinidump.dmp"}	2026-06-27 12:24:58.431652+00
019f0924-fec5-78eb-91d6-1ad82d78b229	\N	\N	Windows	CLIENT_CRASH	Uploaded CrashContext.runtime-xml	Crash upload stored. Payload bytes: 15724.	local://crash-uploads/20260627125407_c46088246a5244059fca9a4206f62cbb_CrashContext.runtime-xml	\N	{"FilePath": "E:/work/Game/DivineBeastsArena/DBA_GameClient/Saved/Crashes/UECC-Windows-AE75BBC34AD10C7948D6B384F1EA7052_0000/CrashContext.runtime-xml", "fileName": "CrashContext.runtime-xml", "acceptedAt": "2026-06-27T12:54:07.3011587+00:00", "storagePath": "/app/crash-uploads", "payloadBytes": 15724, "storedFileName": "20260627125407_c46088246a5244059fca9a4206f62cbb_CrashContext.runtime-xml"}	2026-06-27 12:54:07.301158+00
019f0924-fec5-7057-85bc-c2c07a5dd291	\N	\N	Windows	CLIENT_CRASH	Uploaded CrashReportClient.ini	Crash upload stored. Payload bytes: 239.	local://crash-uploads/20260627125407_0444086ce5f04be69248f9332f571589_CrashReportClient.ini	\N	{"FilePath": "E:/work/Game/DivineBeastsArena/DBA_GameClient/Saved/Crashes/UECC-Windows-AE75BBC34AD10C7948D6B384F1EA7052_0000/CrashReportClient.ini", "fileName": "CrashReportClient.ini", "acceptedAt": "2026-06-27T12:54:07.3011219+00:00", "storagePath": "/app/crash-uploads", "payloadBytes": 239, "storedFileName": "20260627125407_0444086ce5f04be69248f9332f571589_CrashReportClient.ini"}	2026-06-27 12:54:07.301121+00
019f0924-fec5-701b-b702-270d2b289664	\N	\N	Windows	CLIENT_LOG	Uploaded server-smoke-20260627-203615.log	Crash upload stored. Payload bytes: 38483.	\N	local://crash-uploads/20260627125407_86391cbfbf214a21afa9eeb62419472a_server-smoke-20260627-203615.log	{"FilePath": "E:/work/Game/DivineBeastsArena/DBA_GameClient/Saved/Crashes/UECC-Windows-AE75BBC34AD10C7948D6B384F1EA7052_0000/server-smoke-20260627-203615.log", "fileName": "server-smoke-20260627-203615.log", "acceptedAt": "2026-06-27T12:54:07.3011836+00:00", "storagePath": "/app/crash-uploads", "payloadBytes": 38483, "storedFileName": "20260627125407_86391cbfbf214a21afa9eeb62419472a_server-smoke-20260627-203615.log"}	2026-06-27 12:54:07.301183+00
019f0924-fecf-7398-8d57-c9cbb7f6e7e5	\N	\N	Windows	MINIDUMP	Uploaded UEMinidump.dmp	Crash upload stored. Payload bytes: 515847.	local://crash-uploads/20260627125407_e0fad5e1b6364963a47479757f25ae5f_UEMinidump.dmp	\N	{"FilePath": "E:/work/Game/DivineBeastsArena/DBA_GameClient/Saved/Crashes/UECC-Windows-AE75BBC34AD10C7948D6B384F1EA7052_0000/UEMinidump.dmp", "fileName": "UEMinidump.dmp", "acceptedAt": "2026-06-27T12:54:07.309375+00:00", "storagePath": "/app/crash-uploads", "payloadBytes": 515847, "storedFileName": "20260627125407_e0fad5e1b6364963a47479757f25ae5f_UEMinidump.dmp"}	2026-06-27 12:54:07.309375+00
019f0928-11db-7aae-8d61-0645710da397	\N	\N	Windows	CLIENT_CRASH	Uploaded CrashReportClient.ini	Crash upload stored. Payload bytes: 239.	local://crash-uploads/20260627125728_ed0cb19bf6ce495181d961b301e797eb_CrashReportClient.ini	\N	{"FilePath": "../../../DivineBeastsArena/Saved/Crashes/UECC-Windows-CB80A3FE4E9E6348B35ED0B9DBB66A47_0000/CrashReportClient.ini", "fileName": "CrashReportClient.ini", "acceptedAt": "2026-06-27T12:57:28.7953099+00:00", "storagePath": "/app/crash-uploads", "payloadBytes": 239, "storedFileName": "20260627125728_ed0cb19bf6ce495181d961b301e797eb_CrashReportClient.ini"}	2026-06-27 12:57:28.795309+00
019f0928-11dc-710f-b56b-8ca5551f54df	\N	\N	Windows	CLIENT_LOG	Uploaded server-208fdc1d.log	Crash upload stored. Payload bytes: 97883.	\N	local://crash-uploads/20260627125728_f6aa28172c4948c49425b3c73a40e997_server-208fdc1d.log	{"FilePath": "../../../DivineBeastsArena/Saved/Crashes/UECC-Windows-CB80A3FE4E9E6348B35ED0B9DBB66A47_0000/server-208fdc1d.log", "fileName": "server-208fdc1d.log", "acceptedAt": "2026-06-27T12:57:28.7956541+00:00", "storagePath": "/app/crash-uploads", "payloadBytes": 97883, "storedFileName": "20260627125728_f6aa28172c4948c49425b3c73a40e997_server-208fdc1d.log"}	2026-06-27 12:57:28.795654+00
019f0928-11dc-7b23-8957-abf2355a6a70	\N	\N	Windows	CLIENT_CRASH	Uploaded CrashContext.runtime-xml	Crash upload stored. Payload bytes: 18547.	local://crash-uploads/20260627125728_68012420cd114f2cb351e068a390ac01_CrashContext.runtime-xml	\N	{"FilePath": "../../../DivineBeastsArena/Saved/Crashes/UECC-Windows-CB80A3FE4E9E6348B35ED0B9DBB66A47_0000/CrashContext.runtime-xml", "fileName": "CrashContext.runtime-xml", "acceptedAt": "2026-06-27T12:57:28.7957963+00:00", "storagePath": "/app/crash-uploads", "payloadBytes": 18547, "storedFileName": "20260627125728_68012420cd114f2cb351e068a390ac01_CrashContext.runtime-xml"}	2026-06-27 12:57:28.795796+00
019f0928-11e0-751b-8dbb-1fa5b54f7a59	\N	\N	Windows	MINIDUMP	Uploaded UEMinidump.dmp	Crash upload stored. Payload bytes: 451047.	local://crash-uploads/20260627125728_e5b7be9106ac4062877b227d5a16181a_UEMinidump.dmp	\N	{"FilePath": "../../../DivineBeastsArena/Saved/Crashes/UECC-Windows-CB80A3FE4E9E6348B35ED0B9DBB66A47_0000/UEMinidump.dmp", "fileName": "UEMinidump.dmp", "acceptedAt": "2026-06-27T12:57:28.7994648+00:00", "storagePath": "/app/crash-uploads", "payloadBytes": 451047, "storedFileName": "20260627125728_e5b7be9106ac4062877b227d5a16181a_UEMinidump.dmp"}	2026-06-27 12:57:28.799464+00
019f0928-be3a-7b4f-b14a-b396516e6e7a	\N	\N	Windows	CLIENT_CRASH	Uploaded CrashReportClient.ini	Crash upload stored. Payload bytes: 239.	local://crash-uploads/20260627125812_1ada2e7ab2884d52b54d9ecc8ceafc31_CrashReportClient.ini	\N	{"FilePath": "../../../DivineBeastsArena/Saved/Crashes/UECC-Windows-7A6F03E648DEBF0806D2F7ACD241FBC6_0000/CrashReportClient.ini", "fileName": "CrashReportClient.ini", "acceptedAt": "2026-06-27T12:58:12.9218527+00:00", "storagePath": "/app/crash-uploads", "payloadBytes": 239, "storedFileName": "20260627125812_1ada2e7ab2884d52b54d9ecc8ceafc31_CrashReportClient.ini"}	2026-06-27 12:58:12.921852+00
019f0928-be3c-7b9a-b2b7-b51bf8f94bbb	\N	\N	Windows	CLIENT_CRASH	Uploaded CrashReportClient.ini	Crash upload stored. Payload bytes: 239.	local://crash-uploads/20260627125812_a5597481ca604b45bb67aac57563e26f_CrashReportClient.ini	\N	{"FilePath": "../../../DivineBeastsArena/Saved/Crashes/UECC-Windows-CB80A3FE4E9E6348B35ED0B9DBB66A47_0000/CrashReportClient.ini", "fileName": "CrashReportClient.ini", "acceptedAt": "2026-06-27T12:58:12.9237816+00:00", "storagePath": "/app/crash-uploads", "payloadBytes": 239, "storedFileName": "20260627125812_a5597481ca604b45bb67aac57563e26f_CrashReportClient.ini"}	2026-06-27 12:58:12.923781+00
019f0928-be3d-7a18-bb0d-60520da1bf02	\N	\N	Windows	CLIENT_CRASH	Uploaded CrashContext.runtime-xml	Crash upload stored. Payload bytes: 18547.	local://crash-uploads/20260627125812_d15e818bd7624f5d9abec7f902783f85_CrashContext.runtime-xml	\N	{"FilePath": "../../../DivineBeastsArena/Saved/Crashes/UECC-Windows-7A6F03E648DEBF0806D2F7ACD241FBC6_0000/CrashContext.runtime-xml", "fileName": "CrashContext.runtime-xml", "acceptedAt": "2026-06-27T12:58:12.9236284+00:00", "storagePath": "/app/crash-uploads", "payloadBytes": 18547, "storedFileName": "20260627125812_d15e818bd7624f5d9abec7f902783f85_CrashContext.runtime-xml"}	2026-06-27 12:58:12.923628+00
019f0928-be3e-793c-839e-eaa7569ce509	\N	\N	Windows	CLIENT_CRASH	Uploaded CrashContext.runtime-xml	Crash upload stored. Payload bytes: 18547.	local://crash-uploads/20260627125812_ad91565667c849c69e3b77531856174a_CrashContext.runtime-xml	\N	{"FilePath": "../../../DivineBeastsArena/Saved/Crashes/UECC-Windows-CB80A3FE4E9E6348B35ED0B9DBB66A47_0000/CrashContext.runtime-xml", "fileName": "CrashContext.runtime-xml", "acceptedAt": "2026-06-27T12:58:12.9257171+00:00", "storagePath": "/app/crash-uploads", "payloadBytes": 18547, "storedFileName": "20260627125812_ad91565667c849c69e3b77531856174a_CrashContext.runtime-xml"}	2026-06-27 12:58:12.925717+00
019f0928-be3e-7788-ba9e-6b364f1168fd	\N	\N	Windows	CLIENT_LOG	Uploaded server-ea2e387b.log	Crash upload stored. Payload bytes: 97883.	\N	local://crash-uploads/20260627125812_07c73b80f6d042bca1d7c4b57f155d99_server-ea2e387b.log	{"FilePath": "../../../DivineBeastsArena/Saved/Crashes/UECC-Windows-7A6F03E648DEBF0806D2F7ACD241FBC6_0000/server-ea2e387b.log", "fileName": "server-ea2e387b.log", "acceptedAt": "2026-06-27T12:58:12.9235876+00:00", "storagePath": "/app/crash-uploads", "payloadBytes": 97883, "storedFileName": "20260627125812_07c73b80f6d042bca1d7c4b57f155d99_server-ea2e387b.log"}	2026-06-27 12:58:12.923587+00
019f0928-be3f-776b-9afa-a67fff95c757	\N	\N	Windows	CLIENT_LOG	Uploaded server-208fdc1d.log	Crash upload stored. Payload bytes: 97883.	\N	local://crash-uploads/20260627125812_22755fe19d504f9f9f35ff2efef994fa_server-208fdc1d.log	{"FilePath": "../../../DivineBeastsArena/Saved/Crashes/UECC-Windows-CB80A3FE4E9E6348B35ED0B9DBB66A47_0000/server-208fdc1d.log", "fileName": "server-208fdc1d.log", "acceptedAt": "2026-06-27T12:58:12.9265224+00:00", "storagePath": "/app/crash-uploads", "payloadBytes": 97883, "storedFileName": "20260627125812_22755fe19d504f9f9f35ff2efef994fa_server-208fdc1d.log"}	2026-06-27 12:58:12.926522+00
019f0928-be46-77a3-8dcb-68e0691c9694	\N	\N	Windows	MINIDUMP	Uploaded UEMinidump.dmp	Crash upload stored. Payload bytes: 468988.	local://crash-uploads/20260627125812_d72780a30d664e6ea7c8fce5e25f9976_UEMinidump.dmp	\N	{"FilePath": "../../../DivineBeastsArena/Saved/Crashes/UECC-Windows-7A6F03E648DEBF0806D2F7ACD241FBC6_0000/UEMinidump.dmp", "fileName": "UEMinidump.dmp", "acceptedAt": "2026-06-27T12:58:12.9309207+00:00", "storagePath": "/app/crash-uploads", "payloadBytes": 468988, "storedFileName": "20260627125812_d72780a30d664e6ea7c8fce5e25f9976_UEMinidump.dmp"}	2026-06-27 12:58:12.93092+00
019f0928-be46-77d5-a4bc-13e50f43620a	\N	\N	Windows	MINIDUMP	Uploaded UEMinidump.dmp	Crash upload stored. Payload bytes: 451047.	local://crash-uploads/20260627125812_88a02a31a12749afa8501c940b9b6d13_UEMinidump.dmp	\N	{"FilePath": "../../../DivineBeastsArena/Saved/Crashes/UECC-Windows-CB80A3FE4E9E6348B35ED0B9DBB66A47_0000/UEMinidump.dmp", "fileName": "UEMinidump.dmp", "acceptedAt": "2026-06-27T12:58:12.9305956+00:00", "storagePath": "/app/crash-uploads", "payloadBytes": 451047, "storedFileName": "20260627125812_88a02a31a12749afa8501c940b9b6d13_UEMinidump.dmp"}	2026-06-27 12:58:12.930595+00
\.


--
-- Data for Name: daily_stats; Type: TABLE DATA; Schema: public; Owner: game_app
--

COPY public.daily_stats (date, new_users, active_users, new_accounts, total_matches, total_play_time_seconds, total_revenue, region, created_at) FROM stdin;
2026-06-27 00:00:00+00	0	0	0	0	0	0	global	2026-06-27 12:21:35.348839+00
2026-06-28 00:00:00+00	0	0	0	0	0	0	global	2026-06-28 00:00:10.853638+00
\.


--
-- Data for Name: device_login; Type: TABLE DATA; Schema: public; Owner: game_app
--

COPY public.device_login (id, account_id, device_id_hash, device_name, platform, last_login_at, created_at) FROM stdin;
2ff64899-b3bb-41cd-a3a0-550592bb480e	4b16b960-f07a-40e1-a6ec-176a188e0dd1	9f71767024237accba9ba6f76b75915d3e0e139a2cd2e7be8e534899f5145187	CodexSmoke-A	Windows	2026-06-27 12:22:06.907018+00	2026-06-27 12:22:06.907022+00
bc62ce7c-dfa9-49b8-9564-324705eb1ab9	50777d4f-69c4-494b-a6a8-f636b0e9cd6d	3c6dbbfe5ffbab4e59f1337af5c2596d92eeef4af0c41c1e6f517b8ff0b287d8	CodexSmoke-B	Windows	2026-06-27 12:22:07.108318+00	2026-06-27 12:22:07.108318+00
b32771dc-9182-4188-9d00-81bbaa471330	4d3230fd-98b2-4744-9eb3-4c36b976d456	d9323cdafb5a41537227eca5d3e43d172071647948f8e3849f4c5d722ac5cf26	UEValidation-A	Windows	2026-06-27 12:24:19.65601+00	2026-06-27 12:24:19.65601+00
701029d6-1958-4509-88cb-87a601f2eabc	9140cd6e-36df-47fe-a8a4-87d05d2ea139	4df321754df5161b56def32be144f8749bfceb51f65bc5c79602a797e27b818e	UEValidation-B	Windows	2026-06-27 12:24:19.73424+00	2026-06-27 12:24:19.73424+00
51a801ef-a66e-4e99-a794-af755cc88519	c02f78ba-d494-4766-b29c-5c31106196cd	8bbab375c34b51a2fd4a7a9cffdcda7c144cfc2b5a7654dfe9f0fc8465ccaf54	UEValidation-A	Windows	2026-06-27 12:25:50.185598+00	2026-06-27 12:25:50.185598+00
a0aa974e-75e8-415c-b252-a5215415ff76	508d668e-314a-4cd8-b1be-05ccced44e1e	6a2599dce6baa802e0644ca11d8af0bc9b5318554392dea76437361cd8776bc2	UEValidation-B	Windows	2026-06-27 12:25:50.283808+00	2026-06-27 12:25:50.283808+00
03fc0d4f-fc40-4a05-8ed9-6353f96ca433	3300e0b3-c7f7-47ef-8ac1-f8f313970e8d	10e7641798458bd6ce6fe8d0a83c66701935c39262b87437871ef8c260bbec09	UEValidation-A	Windows	2026-06-27 12:27:50.923226+00	2026-06-27 12:27:50.923226+00
a5fe6059-d1f4-4cc5-a0d3-c05501e1fa54	61bfafcb-ff17-44e6-9edd-5034a9d31084	8271c4dca811ff74538355db157e16e628eb8055e1a256aecd509038c1dd8775	UEValidation-B	Windows	2026-06-27 12:27:50.995437+00	2026-06-27 12:27:50.995437+00
565a6cbd-e5dc-40f3-97f9-c996f1f82c45	870e21fb-7265-4c8e-a224-ab9dd615d171	3e50fc3c7e7fabccb78153eeca3526c3d27a4cf0146447226f15e86d48485629	UEValidation-A	Windows	2026-06-27 12:29:08.819168+00	2026-06-27 12:29:08.819168+00
5cb11d4f-f5c8-439c-b42d-9fb742ed0a69	359e7001-7e4e-4869-94e9-6dd22b77959d	a9904df1b2c7428756ac954fe5c6dbe8c836d228e2f0a350534bc319d4917901	UEValidation-B	Windows	2026-06-27 12:29:08.900039+00	2026-06-27 12:29:08.900039+00
103b6645-7939-4a12-a17b-e38dd6cd3424	1561ba88-1bf0-41da-b40c-0245b5448151	c43df9410196dc528651cc0f48aa08878c4bf09759ffdd9e43bafac9d45b13cd	UEValidation-A	Windows	2026-06-27 12:31:49.723144+00	2026-06-27 12:31:49.723144+00
9743c087-74ab-4486-8a81-21b96a5eb6ea	28193923-dd13-4ff5-983c-3da2272616ef	8b2125eb1397ca6336376207b3e881e4d46cb7cb739256d64d9329c6e97689c4	UEValidation-B	Windows	2026-06-27 12:31:49.81643+00	2026-06-27 12:31:49.81643+00
65c41265-c829-4e61-9831-c7f2c74ae845	fb3159b9-69cf-49c3-a324-3547b3658cd6	5589c8bc1ce4c2c878b1e2db95cc15c3e91787dd84fe9ef8d3794abdb8566a5e	UEValidation-A	Windows	2026-06-27 12:33:53.821974+00	2026-06-27 12:33:53.821974+00
aec220ad-58d2-41c1-bfc5-926a662d8a94	e3807e41-2c00-412b-91ba-8bccb152cb07	a30eba42edc2387fedc3523828ea3e0625560ec897abcda834b65396bc4c7f4c	UEValidation-B	Windows	2026-06-27 12:33:53.919921+00	2026-06-27 12:33:53.919921+00
3c028b48-b854-4612-8c24-e62a2ae40d06	b1d0e11e-c572-4d0f-9a2c-9a1fd5028c2b	dbf0a59ba3faa93923ad06b9d363617590f8da6d65d749a8c765a39fe95acb75	UEValidation-A	Windows	2026-06-27 12:52:29.167363+00	2026-06-27 12:52:29.167363+00
1fc6d7b1-7817-4ab8-82d1-565f1d6942a4	35538fb3-d1da-466f-afbe-4592afeb8efb	b85121cb5a28b2b8eea5d62f4910a5e447edd5762345f06105d3a1a638e8125f	UEValidation-B	Windows	2026-06-27 12:52:29.248188+00	2026-06-27 12:52:29.248188+00
a4755399-2842-4821-877a-def9f2bbb92b	9697b5fd-31f5-417f-b384-83c721bb0489	ba8c78dc4ea8b1f71aa82d7b90f82160c3ced1f82594962393c3b7a2d5c1e151	UEValidation-A	Windows	2026-06-27 12:53:37.399964+00	2026-06-27 12:53:37.399964+00
07aa86c0-935f-4cfb-9a50-2e0f82c33390	66406375-f377-463e-b17f-77bf6bac43eb	fd1b21a292819db1f24225940a48f61e05d7f4c6882768a9d1a7a238b098f40d	UEValidation-B	Windows	2026-06-27 12:53:37.460085+00	2026-06-27 12:53:37.460085+00
32fb7fa0-dc42-46fe-8195-b85c873686f1	e09a7963-5996-4145-9a8e-6ffad121f3a6	1537e4f81c9a0ff0e8089943e8b980a391f79fc3c3a34b245f82cf72f7c8822c	UEValidation-A	Windows	2026-06-27 12:56:00.932418+00	2026-06-27 12:56:00.932418+00
0288acf1-8a56-4079-8406-64cc15abd117	7c02b31c-ddca-4ea6-a6a0-c7e0a492afa8	35fdbb49f0061a23e78eaa351550cb2e428ac7050e2510d8c239e02602727f68	UEValidation-B	Windows	2026-06-27 12:56:00.997677+00	2026-06-27 12:56:00.997677+00
05d96f5a-f300-4f11-9177-81cc4c6e587d	d812d3d9-fafb-4e39-a3e2-e5e0a8f617b5	45acc702c735dc735ccbc69d77d8b77ca8e2324720c8e0c9d2564799fab0555c	UEValidation-A	Windows	2026-06-27 12:57:28.068534+00	2026-06-27 12:57:28.068534+00
8ea62a6b-a173-45d2-ac3c-d40df37aa84f	007acf25-7d1a-45c7-aa26-46da18acca34	479e0b6d5e1ec4130048ed0de735e939cdcf1a7a249c8bbf1d1b04a201f35c81	UEValidation-B	Windows	2026-06-27 12:57:28.130088+00	2026-06-27 12:57:28.130088+00
19518328-73ff-4d95-9296-deeec407db6f	640077ad-1fd9-4f78-b215-bfa348010b4a	7f074c1e130bd9ab3166aa6793565223fa35d81743bda8499c1d993dea042889	UEValidation-A	Windows	2026-06-27 12:59:00.042484+00	2026-06-27 12:59:00.042484+00
72f2a4a8-e469-478e-bda7-4d88ee5e8687	2d4e931f-5364-431b-9904-6df2c4c2eecb	290f733256d336e177ce0dbb4841eaccb7ef1024f7a0785ac815f1aa455edec8	UEValidation-B	Windows	2026-06-27 12:59:00.108429+00	2026-06-27 12:59:00.108429+00
ba1efc07-6cba-4ff4-a1a2-478a9ed9c3a5	bd4d705a-ccd9-453b-8d47-92215545c924	d9089a235eaf97d6aa1597e6ea8a54f0957e4bf290e250367be517077d190069	UEValidation-A	Windows	2026-06-27 12:59:28.958317+00	2026-06-27 12:59:28.958317+00
a53571c0-f4d8-44a1-b1ef-02dc4bb1745d	3970fbed-f3a0-4e04-bf3d-a4334b24c11d	2a04484377cbee2072137c7c8cf25c0b7236712ac41cb7850317bfe28e675a3f	UEValidation-B	Windows	2026-06-27 12:59:29.020416+00	2026-06-27 12:59:29.020416+00
\.


--
-- Data for Name: game_config; Type: TABLE DATA; Schema: public; Owner: game_app
--

COPY public.game_config (id, config_key, version, content_json, status, checksum, channel, region, min_client_version, max_client_version, created_by, published_by, published_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: game_config_publish_log; Type: TABLE DATA; Schema: public; Owner: game_app
--

COPY public.game_config_publish_log (id, config_key, from_version, to_version, operator_id, reason, created_at) FROM stdin;
\.


--
-- Data for Name: game_room; Type: TABLE DATA; Schema: public; Owner: game_app
--

COPY public.game_room (id, owner_player_id, mode, map_id, region, max_players, visibility, password_hash, status, created_at, updated_at, closed_at) FROM stdin;
df12fb57-d1eb-412b-a5c1-5c42c17afd4e	1e228019-1521-479f-ad91-d927d688d1b2	classic	DBA_Arena_Test	local	2	public	\N	IN_GAME	2026-06-27 12:22:07.291567+00	2026-06-27 12:22:07.389546+00	\N
8724bd59-1c68-4c56-91b6-a764c2c70492	4d426de5-588b-4ec3-abd6-e2d2e4e81fa0	classic	LobbyMap	local	2	public	\N	IN_GAME	2026-06-27 12:24:19.804171+00	2026-06-27 12:24:19.829495+00	\N
50d431b4-dcbf-46a1-9696-b22af5f3b650	61947706-bd0f-4fa6-9c86-230ece84ea88	classic	LobbyMap	local	2	public	\N	IN_GAME	2026-06-27 12:25:50.359277+00	2026-06-27 12:25:50.381817+00	\N
baa9872e-7b0d-47a3-8539-a8a4e15db4d1	b8b4b5eb-bd36-4f41-a6af-f2259d8dc7cf	classic	LobbyMap	local	2	public	\N	IN_GAME	2026-06-27 12:27:51.044697+00	2026-06-27 12:27:51.059866+00	\N
4785b975-e344-4998-aeaa-d7dae00597c8	67a2185d-5014-46e0-af5b-e796bebdbb55	classic	LobbyMap	local	2	public	\N	IN_GAME	2026-06-27 12:29:08.964015+00	2026-06-27 12:29:08.979636+00	\N
2c93f3f7-1f61-44b4-99cd-b21d216eb677	3b05d8e1-a049-4e77-8cab-0c92e7add106	classic	LobbyMap	local	2	public	\N	IN_GAME	2026-06-27 12:31:49.875924+00	2026-06-27 12:31:49.889582+00	\N
f09b5e23-b11e-4634-97fa-b4e9b68dfc8f	e212e732-f60a-4c68-9d85-3b9463f4b4bd	classic	LobbyMap	local	2	public	\N	IN_GAME	2026-06-27 12:33:53.981722+00	2026-06-27 12:33:53.999332+00	\N
99a17787-d342-4830-9374-c5ff8003484d	662b7079-1ccc-4871-a9c1-1ffb3c34aa41	classic	LobbyMap	local	2	public	\N	IN_GAME	2026-06-27 12:52:29.308569+00	2026-06-27 12:52:29.323942+00	\N
c96443e6-bb91-44eb-a306-85520aa47589	bb6052a0-f333-478a-8d65-deb9964c98b0	classic	LobbyMap	local	2	public	\N	IN_GAME	2026-06-27 12:53:37.505381+00	2026-06-27 12:53:37.517081+00	\N
db3869e7-7c42-4c79-aada-db27fad9eb54	88f54bb1-054b-49bd-b150-aa6dd77d231c	classic	LobbyMap	local	2	public	\N	IN_GAME	2026-06-27 12:56:01.051446+00	2026-06-27 12:56:01.066389+00	\N
c5775b9e-dee0-4827-b561-050cbb2d62e2	416b3f0e-a6e5-46c9-a5ab-0d6550052847	classic	LobbyMap	local	2	public	\N	IN_GAME	2026-06-27 12:57:28.178269+00	2026-06-27 12:57:28.191691+00	\N
d23e3fb0-cee3-4d6e-aec2-f432d5905265	d2220f7d-df2c-4d82-aeea-9307bc803517	classic	LobbyMap	local	2	public	\N	IN_GAME	2026-06-27 12:59:00.16093+00	2026-06-27 12:59:00.175417+00	\N
1dc7ddc4-8e26-4e44-a9d8-58b52a5c98eb	d508645d-709f-4ef7-9875-d483c124c25d	classic	LobbyMap	local	2	public	\N	IN_GAME	2026-06-27 12:59:29.06806+00	2026-06-27 12:59:29.080096+00	\N
\.


--
-- Data for Name: game_room_player; Type: TABLE DATA; Schema: public; Owner: game_app
--

COPY public.game_room_player (id, room_id, player_id, slot_index, team, is_ready, joined_at, left_at) FROM stdin;
1f1cc60e-1df8-4308-b443-de67007ae8e4	df12fb57-d1eb-412b-a5c1-5c42c17afd4e	1e228019-1521-479f-ad91-d927d688d1b2	0	\N	f	2026-06-27 12:22:07.291644+00	\N
60b581fe-8fbd-4be9-a7a8-b0fce5e84162	df12fb57-d1eb-412b-a5c1-5c42c17afd4e	6e300941-1e1a-4e79-995c-067237eacf1e	1	\N	t	2026-06-27 12:22:07.370713+00	2026-06-27 12:22:07.538093+00
71b8eb68-787a-4827-aba9-124c1fb7ca14	8724bd59-1c68-4c56-91b6-a764c2c70492	4d426de5-588b-4ec3-abd6-e2d2e4e81fa0	0	\N	f	2026-06-27 12:24:19.804171+00	\N
156d4462-77f1-4a3b-8e8e-db2a3becfb27	8724bd59-1c68-4c56-91b6-a764c2c70492	8a67a6f9-59f6-4bb1-8141-9268ba831431	1	\N	t	2026-06-27 12:24:19.815299+00	\N
5eded14c-feea-4e9c-9d03-f2ef459fe348	50d431b4-dcbf-46a1-9696-b22af5f3b650	61947706-bd0f-4fa6-9c86-230ece84ea88	0	\N	f	2026-06-27 12:25:50.359277+00	\N
ca7bba25-6749-4482-8c5b-036d1aaf9459	50d431b4-dcbf-46a1-9696-b22af5f3b650	d7bf41de-c6b4-437a-8491-977fe6aea811	1	\N	t	2026-06-27 12:25:50.369665+00	\N
288d0244-812f-4745-9111-ac3a4ca52f2f	baa9872e-7b0d-47a3-8539-a8a4e15db4d1	b8b4b5eb-bd36-4f41-a6af-f2259d8dc7cf	0	\N	f	2026-06-27 12:27:51.044697+00	\N
ea27b5a6-acc9-4035-aeb5-3c67db6b0c4b	baa9872e-7b0d-47a3-8539-a8a4e15db4d1	519ff91e-7648-4ecb-8508-804a17cd32ea	1	\N	t	2026-06-27 12:27:51.051688+00	\N
c9c6821b-fdac-4673-947e-db43e2c4bbcc	4785b975-e344-4998-aeaa-d7dae00597c8	67a2185d-5014-46e0-af5b-e796bebdbb55	0	\N	f	2026-06-27 12:29:08.964015+00	\N
7f84f2f9-1487-4d08-9b07-7b7ab4a18618	4785b975-e344-4998-aeaa-d7dae00597c8	66df9d43-220b-4ac9-8f02-2e3ce2b2842a	1	\N	t	2026-06-27 12:29:08.97099+00	\N
d33519e5-d582-45ed-8a1f-6540bac0843d	2c93f3f7-1f61-44b4-99cd-b21d216eb677	3b05d8e1-a049-4e77-8cab-0c92e7add106	0	\N	f	2026-06-27 12:31:49.875924+00	\N
db6f504d-48d3-40d9-8f50-b9f255afd148	2c93f3f7-1f61-44b4-99cd-b21d216eb677	aeb6861b-fa82-4ec2-856a-8ffc4177413a	1	\N	t	2026-06-27 12:31:49.882235+00	\N
0d97fe70-3637-4c6a-9578-b0c6cba6d5f4	f09b5e23-b11e-4634-97fa-b4e9b68dfc8f	e212e732-f60a-4c68-9d85-3b9463f4b4bd	0	\N	f	2026-06-27 12:33:53.981722+00	\N
1e6912d7-a55b-40bc-bae4-e2850f22a16e	f09b5e23-b11e-4634-97fa-b4e9b68dfc8f	2591522d-8365-49d2-ab2e-a65cb1d4685a	1	\N	t	2026-06-27 12:33:53.988627+00	\N
f27e2147-a5e0-467a-8026-76e168a4b9f5	99a17787-d342-4830-9374-c5ff8003484d	662b7079-1ccc-4871-a9c1-1ffb3c34aa41	0	\N	f	2026-06-27 12:52:29.308569+00	\N
75d1db42-f664-4009-8a38-48567402ade0	99a17787-d342-4830-9374-c5ff8003484d	e560b151-f438-4480-9d81-1f08da21d896	1	\N	t	2026-06-27 12:52:29.315393+00	\N
2fea753f-9aa7-437e-8cae-8bb1c567d165	c96443e6-bb91-44eb-a306-85520aa47589	bb6052a0-f333-478a-8d65-deb9964c98b0	0	\N	f	2026-06-27 12:53:37.505382+00	\N
079f3f68-56a1-4165-ac0f-5ffa7cff0701	c96443e6-bb91-44eb-a306-85520aa47589	1d448a2c-c113-426e-af73-7f8d023306d6	1	\N	t	2026-06-27 12:53:37.510976+00	\N
2e81cf50-e412-437c-97c7-c918cd128f6d	db3869e7-7c42-4c79-aada-db27fad9eb54	88f54bb1-054b-49bd-b150-aa6dd77d231c	0	\N	f	2026-06-27 12:56:01.051447+00	\N
d29e0113-5701-4f09-8988-c1caa81b19d3	db3869e7-7c42-4c79-aada-db27fad9eb54	3067c73a-8eae-42db-a1b1-d1b504f04f83	1	\N	t	2026-06-27 12:56:01.057699+00	\N
3ae28ada-77c6-466c-95bc-ee78c544ceb6	c5775b9e-dee0-4827-b561-050cbb2d62e2	416b3f0e-a6e5-46c9-a5ab-0d6550052847	0	\N	f	2026-06-27 12:57:28.178271+00	\N
15ebd9f4-aa1b-44dc-8545-d81d60b37fba	c5775b9e-dee0-4827-b561-050cbb2d62e2	04846414-01f3-46f9-8a53-f253e0193d1c	1	\N	t	2026-06-27 12:57:28.184281+00	\N
7ad744b8-80a4-441a-b4f2-5b0a517ec961	d23e3fb0-cee3-4d6e-aec2-f432d5905265	d2220f7d-df2c-4d82-aeea-9307bc803517	0	\N	f	2026-06-27 12:59:00.160931+00	\N
c078a70a-80ce-4a2c-8748-11f7a9acace6	d23e3fb0-cee3-4d6e-aec2-f432d5905265	daccbc4e-c950-4845-a8b6-40c15f66796d	1	\N	t	2026-06-27 12:59:00.167759+00	\N
aa024ebb-5dbd-497c-91c0-8799d8283bc2	1dc7ddc4-8e26-4e44-a9d8-58b52a5c98eb	d508645d-709f-4ef7-9875-d483c124c25d	0	\N	f	2026-06-27 12:59:29.068061+00	\N
038bfd34-ad10-4d4a-a619-c3d620a177ab	1dc7ddc4-8e26-4e44-a9d8-58b52a5c98eb	5a05cf51-86bb-4eb9-bcb1-6e337375c6c9	1	\N	t	2026-06-27 12:59:29.073349+00	\N
\.


--
-- Data for Name: game_server_event; Type: TABLE DATA; Schema: public; Owner: game_app
--

COPY public.game_server_event (id, server_id, event_type, payload_json, created_at) FROM stdin;
ceec3d88-e5ee-4c57-aea9-301d54232754	b3280610-f880-4238-8f63-a6700f413a34	ALLOCATE_REQUESTED	{"mode": "classic", "port": 7777, "mapId": "LobbyMap", "sessionId": "f6cad132-fe4d-4346-bde7-5dac8cff72d4"}	2026-06-27 12:24:19.91054+00
35fd3f8d-cadc-44fc-8e5c-9f842dbc62b0	b3280610-f880-4238-8f63-a6700f413a34	LAUNCH_SKIPPED_MOCK	{}	2026-06-27 12:24:19.93995+00
e03568a8-b921-46db-9493-1aa994e67f14	b3280610-f880-4238-8f63-a6700f413a34	READY	{}	2026-06-27 12:24:58.470572+00
6362323f-ab35-427b-b744-73f180e361ab	b3280610-f880-4238-8f63-a6700f413a34	RUNTIME_REGISTER	{}	2026-06-27 12:24:58.469086+00
32aae791-9618-4457-8b57-6890d51a4b1e	d333ae3e-7174-4a4a-ac47-5d6ac711c718	ALLOCATE_REQUESTED	{"mode": "classic", "port": 7778, "mapId": "LobbyMap", "sessionId": "1f8e87b3-0a17-4738-a715-c14528e0312a"}	2026-06-27 12:25:50.399277+00
1004bbb2-09bb-4bf0-afa9-9a0c6d40f0b6	d333ae3e-7174-4a4a-ac47-5d6ac711c718	LAUNCH_SKIPPED_MOCK	{}	2026-06-27 12:25:50.40299+00
d39455d1-b64d-4393-8db0-689eca06a2a5	d333ae3e-7174-4a4a-ac47-5d6ac711c718	RUNTIME_REGISTER	{}	2026-06-27 12:26:00.919518+00
21c7fd49-6d92-4243-9010-e1728a5f9fb1	d333ae3e-7174-4a4a-ac47-5d6ac711c718	READY	{}	2026-06-27 12:26:00.920465+00
b86e942e-3c8d-4a76-9c6f-782c7df148c7	d333ae3e-7174-4a4a-ac47-5d6ac711c718	RELEASED	{"reason": "local ue validation cleanup"}	2026-06-27 12:26:01.788593+00
0dc9fa15-7dc3-4234-9c29-7b0e5f4f0e16	5e7717c9-7ead-4c05-9f7e-3e3c8a8eba53	ALLOCATE_REQUESTED	{"mode": "classic", "port": 7778, "mapId": "LobbyMap", "sessionId": "310d2b11-6375-431a-b2e8-f50611a7ee31"}	2026-06-27 12:27:51.074225+00
ca78814b-33e6-43ec-a791-05fa52d71a0c	5e7717c9-7ead-4c05-9f7e-3e3c8a8eba53	LAUNCH_SKIPPED_MOCK	{}	2026-06-27 12:27:51.077026+00
0104bea2-a5de-4f72-9a0c-ffe1579e839d	5e7717c9-7ead-4c05-9f7e-3e3c8a8eba53	RUNTIME_REGISTER	{}	2026-06-27 12:28:00.386123+00
258113ac-c4c4-4272-bd55-3d7adffa9127	5e7717c9-7ead-4c05-9f7e-3e3c8a8eba53	READY	{}	2026-06-27 12:28:00.386858+00
c29051e4-2872-40fe-8d4b-310ad0f6df18	5e7717c9-7ead-4c05-9f7e-3e3c8a8eba53	RELEASED	{"reason": "local ue validation cleanup"}	2026-06-27 12:28:06.547095+00
07c296e0-d081-4fc0-a592-d58486f619b9	c9fc1f04-a5af-4eb2-81c1-10ec868fb523	ALLOCATE_REQUESTED	{"mode": "classic", "port": 7778, "mapId": "LobbyMap", "sessionId": "cda30148-0b53-4d09-80df-4c6d5e231995"}	2026-06-27 12:29:08.993723+00
6afca967-dc95-4683-bf9e-0d65b64dc489	c9fc1f04-a5af-4eb2-81c1-10ec868fb523	LAUNCH_SKIPPED_MOCK	{}	2026-06-27 12:29:08.996427+00
0e67aca2-6762-46bf-b187-480bffde1ed9	c9fc1f04-a5af-4eb2-81c1-10ec868fb523	RUNTIME_REGISTER	{}	2026-06-27 12:29:17.778927+00
17883354-993e-4eca-aa9f-516767fb6d44	c9fc1f04-a5af-4eb2-81c1-10ec868fb523	READY	{}	2026-06-27 12:29:17.781223+00
43d6b37b-0064-4698-8775-7a5fce89bb85	c9fc1f04-a5af-4eb2-81c1-10ec868fb523	HEARTBEAT	{}	2026-06-27 12:29:38.420525+00
66db1924-5240-40ec-8218-682c5710e993	c9fc1f04-a5af-4eb2-81c1-10ec868fb523	HEARTBEAT	{}	2026-06-27 12:29:58.423454+00
759e46a5-4309-49e2-a566-a4b0ebed8d37	b3280610-f880-4238-8f63-a6700f413a34	MAINTENANCE_TIMEOUT	{"previousStatus": "READY"}	2026-06-27 12:30:05.425929+00
f52129be-476f-4db3-9203-cfefb317a157	c9fc1f04-a5af-4eb2-81c1-10ec868fb523	RELEASED	{"reason": "local ue validation cleanup"}	2026-06-27 12:30:08.361727+00
5a9763f6-c871-49b8-89a7-62e8aeef901d	ebb744ac-b00d-4986-bef9-d51559201cc4	ALLOCATE_REQUESTED	{"mode": "classic", "port": 7777, "mapId": "LobbyMap", "sessionId": "cf25c5b4-ccd4-4a92-83d2-04bf6121fb63"}	2026-06-27 12:31:49.906002+00
585843e8-15b5-48c8-8a64-7c453f64cce2	ebb744ac-b00d-4986-bef9-d51559201cc4	LAUNCH_SKIPPED_MOCK	{}	2026-06-27 12:31:49.909247+00
15c7162e-190c-462d-bba8-a83bdbd45cd7	ebb744ac-b00d-4986-bef9-d51559201cc4	RUNTIME_REGISTER	{}	2026-06-27 12:31:58.017647+00
75f27d99-3a9b-4d31-a0c7-9fc722c90c19	ebb744ac-b00d-4986-bef9-d51559201cc4	READY	{}	2026-06-27 12:31:58.023874+00
1bdd75c8-3ca7-4e9e-8344-e02f834ca06e	ebb744ac-b00d-4986-bef9-d51559201cc4	HEARTBEAT	{}	2026-06-27 12:32:18.534439+00
c475cf9a-4504-4d2a-b551-89f3e8bd20f7	ebb744ac-b00d-4986-bef9-d51559201cc4	HEARTBEAT	{}	2026-06-27 12:32:38.531691+00
62c1924b-7f3a-4e14-a418-a69f7daafd0f	ebb744ac-b00d-4986-bef9-d51559201cc4	RELEASED	{"reason": "local ue validation cleanup"}	2026-06-27 12:32:48.327036+00
a8edf8c6-0f91-4605-9641-46498bd7dd2c	2f73c548-337b-434b-b5a8-59364d0b0e56	ALLOCATE_REQUESTED	{"mode": "classic", "port": 7777, "mapId": "LobbyMap", "sessionId": "d7acfafe-a374-4052-846a-e4abfaa04a32"}	2026-06-27 12:33:54.013082+00
28ceab36-5a3e-409d-b695-bcae50279a9f	2f73c548-337b-434b-b5a8-59364d0b0e56	LAUNCH_SKIPPED_MOCK	{}	2026-06-27 12:33:54.015934+00
2fe843fa-cb7b-4046-9392-bcdc10cb2522	2f73c548-337b-434b-b5a8-59364d0b0e56	RUNTIME_REGISTER	{}	2026-06-27 12:34:03.489403+00
1efafd17-926a-4f84-94fb-f6508342948b	2f73c548-337b-434b-b5a8-59364d0b0e56	READY	{}	2026-06-27 12:34:03.490574+00
a61799de-5e9d-47a1-ab58-f6fa1427ed13	2f73c548-337b-434b-b5a8-59364d0b0e56	HEARTBEAT	{}	2026-06-27 12:34:24.056488+00
751b5d5d-3ced-4ec3-b442-7b456e39c9c5	2f73c548-337b-434b-b5a8-59364d0b0e56	HEARTBEAT	{}	2026-06-27 12:34:44.046812+00
f542d08a-2a4b-47b0-b6c9-34056a61c956	2f73c548-337b-434b-b5a8-59364d0b0e56	RELEASED	{"reason": "local ue validation cleanup"}	2026-06-27 12:34:54.529186+00
7385ef8d-65df-4af8-b865-336820c104c3	e9485dec-8ad7-44dd-bf99-22c619fa18a9	ALLOCATE_REQUESTED	{"mode": "classic", "port": 7777, "mapId": "LobbyMap", "sessionId": "8a26d0ad-0fd1-4da7-b92f-946a33dae1ac"}	2026-06-27 12:52:29.338595+00
a9a67481-7857-4183-9e75-35c3245d577c	e9485dec-8ad7-44dd-bf99-22c619fa18a9	LAUNCH_SKIPPED_MOCK	{}	2026-06-27 12:52:29.341481+00
39a20b48-a72a-4cc7-9106-fd9ebfca88a5	e9485dec-8ad7-44dd-bf99-22c619fa18a9	READY	{}	2026-06-27 12:53:00.818386+00
d05ed8fe-3a7f-4244-ba96-99739079cc9d	e9485dec-8ad7-44dd-bf99-22c619fa18a9	RUNTIME_REGISTER	{}	2026-06-27 12:53:00.822389+00
aceb6a6c-a23b-450f-93a0-7477855299e7	e9485dec-8ad7-44dd-bf99-22c619fa18a9	RELEASED	{"reason": "local ue validation cleanup"}	2026-06-27 12:53:01.894557+00
e60478db-cfe2-4cfe-95af-246daeca55a6	74655b9b-b2ed-4e1f-8140-8e448d40ebd6	ALLOCATE_REQUESTED	{"mode": "classic", "port": 7777, "mapId": "LobbyMap", "sessionId": "2c429a3b-972c-46fb-ab82-7c27bd98976d"}	2026-06-27 12:53:37.53791+00
d9bca455-7d6c-4590-9d5a-4fa8e98ab8be	74655b9b-b2ed-4e1f-8140-8e448d40ebd6	LAUNCH_SKIPPED_MOCK	{}	2026-06-27 12:53:37.543749+00
2c77a0ae-8cf6-4e40-8cd5-0c21084191eb	74655b9b-b2ed-4e1f-8140-8e448d40ebd6	RUNTIME_REGISTER	{}	2026-06-27 12:53:57.107797+00
78937932-63cc-4589-ab22-b841bbf2588f	74655b9b-b2ed-4e1f-8140-8e448d40ebd6	READY	{}	2026-06-27 12:53:57.108441+00
f1fbd3d9-378d-489a-9ad6-fbecf28f6c3b	74655b9b-b2ed-4e1f-8140-8e448d40ebd6	HEARTBEAT	{}	2026-06-27 12:54:17.177259+00
5e1c881e-ad64-481f-bf6f-c1617fae8c63	74655b9b-b2ed-4e1f-8140-8e448d40ebd6	HEARTBEAT	{}	2026-06-27 12:54:37.163982+00
e2812bb0-5e28-4687-8b05-276e521e163b	74655b9b-b2ed-4e1f-8140-8e448d40ebd6	RELEASED	{"reason": "local ue validation cleanup"}	2026-06-27 12:54:48.081761+00
8aac14ce-b6ba-4c07-a94f-e610784bc540	544281f9-ae82-4384-be89-47da17537467	ALLOCATE_REQUESTED	{"mode": "classic", "port": 7777, "mapId": "LobbyMap", "sessionId": "337e0abf-857e-47a1-95f6-346f73d9bfe7"}	2026-06-27 12:56:01.07911+00
7322bdfa-2ae4-41af-a217-d7ad38db66b2	544281f9-ae82-4384-be89-47da17537467	LAUNCH_SKIPPED_MOCK	{}	2026-06-27 12:56:01.084102+00
ee8c361d-4d40-40a7-934f-225c7c832a46	544281f9-ae82-4384-be89-47da17537467	RELEASED	{"reason": "local ue validation cleanup"}	2026-06-27 12:56:02.195228+00
375b926e-b892-4e5b-9641-43a8ae5d0a6c	fdeea3c7-ef68-433e-a087-a55167a027a7	ALLOCATE_REQUESTED	{"mode": "classic", "port": 7777, "mapId": "LobbyMap", "sessionId": "0ef9a6b7-743e-4b00-8e4d-c03a2556d6a1"}	2026-06-27 12:57:28.206294+00
5b5c798b-8049-487e-8730-98cdfc140579	fdeea3c7-ef68-433e-a087-a55167a027a7	LAUNCH_SKIPPED_MOCK	{}	2026-06-27 12:57:28.209073+00
38a40df9-d9f9-46f0-bb2f-a91add6a1803	fdeea3c7-ef68-433e-a087-a55167a027a7	RELEASED	{"reason": "local ue validation cleanup"}	2026-06-27 12:57:29.313623+00
0e0fd90f-667d-44eb-ade5-47f867bf88af	3c955e54-2601-409b-a808-4b020efa8d2c	ALLOCATE_REQUESTED	{"mode": "classic", "port": 7777, "mapId": "LobbyMap", "sessionId": "b2351b4b-54af-4536-85f2-fc609f1bf923"}	2026-06-27 12:59:00.190768+00
2a2ffb15-db28-4b32-a2f6-a2ddd2feeeca	3c955e54-2601-409b-a808-4b020efa8d2c	LAUNCH_SKIPPED_MOCK	{}	2026-06-27 12:59:00.193928+00
b15a03ab-6522-42c8-984e-1a52a0ea6965	3c955e54-2601-409b-a808-4b020efa8d2c	RUNTIME_REGISTER	{}	2026-06-27 12:59:00.930876+00
effd5d07-5616-4dcd-82f9-b57dbacdf5ef	3c955e54-2601-409b-a808-4b020efa8d2c	READY	{}	2026-06-27 12:59:00.931187+00
057748f8-37c4-4658-a3a2-0c6f4e44beb4	3c955e54-2601-409b-a808-4b020efa8d2c	RELEASED	{"reason": "local ue validation cleanup"}	2026-06-27 12:59:01.359514+00
fbf0c04f-d389-4cdf-be54-0d8fff980f9e	43dcc115-12c9-4638-850c-ed73e1bf7961	ALLOCATE_REQUESTED	{"mode": "classic", "port": 7777, "mapId": "LobbyMap", "sessionId": "797f201d-7d5f-4622-8c82-7e270105643f"}	2026-06-27 12:59:29.09328+00
47ffa9b6-d7d2-4dff-84f0-8d865c2bd591	43dcc115-12c9-4638-850c-ed73e1bf7961	LAUNCH_SKIPPED_MOCK	{}	2026-06-27 12:59:29.095873+00
205cd88a-08ba-41e7-9ebb-5c963a34b778	43dcc115-12c9-4638-850c-ed73e1bf7961	RUNTIME_REGISTER	{}	2026-06-27 12:59:29.824648+00
b61bcb28-932c-487b-9c31-d7d24c1b90fd	43dcc115-12c9-4638-850c-ed73e1bf7961	READY	{}	2026-06-27 12:59:29.825127+00
2891a5d0-0ee6-469f-a4aa-d69c90bf0ee1	43dcc115-12c9-4638-850c-ed73e1bf7961	HEARTBEAT	{}	2026-06-27 12:59:49.880739+00
9dec303c-9f6e-4fcf-aeb6-41e7d4b4761d	43dcc115-12c9-4638-850c-ed73e1bf7961	HEARTBEAT	{}	2026-06-27 13:00:09.906562+00
ba0f4473-d894-41fd-a476-88590e135a17	43dcc115-12c9-4638-850c-ed73e1bf7961	RELEASED	{"reason": "local ue validation cleanup"}	2026-06-27 13:00:20.482831+00
\.


--
-- Data for Name: game_server_instance; Type: TABLE DATA; Schema: public; Owner: game_app
--

COPY public.game_server_instance (id, session_id, mode, map_id, region, build_version, ip, port, process_id, container_id, runtime_token_hash, runtime_token_expires_at, status, started_at, ready_at, allocated_at, ended_at, last_heartbeat_at, exit_code, crash_reason, log_path, created_at, updated_at) FROM stdin;
d333ae3e-7174-4a4a-ac47-5d6ac711c718	1f8e87b3-0a17-4738-a715-c14528e0312a	classic	LobbyMap	local	local-validation	127.0.0.1	7778	\N	\N	91998e89df347b99d3126e07d6e2960eeaf8fe848afaadc071ced7f68a14a7d2	2026-06-27 18:25:50.399123+00	STOPPED	2026-06-27 12:25:50.399123+00	2026-06-27 12:26:00.920461+00	\N	2026-06-27 12:26:01.788549+00	2026-06-27 12:26:00.920461+00	\N	\N	\N	2026-06-27 12:25:50.399123+00	2026-06-27 12:26:01.788558+00
5e7717c9-7ead-4c05-9f7e-3e3c8a8eba53	310d2b11-6375-431a-b2e8-f50611a7ee31	classic	LobbyMap	local	local-validation	127.0.0.1	7778	\N	\N	a120d3ee40fde0b726a2664aff2a895739e27e78274c854e0aaaf207627eeb1e	2026-06-27 18:27:51.074113+00	STOPPED	2026-06-27 12:27:51.074113+00	2026-06-27 12:28:00.386854+00	\N	2026-06-27 12:28:06.547085+00	2026-06-27 12:28:00.386854+00	\N	\N	\N	2026-06-27 12:27:51.074113+00	2026-06-27 12:28:06.547086+00
b3280610-f880-4238-8f63-a6700f413a34	f6cad132-fe4d-4346-bde7-5dac8cff72d4	classic	LobbyMap	local	local-validation	127.0.0.1	7777	\N	\N	810653ea681b90f0e26f9eb5fbb1b6244f829f9663f1db226aa94c973f32e292	2026-06-27 18:24:19.891495+00	STOPPED	2026-06-27 12:24:19.891495+00	2026-06-27 12:24:58.470508+00	\N	2026-06-27 12:30:05.381876+00	2026-06-27 12:24:58.46902+00	\N	Server manager maintenance timeout	\N	2026-06-27 12:24:19.891495+00	2026-06-27 12:30:05.381876+00
c9fc1f04-a5af-4eb2-81c1-10ec868fb523	cda30148-0b53-4d09-80df-4c6d5e231995	classic	LobbyMap	local	local-validation	127.0.0.1	7778	\N	\N	38adaab1cff6e33ec4f2049bfd5678c8950dae47603465b29afee9218aef7559	2026-06-27 18:29:08.993619+00	STOPPED	2026-06-27 12:29:08.993619+00	2026-06-27 12:29:17.781203+00	\N	2026-06-27 12:30:08.361721+00	2026-06-27 12:29:58.423449+00	\N	\N	\N	2026-06-27 12:29:08.993619+00	2026-06-27 12:30:08.361722+00
ebb744ac-b00d-4986-bef9-d51559201cc4	cf25c5b4-ccd4-4a92-83d2-04bf6121fb63	classic	LobbyMap	local	local-validation	127.0.0.1	7777	\N	\N	6d6b94e903f32f2cbf5429e189cc3d30a8e66f7d3c1b5be877095328d8629b2c	2026-06-27 18:31:49.905897+00	STOPPED	2026-06-27 12:31:49.905897+00	2026-06-27 12:31:58.023867+00	\N	2026-06-27 12:32:48.327026+00	2026-06-27 12:32:38.531685+00	\N	\N	\N	2026-06-27 12:31:49.905897+00	2026-06-27 12:32:48.327027+00
2f73c548-337b-434b-b5a8-59364d0b0e56	d7acfafe-a374-4052-846a-e4abfaa04a32	classic	LobbyMap	local	local-validation	127.0.0.1	7777	\N	\N	66851c700768404de9e510d074e47435b48459d6bc4e2df0bedcf0fd811c4eeb	2026-06-27 18:33:54.012956+00	STOPPED	2026-06-27 12:33:54.012956+00	2026-06-27 12:34:03.490556+00	\N	2026-06-27 12:34:54.529156+00	2026-06-27 12:34:44.046805+00	\N	\N	\N	2026-06-27 12:33:54.012956+00	2026-06-27 12:34:54.529156+00
e9485dec-8ad7-44dd-bf99-22c619fa18a9	8a26d0ad-0fd1-4da7-b92f-946a33dae1ac	classic	LobbyMap	local	local-validation	127.0.0.1	7777	\N	\N	b08f7a66a597419332aa8c190ae0cfa6bf515cb2d3d397dd3fe36edb7c2f1b93	2026-06-27 18:52:29.33845+00	STOPPED	2026-06-27 12:52:29.33845+00	2026-06-27 12:53:00.818377+00	\N	2026-06-27 12:53:01.89455+00	2026-06-27 12:53:00.822383+00	\N	\N	\N	2026-06-27 12:52:29.33845+00	2026-06-27 12:53:01.894551+00
74655b9b-b2ed-4e1f-8140-8e448d40ebd6	2c429a3b-972c-46fb-ab82-7c27bd98976d	classic	LobbyMap	local	local-validation	127.0.0.1	7777	\N	\N	8189cc9db1bbc3079dbb4484bf501636115d74d79548c3708c6fccd8a8f3b1fe	2026-06-27 18:53:37.537825+00	STOPPED	2026-06-27 12:53:37.537825+00	2026-06-27 12:53:57.108435+00	\N	2026-06-27 12:54:48.081752+00	2026-06-27 12:54:37.163975+00	\N	\N	\N	2026-06-27 12:53:37.537825+00	2026-06-27 12:54:48.081753+00
544281f9-ae82-4384-be89-47da17537467	337e0abf-857e-47a1-95f6-346f73d9bfe7	classic	LobbyMap	local	local-validation	127.0.0.1	7777	\N	\N	87aa71439552826294b307ba2c6a2c49f931855389e034c5a62c0602415d77a7	2026-06-27 18:56:01.078985+00	STOPPED	2026-06-27 12:56:01.078985+00	\N	\N	2026-06-27 12:56:02.195217+00	2026-06-27 12:56:01.078985+00	\N	\N	\N	2026-06-27 12:56:01.078985+00	2026-06-27 12:56:02.195218+00
fdeea3c7-ef68-433e-a087-a55167a027a7	0ef9a6b7-743e-4b00-8e4d-c03a2556d6a1	classic	LobbyMap	local	local-validation	127.0.0.1	7777	\N	\N	c8ceff5649e3237054f1675b986a0a21c64f697f9aa5947c364c668a828192b3	2026-06-27 18:57:28.206155+00	STOPPED	2026-06-27 12:57:28.206155+00	\N	\N	2026-06-27 12:57:29.313616+00	2026-06-27 12:57:28.206155+00	\N	\N	\N	2026-06-27 12:57:28.206155+00	2026-06-27 12:57:29.313617+00
3c955e54-2601-409b-a808-4b020efa8d2c	b2351b4b-54af-4536-85f2-fc609f1bf923	classic	LobbyMap	local	local-validation	127.0.0.1	7777	\N	\N	5d61553d02cf4ad0d67355a7835df56f26e5e25066f1c0b150aae166d222f271	2026-06-27 18:59:00.190677+00	STOPPED	2026-06-27 12:59:00.190677+00	2026-06-27 12:59:00.93118+00	\N	2026-06-27 12:59:01.359491+00	2026-06-27 12:59:00.931181+00	\N	\N	\N	2026-06-27 12:59:00.190677+00	2026-06-27 12:59:01.359492+00
43dcc115-12c9-4638-850c-ed73e1bf7961	797f201d-7d5f-4622-8c82-7e270105643f	classic	LobbyMap	local	local-validation	127.0.0.1	7777	\N	\N	13c7f9fb1408cf040fb4cc9619cb12a44233a0e170206b1af6753a84cee09076	2026-06-27 18:59:29.093162+00	STOPPED	2026-06-27 12:59:29.093162+00	2026-06-27 12:59:29.825117+00	\N	2026-06-27 13:00:20.48282+00	2026-06-27 13:00:09.906553+00	\N	\N	\N	2026-06-27 12:59:29.093162+00	2026-06-27 13:00:20.48282+00
\.


--
-- Data for Name: game_session; Type: TABLE DATA; Schema: public; Owner: game_app
--

COPY public.game_session (id, source_type, source_id, mode, map_id, region, status, server_id, server_ip, server_port, build_version, max_players, retry_count, created_at, allocated_at, started_at, ended_at, updated_at) FROM stdin;
0605b2be-f7bf-4a85-b117-31dc9d01d420	ROOM	df12fb57-d1eb-412b-a5c1-5c42c17afd4e	classic	DBA_Arena_Test	local	ALLOCATING_SERVER	365f99bd-1f56-42ba-b3de-980fa7227c6f	127.0.0.1	7777	\N	2	0	2026-06-27 12:22:07.411864+00	2026-06-27 12:22:07.464699+00	\N	\N	\N
f6cad132-fe4d-4346-bde7-5dac8cff72d4	ROOM	8724bd59-1c68-4c56-91b6-a764c2c70492	classic	LobbyMap	local	WAITING_PLAYERS	b3280610-f880-4238-8f63-a6700f413a34	127.0.0.1	7777	\N	2	0	2026-06-27 12:24:19.836116+00	2026-06-27 12:24:19.91729+00	\N	\N	2026-06-27 12:24:58.470569+00
1f8e87b3-0a17-4738-a715-c14528e0312a	ROOM	50d431b4-dcbf-46a1-9696-b22af5f3b650	classic	LobbyMap	local	WAITING_PLAYERS	d333ae3e-7174-4a4a-ac47-5d6ac711c718	127.0.0.1	7778	\N	2	0	2026-06-27 12:25:50.386253+00	2026-06-27 12:25:50.399883+00	\N	\N	2026-06-27 12:26:00.920462+00
310d2b11-6375-431a-b2e8-f50611a7ee31	ROOM	baa9872e-7b0d-47a3-8539-a8a4e15db4d1	classic	LobbyMap	local	WAITING_PLAYERS	5e7717c9-7ead-4c05-9f7e-3e3c8a8eba53	127.0.0.1	7778	\N	2	0	2026-06-27 12:27:51.064235+00	2026-06-27 12:27:51.07472+00	\N	\N	2026-06-27 12:28:00.386856+00
cda30148-0b53-4d09-80df-4c6d5e231995	ROOM	4785b975-e344-4998-aeaa-d7dae00597c8	classic	LobbyMap	local	WAITING_PLAYERS	c9fc1f04-a5af-4eb2-81c1-10ec868fb523	127.0.0.1	7778	\N	2	0	2026-06-27 12:29:08.983599+00	2026-06-27 12:29:08.994166+00	\N	\N	2026-06-27 12:29:17.781205+00
cf25c5b4-ccd4-4a92-83d2-04bf6121fb63	ROOM	2c93f3f7-1f61-44b4-99cd-b21d216eb677	classic	LobbyMap	local	WAITING_PLAYERS	ebb744ac-b00d-4986-bef9-d51559201cc4	127.0.0.1	7777	\N	2	0	2026-06-27 12:31:49.894532+00	2026-06-27 12:31:49.906519+00	\N	\N	2026-06-27 12:31:58.02387+00
d7acfafe-a374-4052-846a-e4abfaa04a32	ROOM	f09b5e23-b11e-4634-97fa-b4e9b68dfc8f	classic	LobbyMap	local	WAITING_PLAYERS	2f73c548-337b-434b-b5a8-59364d0b0e56	127.0.0.1	7777	\N	2	0	2026-06-27 12:33:54.004225+00	2026-06-27 12:33:54.013549+00	\N	\N	2026-06-27 12:34:03.490559+00
8a26d0ad-0fd1-4da7-b92f-946a33dae1ac	ROOM	99a17787-d342-4830-9374-c5ff8003484d	classic	LobbyMap	local	WAITING_PLAYERS	e9485dec-8ad7-44dd-bf99-22c619fa18a9	127.0.0.1	7777	\N	2	0	2026-06-27 12:52:29.328218+00	2026-06-27 12:52:29.33906+00	\N	\N	2026-06-27 12:53:00.818382+00
2c429a3b-972c-46fb-ab82-7c27bd98976d	ROOM	c96443e6-bb91-44eb-a306-85520aa47589	classic	LobbyMap	local	WAITING_PLAYERS	74655b9b-b2ed-4e1f-8140-8e448d40ebd6	127.0.0.1	7777	\N	2	0	2026-06-27 12:53:37.52232+00	2026-06-27 12:53:37.538311+00	\N	\N	2026-06-27 12:53:57.108439+00
337e0abf-857e-47a1-95f6-346f73d9bfe7	ROOM	db3869e7-7c42-4c79-aada-db27fad9eb54	classic	LobbyMap	local	ALLOCATING_SERVER	544281f9-ae82-4384-be89-47da17537467	127.0.0.1	7777	\N	2	0	2026-06-27 12:56:01.07049+00	2026-06-27 12:56:01.079572+00	\N	\N	2026-06-27 12:56:01.079572+00
0ef9a6b7-743e-4b00-8e4d-c03a2556d6a1	ROOM	c5775b9e-dee0-4827-b561-050cbb2d62e2	classic	LobbyMap	local	ALLOCATING_SERVER	fdeea3c7-ef68-433e-a087-a55167a027a7	127.0.0.1	7777	\N	2	0	2026-06-27 12:57:28.196478+00	2026-06-27 12:57:28.206751+00	\N	\N	2026-06-27 12:57:28.206752+00
b2351b4b-54af-4536-85f2-fc609f1bf923	ROOM	d23e3fb0-cee3-4d6e-aec2-f432d5905265	classic	LobbyMap	local	WAITING_PLAYERS	3c955e54-2601-409b-a808-4b020efa8d2c	127.0.0.1	7777	\N	2	0	2026-06-27 12:59:00.17957+00	2026-06-27 12:59:00.19174+00	\N	\N	2026-06-27 12:59:00.931184+00
797f201d-7d5f-4622-8c82-7e270105643f	ROOM	1dc7ddc4-8e26-4e44-a9d8-58b52a5c98eb	classic	LobbyMap	local	WAITING_PLAYERS	43dcc115-12c9-4638-850c-ed73e1bf7961	127.0.0.1	7777	\N	2	0	2026-06-27 12:59:29.084646+00	2026-06-27 12:59:29.093755+00	\N	\N	2026-06-27 12:59:29.82512+00
\.


--
-- Data for Name: inventory_item; Type: TABLE DATA; Schema: public; Owner: game_app
--

COPY public.inventory_item (id, player_id, item_id, quantity, expires_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: inventory_log; Type: TABLE DATA; Schema: public; Owner: game_app
--

COPY public.inventory_log (id, player_id, item_id, quantity_delta, quantity_before, quantity_after, reason, biz_type, biz_id, operator_id, created_at) FROM stdin;
\.


--
-- Data for Name: match_player_result; Type: TABLE DATA; Schema: public; Owner: game_app
--

COPY public.match_player_result (id, match_result_id, player_id, team, result, kills, deaths, assists, score, exp_delta, reward_json, created_at) FROM stdin;
\.


--
-- Data for Name: match_result; Type: TABLE DATA; Schema: public; Owner: game_app
--

COPY public.match_result (id, session_id, server_id, mode, map_id, duration_seconds, result_json, idempotency_key, created_at, "GameSessionId") FROM stdin;
\.


--
-- Data for Name: matchmaking_ticket; Type: TABLE DATA; Schema: public; Owner: game_app
--

COPY public.matchmaking_ticket (id, player_id, mode, region, mmr, status, matched_session_id, created_at, updated_at, cancelled_at, timeout_at) FROM stdin;
6565e9ce-9044-4f5f-b61d-5db2e3975827	1e228019-1521-479f-ad91-d927d688d1b2	classic	local	1000	CANCELLED	\N	2026-06-27 12:22:07.501326+00	\N	2026-06-27 12:22:07.530735+00	2026-06-27 12:27:07.501315+00
\.


--
-- Data for Name: order_record; Type: TABLE DATA; Schema: public; Owner: game_app
--

COPY public.order_record (id, player_id, platform, platform_order_id, status, amount, currency, item_json, created_at, paid_at, completed_at, updated_at) FROM stdin;
\.


--
-- Data for Name: player_character; Type: TABLE DATA; Schema: public; Owner: game_app
--

COPY public.player_character (id, player_id, character_name, zodiac, primary_element, five_camp, fixed_skill_group_id, core_attributes_json, level, is_selected, created_at, last_used_at, updated_at) FROM stdin;
384da9b4-a0fa-4a5e-8b9b-0399cfe55bfb	1e228019-1521-479f-ad91-d927d688d1b2	Hero_A_d3e6a74e	Rat	Water	East	Rat_Water_Default	{"defense": 40, "maxEnergy": 100, "maxHealth": 1800, "moveSpeed": 380, "attackPower": 100, "energyRegen": 10, "criticalRate": 0.05, "criticalMultiplier": 2}	1	t	2026-06-27 12:22:07.229858+00	2026-06-27 12:22:07.257225+00	2026-06-27 12:22:07.257225+00
95df8e8c-a8a9-43e8-b520-a2dd61e2407b	6e300941-1e1a-4e79-995c-067237eacf1e	Hero_B_d3e6a74e	Rat	Water	East	Rat_Water_Default	{"defense": 40, "maxEnergy": 100, "maxHealth": 1800, "moveSpeed": 380, "attackPower": 100, "energyRegen": 10, "criticalRate": 0.05, "criticalMultiplier": 2}	1	t	2026-06-27 12:22:07.270786+00	2026-06-27 12:22:07.275428+00	2026-06-27 12:22:07.275428+00
6dfa462e-1518-4ce8-968f-936f5b5a396e	4d426de5-588b-4ec3-abd6-e2d2e4e81fa0	UE_A_01fec64e	Rat	Water	East	Rat_Water_Default	{"defense": 40, "maxEnergy": 100, "maxHealth": 1800, "moveSpeed": 380, "attackPower": 100, "energyRegen": 10, "criticalRate": 0.05, "criticalMultiplier": 2}	1	t	2026-06-27 12:24:19.772726+00	2026-06-27 12:24:19.786487+00	2026-06-27 12:24:19.786487+00
dee7f0f2-e842-4649-8461-125bb9d7bf5c	8a67a6f9-59f6-4bb1-8141-9268ba831431	UE_B_01fec64e	Rat	Water	East	Rat_Water_Default	{"defense": 40, "maxEnergy": 100, "maxHealth": 1800, "moveSpeed": 380, "attackPower": 100, "energyRegen": 10, "criticalRate": 0.05, "criticalMultiplier": 2}	1	t	2026-06-27 12:24:19.794722+00	2026-06-27 12:24:19.79882+00	2026-06-27 12:24:19.79882+00
fcc2dcc7-3f7a-4d96-b51a-406496a7136b	61947706-bd0f-4fa6-9c86-230ece84ea88	UE_A_08ce1b7c	Rat	Water	East	Rat_Water_Default	{"defense": 40, "maxEnergy": 100, "maxHealth": 1800, "moveSpeed": 380, "attackPower": 100, "energyRegen": 10, "criticalRate": 0.05, "criticalMultiplier": 2}	1	t	2026-06-27 12:25:50.329891+00	2026-06-27 12:25:50.339284+00	2026-06-27 12:25:50.339284+00
8c0d12c0-e155-47a5-9d3c-de55ec845b81	d7bf41de-c6b4-437a-8491-977fe6aea811	UE_B_08ce1b7c	Rat	Water	East	Rat_Water_Default	{"defense": 40, "maxEnergy": 100, "maxHealth": 1800, "moveSpeed": 380, "attackPower": 100, "energyRegen": 10, "criticalRate": 0.05, "criticalMultiplier": 2}	1	t	2026-06-27 12:25:50.349619+00	2026-06-27 12:25:50.353534+00	2026-06-27 12:25:50.353534+00
dabd197f-e230-4cbc-acde-5bd7511286fb	b8b4b5eb-bd36-4f41-a6af-f2259d8dc7cf	UE_A_7d6480ca	Rat	Water	East	Rat_Water_Default	{"defense": 40, "maxEnergy": 100, "maxHealth": 1800, "moveSpeed": 380, "attackPower": 100, "energyRegen": 10, "criticalRate": 0.05, "criticalMultiplier": 2}	1	t	2026-06-27 12:27:51.023721+00	2026-06-27 12:27:51.029364+00	2026-06-27 12:27:51.029364+00
8105cca8-a20d-4ddf-ad74-87fa95c6114d	519ff91e-7648-4ecb-8508-804a17cd32ea	UE_B_7d6480ca	Rat	Water	East	Rat_Water_Default	{"defense": 40, "maxEnergy": 100, "maxHealth": 1800, "moveSpeed": 380, "attackPower": 100, "energyRegen": 10, "criticalRate": 0.05, "criticalMultiplier": 2}	1	t	2026-06-27 12:27:51.036808+00	2026-06-27 12:27:51.04059+00	2026-06-27 12:27:51.04059+00
d79bad9d-75d7-49f6-8a30-50d85d62e56f	67a2185d-5014-46e0-af5b-e796bebdbb55	UE_A_2971e0b2	Rat	Water	East	Rat_Water_Default	{"defense": 40, "maxEnergy": 100, "maxHealth": 1800, "moveSpeed": 380, "attackPower": 100, "energyRegen": 10, "criticalRate": 0.05, "criticalMultiplier": 2}	1	t	2026-06-27 12:29:08.941877+00	2026-06-27 12:29:08.94766+00	2026-06-27 12:29:08.94766+00
d882487a-5db2-4b08-8dc9-0452fd2a51be	66df9d43-220b-4ac9-8f02-2e3ce2b2842a	UE_B_2971e0b2	Rat	Water	East	Rat_Water_Default	{"defense": 40, "maxEnergy": 100, "maxHealth": 1800, "moveSpeed": 380, "attackPower": 100, "energyRegen": 10, "criticalRate": 0.05, "criticalMultiplier": 2}	1	t	2026-06-27 12:29:08.956003+00	2026-06-27 12:29:08.959591+00	2026-06-27 12:29:08.959591+00
31c19e8f-1060-484b-a946-1cc1c0e02314	3b05d8e1-a049-4e77-8cab-0c92e7add106	UE_A_eaf0b7b6	Rat	Water	East	Rat_Water_Default	{"defense": 40, "maxEnergy": 100, "maxHealth": 1800, "moveSpeed": 380, "attackPower": 100, "energyRegen": 10, "criticalRate": 0.05, "criticalMultiplier": 2}	1	t	2026-06-27 12:31:49.851641+00	2026-06-27 12:31:49.85821+00	2026-06-27 12:31:49.85821+00
f6998a61-4933-4547-8254-d81f64065579	aeb6861b-fa82-4ec2-856a-8ffc4177413a	UE_B_eaf0b7b6	Rat	Water	East	Rat_Water_Default	{"defense": 40, "maxEnergy": 100, "maxHealth": 1800, "moveSpeed": 380, "attackPower": 100, "energyRegen": 10, "criticalRate": 0.05, "criticalMultiplier": 2}	1	t	2026-06-27 12:31:49.868078+00	2026-06-27 12:31:49.871331+00	2026-06-27 12:31:49.871331+00
985dfbe0-d64a-4a21-8e9f-145a23961445	e212e732-f60a-4c68-9d85-3b9463f4b4bd	UE_A_98070539	Rat	Water	East	Rat_Water_Default	{"defense": 40, "maxEnergy": 100, "maxHealth": 1800, "moveSpeed": 380, "attackPower": 100, "energyRegen": 10, "criticalRate": 0.05, "criticalMultiplier": 2}	1	t	2026-06-27 12:33:53.958402+00	2026-06-27 12:33:53.964257+00	2026-06-27 12:33:53.964257+00
d1dd7c5d-dacb-400c-a768-cef9df440b67	2591522d-8365-49d2-ab2e-a65cb1d4685a	UE_B_98070539	Rat	Water	East	Rat_Water_Default	{"defense": 40, "maxEnergy": 100, "maxHealth": 1800, "moveSpeed": 380, "attackPower": 100, "energyRegen": 10, "criticalRate": 0.05, "criticalMultiplier": 2}	1	t	2026-06-27 12:33:53.972556+00	2026-06-27 12:33:53.975864+00	2026-06-27 12:33:53.975864+00
0dee1088-a76a-4d23-a7e0-6d26cb4fd2e0	662b7079-1ccc-4871-a9c1-1ffb3c34aa41	UE_A_e0d92880	Rat	Water	East	Rat_Water_Default	{"defense": 40, "maxEnergy": 100, "maxHealth": 1800, "moveSpeed": 380, "attackPower": 100, "energyRegen": 10, "criticalRate": 0.05, "criticalMultiplier": 2}	1	t	2026-06-27 12:52:29.283914+00	2026-06-27 12:52:29.293397+00	2026-06-27 12:52:29.293397+00
6adf976c-1fc9-4477-9d9f-9996ddd2827f	e560b151-f438-4480-9d81-1f08da21d896	UE_B_e0d92880	Rat	Water	East	Rat_Water_Default	{"defense": 40, "maxEnergy": 100, "maxHealth": 1800, "moveSpeed": 380, "attackPower": 100, "energyRegen": 10, "criticalRate": 0.05, "criticalMultiplier": 2}	1	t	2026-06-27 12:52:29.300319+00	2026-06-27 12:52:29.303746+00	2026-06-27 12:52:29.303746+00
a9847e7c-bf72-43ca-b1de-2b0d8e0d7043	bb6052a0-f333-478a-8d65-deb9964c98b0	UE_A_484a1bff	Rat	Water	East	Rat_Water_Default	{"defense": 40, "maxEnergy": 100, "maxHealth": 1800, "moveSpeed": 380, "attackPower": 100, "energyRegen": 10, "criticalRate": 0.05, "criticalMultiplier": 2}	1	t	2026-06-27 12:53:37.487766+00	2026-06-27 12:53:37.492992+00	2026-06-27 12:53:37.492992+00
122e86dc-b7a6-49a3-b774-a1cfd1efed3a	1d448a2c-c113-426e-af73-7f8d023306d6	UE_B_484a1bff	Rat	Water	East	Rat_Water_Default	{"defense": 40, "maxEnergy": 100, "maxHealth": 1800, "moveSpeed": 380, "attackPower": 100, "energyRegen": 10, "criticalRate": 0.05, "criticalMultiplier": 2}	1	t	2026-06-27 12:53:37.497713+00	2026-06-27 12:53:37.500131+00	2026-06-27 12:53:37.500131+00
7109f281-4921-4420-9810-bf6a602a3ac8	88f54bb1-054b-49bd-b150-aa6dd77d231c	UE_A_208fdc1d	Rat	Water	East	Rat_Water_Default	{"defense": 40, "maxEnergy": 100, "maxHealth": 1800, "moveSpeed": 380, "attackPower": 100, "energyRegen": 10, "criticalRate": 0.05, "criticalMultiplier": 2}	1	t	2026-06-27 12:56:01.029108+00	2026-06-27 12:56:01.034687+00	2026-06-27 12:56:01.034687+00
b106bbfa-8404-45c2-abc9-925dbc29b0cc	3067c73a-8eae-42db-a1b1-d1b504f04f83	UE_B_208fdc1d	Rat	Water	East	Rat_Water_Default	{"defense": 40, "maxEnergy": 100, "maxHealth": 1800, "moveSpeed": 380, "attackPower": 100, "energyRegen": 10, "criticalRate": 0.05, "criticalMultiplier": 2}	1	t	2026-06-27 12:56:01.044289+00	2026-06-27 12:56:01.047216+00	2026-06-27 12:56:01.047216+00
c80a6dbb-f4ef-4f3f-8729-be8d05488957	416b3f0e-a6e5-46c9-a5ab-0d6550052847	UE_A_ea2e387b	Rat	Water	East	Rat_Water_Default	{"defense": 40, "maxEnergy": 100, "maxHealth": 1800, "moveSpeed": 380, "attackPower": 100, "energyRegen": 10, "criticalRate": 0.05, "criticalMultiplier": 2}	1	t	2026-06-27 12:57:28.158516+00	2026-06-27 12:57:28.164238+00	2026-06-27 12:57:28.164238+00
4f024ba7-951d-4bc5-a5f6-41f9a66fd097	04846414-01f3-46f9-8a53-f253e0193d1c	UE_B_ea2e387b	Rat	Water	East	Rat_Water_Default	{"defense": 40, "maxEnergy": 100, "maxHealth": 1800, "moveSpeed": 380, "attackPower": 100, "energyRegen": 10, "criticalRate": 0.05, "criticalMultiplier": 2}	1	t	2026-06-27 12:57:28.170127+00	2026-06-27 12:57:28.17354+00	2026-06-27 12:57:28.17354+00
7d5a1e73-ceb8-4810-ad6f-8dcd3365fe0c	d2220f7d-df2c-4d82-aeea-9307bc803517	UE_A_f7861350	Rat	Water	East	Rat_Water_Default	{"defense": 40, "maxEnergy": 100, "maxHealth": 1800, "moveSpeed": 380, "attackPower": 100, "energyRegen": 10, "criticalRate": 0.05, "criticalMultiplier": 2}	1	t	2026-06-27 12:59:00.140178+00	2026-06-27 12:59:00.146453+00	2026-06-27 12:59:00.146453+00
ce2a4920-ee21-4b69-95f9-3566113307ab	daccbc4e-c950-4845-a8b6-40c15f66796d	UE_B_f7861350	Rat	Water	East	Rat_Water_Default	{"defense": 40, "maxEnergy": 100, "maxHealth": 1800, "moveSpeed": 380, "attackPower": 100, "energyRegen": 10, "criticalRate": 0.05, "criticalMultiplier": 2}	1	t	2026-06-27 12:59:00.153429+00	2026-06-27 12:59:00.156409+00	2026-06-27 12:59:00.156409+00
c5470ad0-2931-4773-801d-788e3a63aaeb	d508645d-709f-4ef7-9875-d483c124c25d	UE_A_7bb2d9c1	Rat	Water	East	Rat_Water_Default	{"defense": 40, "maxEnergy": 100, "maxHealth": 1800, "moveSpeed": 380, "attackPower": 100, "energyRegen": 10, "criticalRate": 0.05, "criticalMultiplier": 2}	1	t	2026-06-27 12:59:29.046845+00	2026-06-27 12:59:29.052864+00	2026-06-27 12:59:29.052864+00
4de96ebb-f9a0-4554-aedc-ac2960671734	5a05cf51-86bb-4eb9-bcb1-6e337375c6c9	UE_B_7bb2d9c1	Rat	Water	East	Rat_Water_Default	{"defense": 40, "maxEnergy": 100, "maxHealth": 1800, "moveSpeed": 380, "attackPower": 100, "energyRegen": 10, "criticalRate": 0.05, "criticalMultiplier": 2}	1	t	2026-06-27 12:59:29.05877+00	2026-06-27 12:59:29.061616+00	2026-06-27 12:59:29.061616+00
\.


--
-- Data for Name: player_event_log; Type: TABLE DATA; Schema: public; Owner: game_app
--

COPY public.player_event_log (id, player_id, event_type, payload_json, created_at) FROM stdin;
\.


--
-- Data for Name: player_feedback; Type: TABLE DATA; Schema: public; Owner: game_app
--

COPY public.player_feedback (id, player_id, nickname, email, feedback_type, title, content, status, created_at, updated_at, handled_by, handled_at, handle_note) FROM stdin;
\.


--
-- Data for Name: player_identity; Type: TABLE DATA; Schema: public; Owner: game_app
--

COPY public.player_identity (id, account_id, player_id, display_name, created_at) FROM stdin;
c688786b-27e5-4774-a5a2-467ce1e41e6f	4b16b960-f07a-40e1-a6ec-176a188e0dd1	1e228019-1521-479f-ad91-d927d688d1b2	Player_49af2d97	2026-06-27 12:22:06.906743+00
798d3759-aa0f-4340-8fe9-5e79db9ce157	50777d4f-69c4-494b-a6a8-f636b0e9cd6d	6e300941-1e1a-4e79-995c-067237eacf1e	Player_30c3bc66	2026-06-27 12:22:07.108316+00
5d148110-7132-4ada-847f-148d731e21ca	4d3230fd-98b2-4744-9eb3-4c36b976d456	4d426de5-588b-4ec3-abd6-e2d2e4e81fa0	Player_655bf681	2026-06-27 12:24:19.656007+00
63d04038-31ff-4a62-b9a5-6068b22c998b	9140cd6e-36df-47fe-a8a4-87d05d2ea139	8a67a6f9-59f6-4bb1-8141-9268ba831431	Player_6514d8f7	2026-06-27 12:24:19.734238+00
0933d0b9-e2f4-4a87-aaef-edc4639987a0	c02f78ba-d494-4766-b29c-5c31106196cd	61947706-bd0f-4fa6-9c86-230ece84ea88	Player_7564ca16	2026-06-27 12:25:50.185595+00
ec3c4c94-4ce5-45e5-b34b-a83a768a8dc9	508d668e-314a-4cd8-b1be-05ccced44e1e	d7bf41de-c6b4-437a-8491-977fe6aea811	Player_ce6e3973	2026-06-27 12:25:50.283806+00
f4be1bec-9fc9-478e-9b76-78e4cc540511	3300e0b3-c7f7-47ef-8ac1-f8f313970e8d	b8b4b5eb-bd36-4f41-a6af-f2259d8dc7cf	Player_7e87708e	2026-06-27 12:27:50.923223+00
3c12ae09-aa04-4098-acf3-67468fd91558	61bfafcb-ff17-44e6-9edd-5034a9d31084	519ff91e-7648-4ecb-8508-804a17cd32ea	Player_667b4e89	2026-06-27 12:27:50.995435+00
2d45eacd-c156-4720-9ac6-627ef0b86539	870e21fb-7265-4c8e-a224-ab9dd615d171	67a2185d-5014-46e0-af5b-e796bebdbb55	Player_2b80a31b	2026-06-27 12:29:08.819165+00
de67155b-93aa-401a-920b-b80e16499b87	359e7001-7e4e-4869-94e9-6dd22b77959d	66df9d43-220b-4ac9-8f02-2e3ce2b2842a	Player_6ce732ce	2026-06-27 12:29:08.900037+00
439386fd-d381-4381-9b98-466cc1136efb	1561ba88-1bf0-41da-b40c-0245b5448151	3b05d8e1-a049-4e77-8cab-0c92e7add106	Player_4af6ddc2	2026-06-27 12:31:49.723141+00
a32e4149-8bd6-4db0-bd0b-4f60db813fe4	28193923-dd13-4ff5-983c-3da2272616ef	aeb6861b-fa82-4ec2-856a-8ffc4177413a	Player_2820490a	2026-06-27 12:31:49.816428+00
7251aad9-c088-40eb-846f-19e9c8b3a135	fb3159b9-69cf-49c3-a324-3547b3658cd6	e212e732-f60a-4c68-9d85-3b9463f4b4bd	Player_6bf40575	2026-06-27 12:33:53.821972+00
b41dfa73-4d43-4a73-8c13-dcfc298e470a	e3807e41-2c00-412b-91ba-8bccb152cb07	2591522d-8365-49d2-ab2e-a65cb1d4685a	Player_116cd11f	2026-06-27 12:33:53.919919+00
b4dc179c-a8b4-4175-afe3-6f1f02486f13	b1d0e11e-c572-4d0f-9a2c-9a1fd5028c2b	662b7079-1ccc-4871-a9c1-1ffb3c34aa41	Player_5aea5796	2026-06-27 12:52:29.16736+00
7173ba94-1f70-4e34-8477-73712847f237	35538fb3-d1da-466f-afbe-4592afeb8efb	e560b151-f438-4480-9d81-1f08da21d896	Player_c00f6bda	2026-06-27 12:52:29.248186+00
ef666155-8172-48ab-a4d2-a6a3f6284cef	9697b5fd-31f5-417f-b384-83c721bb0489	bb6052a0-f333-478a-8d65-deb9964c98b0	Player_f18e45c4	2026-06-27 12:53:37.399952+00
2014d14a-127f-45a1-85f3-ab42018962a5	66406375-f377-463e-b17f-77bf6bac43eb	1d448a2c-c113-426e-af73-7f8d023306d6	Player_3bd713ca	2026-06-27 12:53:37.460083+00
d2dbf729-0c0b-4399-956e-03c8b49d4545	e09a7963-5996-4145-9a8e-6ffad121f3a6	88f54bb1-054b-49bd-b150-aa6dd77d231c	Player_1c1a1168	2026-06-27 12:56:00.932416+00
588f226c-d57a-401b-8719-fc57f493d26b	7c02b31c-ddca-4ea6-a6a0-c7e0a492afa8	3067c73a-8eae-42db-a1b1-d1b504f04f83	Player_a516eb77	2026-06-27 12:56:00.997675+00
d526836f-085a-4d21-bbe1-9648bc99607d	d812d3d9-fafb-4e39-a3e2-e5e0a8f617b5	416b3f0e-a6e5-46c9-a5ab-0d6550052847	Player_6a6c33f2	2026-06-27 12:57:28.068531+00
7b739eba-20f3-4003-a5a7-8066af972f60	007acf25-7d1a-45c7-aa26-46da18acca34	04846414-01f3-46f9-8a53-f253e0193d1c	Player_c15fdca7	2026-06-27 12:57:28.130086+00
d19c3cbf-310a-4cd1-8659-6b01abc0a34c	640077ad-1fd9-4f78-b215-bfa348010b4a	d2220f7d-df2c-4d82-aeea-9307bc803517	Player_75aa1220	2026-06-27 12:59:00.042482+00
8e0b4c55-1047-4978-8ec7-c72596125358	2d4e931f-5364-431b-9904-6df2c4c2eecb	daccbc4e-c950-4845-a8b6-40c15f66796d	Player_96397af7	2026-06-27 12:59:00.108427+00
992e07a6-7902-49b1-9799-81bdff3dbb26	bd4d705a-ccd9-453b-8d47-92215545c924	d508645d-709f-4ef7-9875-d483c124c25d	Player_ceb4d846	2026-06-27 12:59:28.958315+00
e52c269c-aa85-44d7-a7a6-ef29595decf2	3970fbed-f3a0-4e04-bf3d-a4334b24c11d	5a05cf51-86bb-4eb9-bcb1-6e337375c6c9	Player_6c42e291	2026-06-27 12:59:29.020414+00
\.


--
-- Data for Name: player_profile; Type: TABLE DATA; Schema: public; Owner: game_app
--

COPY public.player_profile (player_id, nickname, avatar, level, exp, nickname_updated_at, created_at, last_login_at, updated_at) FROM stdin;
1e228019-1521-479f-ad91-d927d688d1b2	Player_49af2d97	\N	1	0	\N	2026-06-27 12:22:06.906874+00	\N	\N
6e300941-1e1a-4e79-995c-067237eacf1e	Player_30c3bc66	\N	1	0	\N	2026-06-27 12:22:07.108316+00	\N	\N
4d426de5-588b-4ec3-abd6-e2d2e4e81fa0	Player_655bf681	\N	1	0	\N	2026-06-27 12:24:19.656008+00	\N	\N
8a67a6f9-59f6-4bb1-8141-9268ba831431	Player_6514d8f7	\N	1	0	\N	2026-06-27 12:24:19.734238+00	\N	\N
61947706-bd0f-4fa6-9c86-230ece84ea88	Player_7564ca16	\N	1	0	\N	2026-06-27 12:25:50.185596+00	\N	\N
d7bf41de-c6b4-437a-8491-977fe6aea811	Player_ce6e3973	\N	1	0	\N	2026-06-27 12:25:50.283807+00	\N	\N
b8b4b5eb-bd36-4f41-a6af-f2259d8dc7cf	Player_7e87708e	\N	1	0	\N	2026-06-27 12:27:50.923224+00	\N	\N
519ff91e-7648-4ecb-8508-804a17cd32ea	Player_667b4e89	\N	1	0	\N	2026-06-27 12:27:50.995436+00	\N	\N
67a2185d-5014-46e0-af5b-e796bebdbb55	Player_2b80a31b	\N	1	0	\N	2026-06-27 12:29:08.819166+00	\N	\N
66df9d43-220b-4ac9-8f02-2e3ce2b2842a	Player_6ce732ce	\N	1	0	\N	2026-06-27 12:29:08.900038+00	\N	\N
3b05d8e1-a049-4e77-8cab-0c92e7add106	Player_4af6ddc2	\N	1	0	\N	2026-06-27 12:31:49.723142+00	\N	\N
aeb6861b-fa82-4ec2-856a-8ffc4177413a	Player_2820490a	\N	1	0	\N	2026-06-27 12:31:49.816428+00	\N	\N
e212e732-f60a-4c68-9d85-3b9463f4b4bd	Player_6bf40575	\N	1	0	\N	2026-06-27 12:33:53.821973+00	\N	\N
2591522d-8365-49d2-ab2e-a65cb1d4685a	Player_116cd11f	\N	1	0	\N	2026-06-27 12:33:53.919919+00	\N	\N
662b7079-1ccc-4871-a9c1-1ffb3c34aa41	Player_5aea5796	\N	1	0	\N	2026-06-27 12:52:29.167361+00	\N	\N
e560b151-f438-4480-9d81-1f08da21d896	Player_c00f6bda	\N	1	0	\N	2026-06-27 12:52:29.248186+00	\N	\N
bb6052a0-f333-478a-8d65-deb9964c98b0	Player_f18e45c4	\N	1	0	\N	2026-06-27 12:53:37.399953+00	\N	\N
1d448a2c-c113-426e-af73-7f8d023306d6	Player_3bd713ca	\N	1	0	\N	2026-06-27 12:53:37.460084+00	\N	\N
88f54bb1-054b-49bd-b150-aa6dd77d231c	Player_1c1a1168	\N	1	0	\N	2026-06-27 12:56:00.932417+00	\N	\N
3067c73a-8eae-42db-a1b1-d1b504f04f83	Player_a516eb77	\N	1	0	\N	2026-06-27 12:56:00.997676+00	\N	\N
416b3f0e-a6e5-46c9-a5ab-0d6550052847	Player_6a6c33f2	\N	1	0	\N	2026-06-27 12:57:28.068532+00	\N	\N
04846414-01f3-46f9-8a53-f253e0193d1c	Player_c15fdca7	\N	1	0	\N	2026-06-27 12:57:28.130087+00	\N	\N
d2220f7d-df2c-4d82-aeea-9307bc803517	Player_75aa1220	\N	1	0	\N	2026-06-27 12:59:00.042483+00	\N	\N
daccbc4e-c950-4845-a8b6-40c15f66796d	Player_96397af7	\N	1	0	\N	2026-06-27 12:59:00.108427+00	\N	\N
d508645d-709f-4ef7-9875-d483c124c25d	Player_ceb4d846	\N	1	0	\N	2026-06-27 12:59:28.958316+00	\N	\N
5a05cf51-86bb-4eb9-bcb1-6e337375c6c9	Player_6c42e291	\N	1	0	\N	2026-06-27 12:59:29.020415+00	\N	\N
\.


--
-- Data for Name: player_session; Type: TABLE DATA; Schema: public; Owner: game_app
--

COPY public.player_session (id, game_session_id, player_id, team, slot_index, status, session_token_hash, session_token_expires_at, reconnect_token_hash, reconnect_token_expires_at, joined_at, left_at, created_at) FROM stdin;
48dff285-dc95-44fa-9a7a-c9bbeecc4805	0605b2be-f7bf-4a85-b117-31dc9d01d420	1e228019-1521-479f-ad91-d927d688d1b2	\N	0	CREATED	4bfc5f734b4ce5c77934ea2b5e1551d53767d549ae440de853253f5e9f9fa2f0	2026-06-27 12:32:07.478965+00	\N	\N	\N	\N	2026-06-27 12:22:07.43118+00
afc1172e-5dea-4428-9b51-b061fb591748	0605b2be-f7bf-4a85-b117-31dc9d01d420	6e300941-1e1a-4e79-995c-067237eacf1e	\N	1	CREATED	783ab468799ea84a7adeb2de09d05873fc63fbf9021995e1a9806cc36189fcad	2026-06-27 12:32:07.489392+00	\N	\N	\N	\N	2026-06-27 12:22:07.440259+00
71f9bdd2-81b1-4b16-a069-f50821ddbf9f	f6cad132-fe4d-4346-bde7-5dac8cff72d4	4d426de5-588b-4ec3-abd6-e2d2e4e81fa0	\N	0	CREATED	819bc4b8f9162b3f71058837f5e325d3d6a370672ed0829706c4665e06c0c994	2026-06-27 14:24:19.837029+00	\N	\N	\N	\N	2026-06-27 12:24:19.837031+00
869c9e43-298a-44fe-925f-4ed10241ef1e	f6cad132-fe4d-4346-bde7-5dac8cff72d4	8a67a6f9-59f6-4bb1-8141-9268ba831431	\N	1	CREATED	65f5c6d703f743742591cb2b63640602d03e8cd57b993c9e6c8768744930478a	2026-06-27 14:24:19.83714+00	\N	\N	\N	\N	2026-06-27 12:24:19.83714+00
8273a7d5-49c5-4625-98d5-bf00e0f78cdb	1f8e87b3-0a17-4738-a715-c14528e0312a	d7bf41de-c6b4-437a-8491-977fe6aea811	\N	1	CREATED	e3319e513324f86c49b65b0fec8db2eef37d6a8747eec40f9ca9ef43e13871c7	2026-06-27 14:25:50.387+00	\N	\N	\N	\N	2026-06-27 12:25:50.387+00
b24b7868-4634-4ed0-a13c-c8170ff979e9	1f8e87b3-0a17-4738-a715-c14528e0312a	61947706-bd0f-4fa6-9c86-230ece84ea88	\N	0	CREATED	af3778a503768c1efba5227c328c75756b33799f61121ad9d4bac9abe247c0dd	2026-06-27 14:25:50.386877+00	\N	\N	\N	\N	2026-06-27 12:25:50.386878+00
0b0053d8-8c8a-4760-938f-605868743a4a	310d2b11-6375-431a-b2e8-f50611a7ee31	b8b4b5eb-bd36-4f41-a6af-f2259d8dc7cf	\N	0	CREATED	a6ee65c1b978838fb75a0f5f2cd655e1a1058906bf00850212852dd695db4604	2026-06-27 12:38:01.406296+00	\N	\N	\N	\N	2026-06-27 12:27:51.065221+00
84f7e37b-7bd0-4256-857d-04541442a693	310d2b11-6375-431a-b2e8-f50611a7ee31	519ff91e-7648-4ecb-8508-804a17cd32ea	\N	1	CREATED	e4240114428feafea10b91dd906f0fba32ba5b4fa26dc468d7712f16cacdfe4f	2026-06-27 12:38:01.412232+00	\N	\N	\N	\N	2026-06-27 12:27:51.065179+00
d907ca69-62c0-4b2e-b051-1847e1c3e9f7	cda30148-0b53-4d09-80df-4c6d5e231995	67a2185d-5014-46e0-af5b-e796bebdbb55	\N	0	CREATED	660aa0bed41b79d7730e1a4771445b0278feed3160fd091d50370eff1ad9ffe3	2026-06-27 12:39:18.260149+00	\N	\N	\N	\N	2026-06-27 12:29:08.984113+00
3dc6a1e1-49a9-48c3-8b3b-801895609021	cda30148-0b53-4d09-80df-4c6d5e231995	66df9d43-220b-4ac9-8f02-2e3ce2b2842a	\N	1	CREATED	1857072096bcf316cd04015a404305ada417a434eeaa35cc4d6a92898f211286	2026-06-27 12:39:18.264442+00	\N	\N	\N	\N	2026-06-27 12:29:08.984081+00
7c863c7d-53b4-4b49-8ebe-81a2df819bf2	cf25c5b4-ccd4-4a92-83d2-04bf6121fb63	3b05d8e1-a049-4e77-8cab-0c92e7add106	\N	0	JOINED	cb4f19388cd6114f3a5bc863c0d3ed27147e56093e5bf750049074d2f55188cd	2026-06-27 12:41:58.204262+00	\N	\N	2026-06-27 12:32:09.718297+00	\N	2026-06-27 12:31:49.895063+00
e2066c67-0cee-4fe2-b7e6-8e154ba66096	cf25c5b4-ccd4-4a92-83d2-04bf6121fb63	aeb6861b-fa82-4ec2-856a-8ffc4177413a	\N	1	JOINED	70b4f01f2cb963ea6173a6571ac1035d72273059604410c78403f0ea87f8f37e	2026-06-27 12:41:58.213661+00	\N	\N	2026-06-27 12:32:14.126232+00	\N	2026-06-27 12:31:49.895134+00
b6a300c7-9dc2-4ea4-af5c-043efeb57c13	d7acfafe-a374-4052-846a-e4abfaa04a32	e212e732-f60a-4c68-9d85-3b9463f4b4bd	\N	0	JOINED	6d9a86846e8d1f6926679b1bed3bcd20582add13c32887f2f6b1280c16cc8f37	2026-06-27 12:44:04.353266+00	\N	\N	2026-06-27 12:34:14.986072+00	\N	2026-06-27 12:33:54.004787+00
42d649dc-ffa2-475d-8dae-ba0f26407a1a	d7acfafe-a374-4052-846a-e4abfaa04a32	2591522d-8365-49d2-ab2e-a65cb1d4685a	\N	1	JOINED	5f36db56b778cefaa07387fbcbf9f19f67c90cd2419d11f7d4eb6053fd95222f	2026-06-27 12:44:04.362051+00	\N	\N	2026-06-27 12:34:20.900724+00	\N	2026-06-27 12:33:54.004741+00
5d3d0c6b-cd42-4771-9282-c3a063f3aa5a	8a26d0ad-0fd1-4da7-b92f-946a33dae1ac	662b7079-1ccc-4871-a9c1-1ffb3c34aa41	\N	0	CREATED	f66131ad7b93df60799b875c7c59910811f7fc74a3da46fd0c26718a98d0092e	2026-06-27 14:52:29.328672+00	\N	\N	\N	\N	2026-06-27 12:52:29.328674+00
8986c32c-ae85-4eff-beca-d025545f5ba3	8a26d0ad-0fd1-4da7-b92f-946a33dae1ac	e560b151-f438-4480-9d81-1f08da21d896	\N	1	CREATED	89f67dcd02a5f627fb52d98720bd87918b7e22784a3f16a6e050cfbab9026cc4	2026-06-27 14:52:29.328734+00	\N	\N	\N	\N	2026-06-27 12:52:29.328734+00
6bd9319a-020f-46ca-895c-a51d91445230	2c429a3b-972c-46fb-ab82-7c27bd98976d	bb6052a0-f333-478a-8d65-deb9964c98b0	\N	0	JOINED	469275bb898f8ad79c8ee1157b32016ddd448f705e6a665d0493e79c926dca3b	2026-06-27 13:03:57.931249+00	\N	\N	2026-06-27 12:54:07.757616+00	\N	2026-06-27 12:53:37.522875+00
65653495-0db5-4dc0-994e-7d184da60ef1	2c429a3b-972c-46fb-ab82-7c27bd98976d	1d448a2c-c113-426e-af73-7f8d023306d6	\N	1	JOINED	c41e59502b8c4472806b16ac2186415f22f687fde13a6c793054d0a694a08e06	2026-06-27 13:03:57.936202+00	\N	\N	2026-06-27 12:54:15.941482+00	\N	2026-06-27 12:53:37.522851+00
3c61f073-1295-40d7-81cc-f764b559ef57	337e0abf-857e-47a1-95f6-346f73d9bfe7	88f54bb1-054b-49bd-b150-aa6dd77d231c	\N	0	CREATED	3852a1516038e775cf24c27c5784b84287a37f678a8bfd00766cc72d83f56245	2026-06-27 14:56:01.070964+00	\N	\N	\N	\N	2026-06-27 12:56:01.070964+00
5d8baa4d-7b2e-4579-bda1-d77dd99e958c	337e0abf-857e-47a1-95f6-346f73d9bfe7	3067c73a-8eae-42db-a1b1-d1b504f04f83	\N	1	CREATED	b7b6b198a9084f7a777505ba2a3d11251ec3cde7a4005aa9cefc18c028d91f3e	2026-06-27 14:56:01.070935+00	\N	\N	\N	\N	2026-06-27 12:56:01.070936+00
1111c914-6ad9-48e9-88f7-8ace72d96d48	0ef9a6b7-743e-4b00-8e4d-c03a2556d6a1	04846414-01f3-46f9-8a53-f253e0193d1c	\N	1	CREATED	e62dcd6a30fdf86707a7fea6b01463c33e407303652943aed8d0d598da2336b4	2026-06-27 14:57:28.197065+00	\N	\N	\N	\N	2026-06-27 12:57:28.197066+00
5c6de885-f834-496f-b63e-aff8f15a03e1	0ef9a6b7-743e-4b00-8e4d-c03a2556d6a1	416b3f0e-a6e5-46c9-a5ab-0d6550052847	\N	0	CREATED	c7653fca802314c41a0b980dcb140c269a65ff646e8d1644b0d56c3595c7dce6	2026-06-27 14:57:28.197109+00	\N	\N	\N	\N	2026-06-27 12:57:28.197109+00
2878371b-16b3-4380-9772-8991d621c582	b2351b4b-54af-4536-85f2-fc609f1bf923	daccbc4e-c950-4845-a8b6-40c15f66796d	\N	1	CREATED	a42f14ff3af7d59d470d8338fb13ce8c6ebae1437ea6823de6c701a663369153	2026-06-27 14:59:00.180056+00	\N	\N	\N	\N	2026-06-27 12:59:00.180056+00
2db5a51f-ce7b-4884-8377-a94640b30383	b2351b4b-54af-4536-85f2-fc609f1bf923	d2220f7d-df2c-4d82-aeea-9307bc803517	\N	0	CREATED	af0884e9c3f3cb7bbd3d56bd6d643628fe1f94a1757e28aca15818239782cf84	2026-06-27 14:59:00.180029+00	\N	\N	\N	\N	2026-06-27 12:59:00.180032+00
351d212b-a5b8-455e-adac-e06c57f8d67b	797f201d-7d5f-4622-8c82-7e270105643f	d508645d-709f-4ef7-9875-d483c124c25d	\N	0	JOINED	d34caacc380dd994e19c0bf38b7ecc39821596805aff6b45071161ad4ac1a1d0	2026-06-27 13:09:30.226611+00	\N	\N	2026-06-27 12:59:40.872224+00	\N	2026-06-27 12:59:29.085257+00
e7c54220-a0b0-47b3-836c-97383321c004	797f201d-7d5f-4622-8c82-7e270105643f	5a05cf51-86bb-4eb9-bcb1-6e337375c6c9	\N	1	JOINED	c861c9a44d14dc21da80c5a0893355aaf88312fe7058538298730ca72c9c8a49	2026-06-27 13:09:30.238598+00	\N	\N	2026-06-27 12:59:45.936773+00	\N	2026-06-27 12:59:29.085231+00
\.


--
-- Data for Name: player_settings; Type: TABLE DATA; Schema: public; Owner: game_app
--

COPY public.player_settings (player_id, settings_json, updated_at) FROM stdin;
1e228019-1521-479f-ad91-d927d688d1b2	{}	2026-06-27 12:22:06.906964+00
6e300941-1e1a-4e79-995c-067237eacf1e	{}	2026-06-27 12:22:07.108317+00
4d426de5-588b-4ec3-abd6-e2d2e4e81fa0	{}	2026-06-27 12:24:19.656009+00
8a67a6f9-59f6-4bb1-8141-9268ba831431	{}	2026-06-27 12:24:19.734239+00
61947706-bd0f-4fa6-9c86-230ece84ea88	{}	2026-06-27 12:25:50.185597+00
d7bf41de-c6b4-437a-8491-977fe6aea811	{}	2026-06-27 12:25:50.283807+00
b8b4b5eb-bd36-4f41-a6af-f2259d8dc7cf	{}	2026-06-27 12:27:50.923225+00
519ff91e-7648-4ecb-8508-804a17cd32ea	{}	2026-06-27 12:27:50.995436+00
67a2185d-5014-46e0-af5b-e796bebdbb55	{}	2026-06-27 12:29:08.819167+00
66df9d43-220b-4ac9-8f02-2e3ce2b2842a	{}	2026-06-27 12:29:08.900038+00
3b05d8e1-a049-4e77-8cab-0c92e7add106	{}	2026-06-27 12:31:49.723143+00
aeb6861b-fa82-4ec2-856a-8ffc4177413a	{}	2026-06-27 12:31:49.816429+00
e212e732-f60a-4c68-9d85-3b9463f4b4bd	{}	2026-06-27 12:33:53.821973+00
2591522d-8365-49d2-ab2e-a65cb1d4685a	{}	2026-06-27 12:33:53.91992+00
662b7079-1ccc-4871-a9c1-1ffb3c34aa41	{}	2026-06-27 12:52:29.167362+00
e560b151-f438-4480-9d81-1f08da21d896	{}	2026-06-27 12:52:29.248187+00
bb6052a0-f333-478a-8d65-deb9964c98b0	{}	2026-06-27 12:53:37.399953+00
1d448a2c-c113-426e-af73-7f8d023306d6	{}	2026-06-27 12:53:37.460084+00
88f54bb1-054b-49bd-b150-aa6dd77d231c	{}	2026-06-27 12:56:00.932417+00
3067c73a-8eae-42db-a1b1-d1b504f04f83	{}	2026-06-27 12:56:00.997676+00
416b3f0e-a6e5-46c9-a5ab-0d6550052847	{}	2026-06-27 12:57:28.068533+00
04846414-01f3-46f9-8a53-f253e0193d1c	{}	2026-06-27 12:57:28.130087+00
d2220f7d-df2c-4d82-aeea-9307bc803517	{}	2026-06-27 12:59:00.042483+00
daccbc4e-c950-4845-a8b6-40c15f66796d	{}	2026-06-27 12:59:00.108427+00
d508645d-709f-4ef7-9875-d483c124c25d	{}	2026-06-27 12:59:28.958317+00
5a05cf51-86bb-4eb9-bcb1-6e337375c6c9	{}	2026-06-27 12:59:29.020415+00
\.


--
-- Data for Name: player_statistics; Type: TABLE DATA; Schema: public; Owner: game_app
--

COPY public.player_statistics (player_id, total_matches, wins, losses, draws, kills, deaths, assists, score, play_time_seconds, updated_at) FROM stdin;
1e228019-1521-479f-ad91-d927d688d1b2	0	0	0	0	0	0	0	0	0	2026-06-27 12:22:06.906939+00
6e300941-1e1a-4e79-995c-067237eacf1e	0	0	0	0	0	0	0	0	0	2026-06-27 12:22:07.108317+00
4d426de5-588b-4ec3-abd6-e2d2e4e81fa0	0	0	0	0	0	0	0	0	0	2026-06-27 12:24:19.656008+00
8a67a6f9-59f6-4bb1-8141-9268ba831431	0	0	0	0	0	0	0	0	0	2026-06-27 12:24:19.734239+00
61947706-bd0f-4fa6-9c86-230ece84ea88	0	0	0	0	0	0	0	0	0	2026-06-27 12:25:50.185596+00
d7bf41de-c6b4-437a-8491-977fe6aea811	0	0	0	0	0	0	0	0	0	2026-06-27 12:25:50.283807+00
b8b4b5eb-bd36-4f41-a6af-f2259d8dc7cf	0	0	0	0	0	0	0	0	0	2026-06-27 12:27:50.923224+00
519ff91e-7648-4ecb-8508-804a17cd32ea	0	0	0	0	0	0	0	0	0	2026-06-27 12:27:50.995436+00
67a2185d-5014-46e0-af5b-e796bebdbb55	0	0	0	0	0	0	0	0	0	2026-06-27 12:29:08.819166+00
66df9d43-220b-4ac9-8f02-2e3ce2b2842a	0	0	0	0	0	0	0	0	0	2026-06-27 12:29:08.900038+00
3b05d8e1-a049-4e77-8cab-0c92e7add106	0	0	0	0	0	0	0	0	0	2026-06-27 12:31:49.723142+00
aeb6861b-fa82-4ec2-856a-8ffc4177413a	0	0	0	0	0	0	0	0	0	2026-06-27 12:31:49.816429+00
e212e732-f60a-4c68-9d85-3b9463f4b4bd	0	0	0	0	0	0	0	0	0	2026-06-27 12:33:53.821973+00
2591522d-8365-49d2-ab2e-a65cb1d4685a	0	0	0	0	0	0	0	0	0	2026-06-27 12:33:53.91992+00
662b7079-1ccc-4871-a9c1-1ffb3c34aa41	0	0	0	0	0	0	0	0	0	2026-06-27 12:52:29.167362+00
e560b151-f438-4480-9d81-1f08da21d896	0	0	0	0	0	0	0	0	0	2026-06-27 12:52:29.248187+00
bb6052a0-f333-478a-8d65-deb9964c98b0	0	0	0	0	0	0	0	0	0	2026-06-27 12:53:37.399953+00
1d448a2c-c113-426e-af73-7f8d023306d6	0	0	0	0	0	0	0	0	0	2026-06-27 12:53:37.460084+00
88f54bb1-054b-49bd-b150-aa6dd77d231c	0	0	0	0	0	0	0	0	0	2026-06-27 12:56:00.932417+00
3067c73a-8eae-42db-a1b1-d1b504f04f83	0	0	0	0	0	0	0	0	0	2026-06-27 12:56:00.997676+00
416b3f0e-a6e5-46c9-a5ab-0d6550052847	0	0	0	0	0	0	0	0	0	2026-06-27 12:57:28.068533+00
04846414-01f3-46f9-8a53-f253e0193d1c	0	0	0	0	0	0	0	0	0	2026-06-27 12:57:28.130087+00
d2220f7d-df2c-4d82-aeea-9307bc803517	0	0	0	0	0	0	0	0	0	2026-06-27 12:59:00.042483+00
daccbc4e-c950-4845-a8b6-40c15f66796d	0	0	0	0	0	0	0	0	0	2026-06-27 12:59:00.108427+00
d508645d-709f-4ef7-9875-d483c124c25d	0	0	0	0	0	0	0	0	0	2026-06-27 12:59:28.958316+00
5a05cf51-86bb-4eb9-bcb1-6e337375c6c9	0	0	0	0	0	0	0	0	0	2026-06-27 12:59:29.020415+00
\.


--
-- Data for Name: player_unlock; Type: TABLE DATA; Schema: public; Owner: game_app
--

COPY public.player_unlock (id, player_id, unlock_type, unlock_id, source, created_at) FROM stdin;
\.


--
-- Data for Name: port_allocation; Type: TABLE DATA; Schema: public; Owner: game_app
--

COPY public.port_allocation (port, status, server_id, allocated_at, released_at) FROM stdin;
7778	FREE	\N	2026-06-27 12:29:08.993619+00	2026-06-27 12:30:08.362471+00
7777	FREE	\N	2026-06-27 12:59:29.093162+00	2026-06-27 13:00:20.48385+00
\.


--
-- Data for Name: refresh_token; Type: TABLE DATA; Schema: public; Owner: game_app
--

COPY public.refresh_token (id, account_id, token_hash, expires_at, revoked_at, created_at, created_by_ip, user_agent) FROM stdin;
1f54ff50-48f2-4e58-890b-a49c876a1907	4b16b960-f07a-40e1-a6ec-176a188e0dd1	2f18b1e0558206f82d473e5d9995366b26f6aba397a82d1b08ded6c627de6100	2026-07-27 12:22:07.068695+00	\N	2026-06-27 12:22:07.068711+00	\N	\N
add953f0-5ae4-4f4a-836d-cfea5e609476	50777d4f-69c4-494b-a6a8-f636b0e9cd6d	0ec267dd969c285b55335b7c0ba1180e27cee93a00e8ed3913ee2a7e6248fcea	2026-07-27 12:22:07.111351+00	\N	2026-06-27 12:22:07.111351+00	\N	\N
525ef4d6-7ef3-45be-b0a5-5378f80ac42a	4d3230fd-98b2-4744-9eb3-4c36b976d456	8eb2df105c1b88046fbfbee705b1107fbec0aec222e52a88391db78ef6ff001c	2026-07-27 12:24:19.662446+00	\N	2026-06-27 12:24:19.662447+00	\N	\N
96519141-5069-4580-9e1d-623a57e22df8	9140cd6e-36df-47fe-a8a4-87d05d2ea139	27c78e563215801b7ba67347ba0659507894ada9f55c58ea265a6fe0c902eff6	2026-07-27 12:24:19.740041+00	\N	2026-06-27 12:24:19.740041+00	\N	\N
90643b43-3571-49e4-86f6-cc08384fdf1f	c02f78ba-d494-4766-b29c-5c31106196cd	027a19ccbfc302099a42ddb6f3123054351ee376f51b7adcbfecfee68f331dac	2026-07-27 12:25:50.190459+00	\N	2026-06-27 12:25:50.19046+00	\N	\N
cd65c779-9437-4e60-8594-8f8de04568aa	508d668e-314a-4cd8-b1be-05ccced44e1e	acf953e4118ac825e72273868ee9965db4b36adfb3a740c1efb29e5be6d8ee3c	2026-07-27 12:25:50.295206+00	\N	2026-06-27 12:25:50.295207+00	\N	\N
f9866651-387c-4114-917b-e71e3809ef79	3300e0b3-c7f7-47ef-8ac1-f8f313970e8d	7851eda7fcfc3ca07f97e10db9182a1c715ca0a172b4b006631fc6e53ad5f1e3	2026-07-27 12:27:50.929003+00	\N	2026-06-27 12:27:50.929003+00	\N	\N
471f981c-b6e3-490f-9355-e038bc7f6f7d	61bfafcb-ff17-44e6-9edd-5034a9d31084	e3096df102fcb1c2977f46b41042d8eb93acc2641176c576132f653cd4ecab8f	2026-07-27 12:27:50.997687+00	\N	2026-06-27 12:27:50.997687+00	\N	\N
3ded8021-18e1-49eb-8085-3cbcae3ecf5e	870e21fb-7265-4c8e-a224-ab9dd615d171	ba126ef69ff0d7c80417181c5aeaa2c833b7e4548fca47894395a866aa35dbda	2026-07-27 12:29:08.824927+00	\N	2026-06-27 12:29:08.824928+00	\N	\N
512e2d2e-3392-4fa7-b0ce-f2031ca2816f	359e7001-7e4e-4869-94e9-6dd22b77959d	d70a408d3f69051a859ffaa3db231d0bad028e1c872b30ba5b7aeea50c270f67	2026-07-27 12:29:08.905856+00	\N	2026-06-27 12:29:08.905856+00	\N	\N
7a6ae4c6-f9f8-4875-95e7-f1d463495483	1561ba88-1bf0-41da-b40c-0245b5448151	6de8ded45257e7aaaf39cf89bdaebf737b6f1d405272d736a85235a0cfd42554	2026-07-27 12:31:49.725878+00	\N	2026-06-27 12:31:49.725878+00	\N	\N
29f5c66f-b7b3-4a04-999a-de40e07c144d	28193923-dd13-4ff5-983c-3da2272616ef	c4badf03b036f11aec984624528b6b747d8fef2541de73ea16cb1d6107d09343	2026-07-27 12:31:49.821344+00	\N	2026-06-27 12:31:49.821345+00	\N	\N
4a79f1a2-0c75-4669-85ad-6703115f9a4a	fb3159b9-69cf-49c3-a324-3547b3658cd6	1a919c4029562aeebf59d8dfea680fca55610052103946a541f5db4b0de9ca3c	2026-07-27 12:33:53.827408+00	\N	2026-06-27 12:33:53.827408+00	\N	\N
dcc4d001-6940-4cd7-87c9-c289b6e4141a	e3807e41-2c00-412b-91ba-8bccb152cb07	3738540c5f0dbdeec2f5c6e0f7daa0240cc3522dc5b135dc3bb893919d173ed3	2026-07-27 12:33:53.925073+00	\N	2026-06-27 12:33:53.925074+00	\N	\N
59b17ecb-e864-4398-8d3e-453d610a9e8b	b1d0e11e-c572-4d0f-9a2c-9a1fd5028c2b	2e625892a4d0f81b002fba4dcd3ed605e1fb1f6466a18f46bd1d5796fa9c5fb8	2026-07-27 12:52:29.173124+00	\N	2026-06-27 12:52:29.173124+00	\N	\N
8d8b69b5-1b72-4fa7-be5a-ae7a0dcac78f	35538fb3-d1da-466f-afbe-4592afeb8efb	d77525fdad6e328b8227d085b56ad1979081685a06794f8be2d3a331f9972a93	2026-07-27 12:52:29.257416+00	\N	2026-06-27 12:52:29.257416+00	\N	\N
577101b2-f2a1-41ca-a565-56eca043fbed	9697b5fd-31f5-417f-b384-83c721bb0489	d81ef4ea9001e0490a684f89763a06f0e548683b9c72aa272f1b3f7705cbb7e5	2026-07-27 12:53:37.402131+00	\N	2026-06-27 12:53:37.402131+00	\N	\N
1c59c053-3d68-4dbc-bcbc-cd7aed42707b	66406375-f377-463e-b17f-77bf6bac43eb	c630346b09867a1237352177e4132f432130966240461f122a31a50adccb1ab2	2026-07-27 12:53:37.463233+00	\N	2026-06-27 12:53:37.463234+00	\N	\N
b44952f8-376b-4203-bb68-d7b3ef8ce80a	e09a7963-5996-4145-9a8e-6ffad121f3a6	741eb6cab86a5baf35bcf381325cef511ce88d6367d6242a575a650299ad9b5d	2026-07-27 12:56:00.934414+00	\N	2026-06-27 12:56:00.934414+00	\N	\N
df427315-31c2-4bd1-b937-fe2d5886349b	7c02b31c-ddca-4ea6-a6a0-c7e0a492afa8	f7eb72a174fa1f5f1d72404626f71db65091155d74b29eb9a178bed058abc8a2	2026-07-27 12:56:01.003152+00	\N	2026-06-27 12:56:01.003152+00	\N	\N
eceeb6ac-9970-4014-9352-825d0c8106e7	d812d3d9-fafb-4e39-a3e2-e5e0a8f617b5	53d23b4e83c85caa3f958a5cd682c2bf246a36b34a8f2409cfd904fc9b4c2839	2026-07-27 12:57:28.070856+00	\N	2026-06-27 12:57:28.070856+00	\N	\N
b0104e88-76df-414f-a749-e008e6b35bbf	007acf25-7d1a-45c7-aa26-46da18acca34	9ea931aeaa992078b82c08d4a45b5fbd25f00a2d99bbd9d2fae89a5d982e30fb	2026-07-27 12:57:28.132118+00	\N	2026-06-27 12:57:28.132118+00	\N	\N
320b9cfb-9698-4bb0-8b0b-ce8511b42924	640077ad-1fd9-4f78-b215-bfa348010b4a	aade272ad15f4e033c5bbc7ab7bfb7e96c7e417cf426730c6fd2e3d00c40a951	2026-07-27 12:59:00.044601+00	\N	2026-06-27 12:59:00.044603+00	\N	\N
c89f0482-149b-492f-8e47-f60963ff3ece	2d4e931f-5364-431b-9904-6df2c4c2eecb	64d337917a5b90afccce13eb82dbee47ad0734178df403b6337125f2e878a4ae	2026-07-27 12:59:00.11397+00	\N	2026-06-27 12:59:00.113971+00	\N	\N
3c6aa324-2ade-47b1-a588-06848eb5488b	bd4d705a-ccd9-453b-8d47-92215545c924	fdeae650aa128fc7ca39caa0f2419b31617d7edd45b223aa6611e9267b1761cb	2026-07-27 12:59:28.963144+00	\N	2026-06-27 12:59:28.963146+00	\N	\N
8ea2b22a-26d0-49c6-8555-6b1f86f815af	3970fbed-f3a0-4e04-bf3d-a4334b24c11d	86d261bc1bd584fcf6f68122313e7834266bb061a7798ce9a455e94c85a0da95	2026-07-27 12:59:29.022368+00	\N	2026-06-27 12:59:29.02237+00	\N	\N
\.


--
-- Data for Name: retention_cohort; Type: TABLE DATA; Schema: public; Owner: game_app
--

COPY public.retention_cohort (id, cohort_date, d0, d1, d3, d7, d14, d30, region) FROM stdin;
\.


--
-- Data for Name: session_event; Type: TABLE DATA; Schema: public; Owner: game_app
--

COPY public.session_event (id, game_session_id, event_type, payload_json, created_at) FROM stdin;
5d9f0fbf-3d43-4e9c-91e9-3217df7a370c	f6cad132-fe4d-4346-bde7-5dac8cff72d4	READY	{"serverId": "b3280610-f880-4238-8f63-a6700f413a34"}	2026-06-27 12:24:58.470643+00
d18d238c-abda-4f35-a5d6-4a20810d814c	f6cad132-fe4d-4346-bde7-5dac8cff72d4	SERVER_REGISTERED	{"serverId": "b3280610-f880-4238-8f63-a6700f413a34"}	2026-06-27 12:24:58.469497+00
d5bfc0a2-f88e-4ea3-8db1-86dffc2964f7	1f8e87b3-0a17-4738-a715-c14528e0312a	SERVER_REGISTERED	{"serverId": "d333ae3e-7174-4a4a-ac47-5d6ac711c718"}	2026-06-27 12:26:00.919599+00
38c06af8-2908-455a-8ccf-0807cf517537	1f8e87b3-0a17-4738-a715-c14528e0312a	READY	{"serverId": "d333ae3e-7174-4a4a-ac47-5d6ac711c718"}	2026-06-27 12:26:00.920497+00
525bb332-5f89-4a0d-8b63-252a37e64486	310d2b11-6375-431a-b2e8-f50611a7ee31	SERVER_REGISTERED	{"serverId": "5e7717c9-7ead-4c05-9f7e-3e3c8a8eba53"}	2026-06-27 12:28:00.386171+00
c3db76b1-ee7b-44e0-9620-d8fcd660c413	310d2b11-6375-431a-b2e8-f50611a7ee31	READY	{"serverId": "5e7717c9-7ead-4c05-9f7e-3e3c8a8eba53"}	2026-06-27 12:28:00.386887+00
f50c382d-bc82-45a0-b045-4c4ccbed01bc	cda30148-0b53-4d09-80df-4c6d5e231995	SERVER_REGISTERED	{"serverId": "c9fc1f04-a5af-4eb2-81c1-10ec868fb523"}	2026-06-27 12:29:17.778971+00
610f5c4c-ebc9-473c-a657-28c66113801d	cda30148-0b53-4d09-80df-4c6d5e231995	READY	{"serverId": "c9fc1f04-a5af-4eb2-81c1-10ec868fb523"}	2026-06-27 12:29:17.781253+00
f2b355bb-2991-404a-89fd-545d7e7fb457	cf25c5b4-ccd4-4a92-83d2-04bf6121fb63	SERVER_REGISTERED	{"serverId": "ebb744ac-b00d-4986-bef9-d51559201cc4"}	2026-06-27 12:31:58.01769+00
db37e9e4-5cc6-445e-a2e5-42f7379df7c1	cf25c5b4-ccd4-4a92-83d2-04bf6121fb63	READY	{"serverId": "ebb744ac-b00d-4986-bef9-d51559201cc4"}	2026-06-27 12:31:58.023911+00
d13075ae-06fd-47df-9bb3-8c077c2fb281	cf25c5b4-ccd4-4a92-83d2-04bf6121fb63	PLAYER_JOINED	{"playerId": "3b05d8e1-a049-4e77-8cab-0c92e7add106"}	2026-06-27 12:32:09.718361+00
f5c83a7f-76f5-4131-b77a-c59e59e7a838	cf25c5b4-ccd4-4a92-83d2-04bf6121fb63	PLAYER_JOINED	{"playerId": "aeb6861b-fa82-4ec2-856a-8ffc4177413a"}	2026-06-27 12:32:14.126251+00
04bcd603-c7df-4774-aec2-a9a39f3cbcd8	d7acfafe-a374-4052-846a-e4abfaa04a32	SERVER_REGISTERED	{"serverId": "2f73c548-337b-434b-b5a8-59364d0b0e56"}	2026-06-27 12:34:03.489453+00
cf53917d-1d29-4447-8a0e-d0ffb8dfd489	d7acfafe-a374-4052-846a-e4abfaa04a32	READY	{"serverId": "2f73c548-337b-434b-b5a8-59364d0b0e56"}	2026-06-27 12:34:03.490602+00
61c09afc-055a-4781-be18-be0e6f5ea244	d7acfafe-a374-4052-846a-e4abfaa04a32	PLAYER_JOINED	{"playerId": "e212e732-f60a-4c68-9d85-3b9463f4b4bd"}	2026-06-27 12:34:14.986095+00
3e0fcb58-ded3-4ae9-898e-ef7d03ac50a7	d7acfafe-a374-4052-846a-e4abfaa04a32	PLAYER_JOINED	{"playerId": "2591522d-8365-49d2-ab2e-a65cb1d4685a"}	2026-06-27 12:34:20.900739+00
c3e715ff-8788-4ebd-9ec1-ad1cc988df4e	8a26d0ad-0fd1-4da7-b92f-946a33dae1ac	READY	{"serverId": "e9485dec-8ad7-44dd-bf99-22c619fa18a9"}	2026-06-27 12:53:00.818433+00
18e2a843-1721-4a71-b124-9b4ff3bedf6a	8a26d0ad-0fd1-4da7-b92f-946a33dae1ac	SERVER_REGISTERED	{"serverId": "e9485dec-8ad7-44dd-bf99-22c619fa18a9"}	2026-06-27 12:53:00.822427+00
0040a85a-d9cc-4a22-9720-d4022d1e3c2d	2c429a3b-972c-46fb-ab82-7c27bd98976d	SERVER_REGISTERED	{"serverId": "74655b9b-b2ed-4e1f-8140-8e448d40ebd6"}	2026-06-27 12:53:57.107836+00
9d7aa383-f487-4f4d-bfb9-3783975bb50e	2c429a3b-972c-46fb-ab82-7c27bd98976d	READY	{"serverId": "74655b9b-b2ed-4e1f-8140-8e448d40ebd6"}	2026-06-27 12:53:57.108472+00
8c617689-c16b-4500-a9ae-b431171c1eba	2c429a3b-972c-46fb-ab82-7c27bd98976d	PLAYER_JOINED	{"playerId": "bb6052a0-f333-478a-8d65-deb9964c98b0"}	2026-06-27 12:54:07.757629+00
2443328d-a364-43d8-87f6-beb3a26045f8	2c429a3b-972c-46fb-ab82-7c27bd98976d	PLAYER_JOINED	{"playerId": "1d448a2c-c113-426e-af73-7f8d023306d6"}	2026-06-27 12:54:15.941495+00
e4ea8f5d-87a0-4041-9011-074027f5af5d	b2351b4b-54af-4536-85f2-fc609f1bf923	SERVER_REGISTERED	{"serverId": "3c955e54-2601-409b-a808-4b020efa8d2c"}	2026-06-27 12:59:00.930943+00
08bd406b-df20-4972-90bd-e66126a2f0b4	b2351b4b-54af-4536-85f2-fc609f1bf923	READY	{"serverId": "3c955e54-2601-409b-a808-4b020efa8d2c"}	2026-06-27 12:59:00.931212+00
3def7fc8-a6c8-4b5c-9ec5-ca9377da89e5	797f201d-7d5f-4622-8c82-7e270105643f	SERVER_REGISTERED	{"serverId": "43dcc115-12c9-4638-850c-ed73e1bf7961"}	2026-06-27 12:59:29.824686+00
05b14d7b-a95e-44ab-9a9e-177a53f3edb9	797f201d-7d5f-4622-8c82-7e270105643f	READY	{"serverId": "43dcc115-12c9-4638-850c-ed73e1bf7961"}	2026-06-27 12:59:29.82515+00
f0c36ce7-4816-4814-9864-ed4f555c41f4	797f201d-7d5f-4622-8c82-7e270105643f	PLAYER_JOINED	{"playerId": "d508645d-709f-4ef7-9875-d483c124c25d"}	2026-06-27 12:59:40.872246+00
99981a24-d581-4006-80df-b048221d3cd8	797f201d-7d5f-4622-8c82-7e270105643f	PLAYER_JOINED	{"playerId": "5a05cf51-86bb-4eb9-bcb1-6e337375c6c9"}	2026-06-27 12:59:45.936784+00
\.


--
-- Data for Name: wallet_balance; Type: TABLE DATA; Schema: public; Owner: game_app
--

COPY public.wallet_balance (id, player_id, currency_type, balance, updated_at) FROM stdin;
\.


--
-- Data for Name: wallet_ledger; Type: TABLE DATA; Schema: public; Owner: game_app
--

COPY public.wallet_ledger (id, player_id, currency_type, amount, balance_before, balance_after, biz_type, biz_id, idempotency_key, operator_id, created_at) FROM stdin;
\.


--
-- Name: port_allocation_port_seq; Type: SEQUENCE SET; Schema: public; Owner: game_app
--

SELECT pg_catalog.setval('public.port_allocation_port_seq', 1, false);


--
-- Name: Achievements PK_Achievements; Type: CONSTRAINT; Schema: public; Owner: game_app
--

ALTER TABLE ONLY public."Achievements"
    ADD CONSTRAINT "PK_Achievements" PRIMARY KEY ("Id");


--
-- Name: Announcements PK_Announcements; Type: CONSTRAINT; Schema: public; Owner: game_app
--

ALTER TABLE ONLY public."Announcements"
    ADD CONSTRAINT "PK_Announcements" PRIMARY KEY ("Id");


--
-- Name: ClientVersions PK_ClientVersions; Type: CONSTRAINT; Schema: public; Owner: game_app
--

ALTER TABLE ONLY public."ClientVersions"
    ADD CONSTRAINT "PK_ClientVersions" PRIMARY KEY ("Id");


--
-- Name: FriendRelations PK_FriendRelations; Type: CONSTRAINT; Schema: public; Owner: game_app
--

ALTER TABLE ONLY public."FriendRelations"
    ADD CONSTRAINT "PK_FriendRelations" PRIMARY KEY ("Id");


--
-- Name: FriendRequests PK_FriendRequests; Type: CONSTRAINT; Schema: public; Owner: game_app
--

ALTER TABLE ONLY public."FriendRequests"
    ADD CONSTRAINT "PK_FriendRequests" PRIMARY KEY ("Id");


--
-- Name: GameEvents PK_GameEvents; Type: CONSTRAINT; Schema: public; Owner: game_app
--

ALTER TABLE ONLY public."GameEvents"
    ADD CONSTRAINT "PK_GameEvents" PRIMARY KEY ("Id");


--
-- Name: MailAttachments PK_MailAttachments; Type: CONSTRAINT; Schema: public; Owner: game_app
--

ALTER TABLE ONLY public."MailAttachments"
    ADD CONSTRAINT "PK_MailAttachments" PRIMARY KEY ("Id");


--
-- Name: Mails PK_Mails; Type: CONSTRAINT; Schema: public; Owner: game_app
--

ALTER TABLE ONLY public."Mails"
    ADD CONSTRAINT "PK_Mails" PRIMARY KEY ("Id");


--
-- Name: PlayerAchievements PK_PlayerAchievements; Type: CONSTRAINT; Schema: public; Owner: game_app
--

ALTER TABLE ONLY public."PlayerAchievements"
    ADD CONSTRAINT "PK_PlayerAchievements" PRIMARY KEY ("Id");


--
-- Name: PlayerEventProgresses PK_PlayerEventProgresses; Type: CONSTRAINT; Schema: public; Owner: game_app
--

ALTER TABLE ONLY public."PlayerEventProgresses"
    ADD CONSTRAINT "PK_PlayerEventProgresses" PRIMARY KEY ("Id");


--
-- Name: PlayerMatchHistories PK_PlayerMatchHistories; Type: CONSTRAINT; Schema: public; Owner: game_app
--

ALTER TABLE ONLY public."PlayerMatchHistories"
    ADD CONSTRAINT "PK_PlayerMatchHistories" PRIMARY KEY ("Id");


--
-- Name: PlayerRankings PK_PlayerRankings; Type: CONSTRAINT; Schema: public; Owner: game_app
--

ALTER TABLE ONLY public."PlayerRankings"
    ADD CONSTRAINT "PK_PlayerRankings" PRIMARY KEY ("Id");


--
-- Name: Reports PK_Reports; Type: CONSTRAINT; Schema: public; Owner: game_app
--

ALTER TABLE ONLY public."Reports"
    ADD CONSTRAINT "PK_Reports" PRIMARY KEY ("Id");


--
-- Name: SupportTickets PK_SupportTickets; Type: CONSTRAINT; Schema: public; Owner: game_app
--

ALTER TABLE ONLY public."SupportTickets"
    ADD CONSTRAINT "PK_SupportTickets" PRIMARY KEY ("Id");


--
-- Name: TicketReplies PK_TicketReplies; Type: CONSTRAINT; Schema: public; Owner: game_app
--

ALTER TABLE ONLY public."TicketReplies"
    ADD CONSTRAINT "PK_TicketReplies" PRIMARY KEY ("Id");


--
-- Name: __EFMigrationsHistory PK___EFMigrationsHistory; Type: CONSTRAINT; Schema: public; Owner: game_app
--

ALTER TABLE ONLY public."__EFMigrationsHistory"
    ADD CONSTRAINT "PK___EFMigrationsHistory" PRIMARY KEY ("MigrationId");


--
-- Name: account PK_account; Type: CONSTRAINT; Schema: public; Owner: game_app
--

ALTER TABLE ONLY public.account
    ADD CONSTRAINT "PK_account" PRIMARY KEY (id);


--
-- Name: admin_audit_log PK_admin_audit_log; Type: CONSTRAINT; Schema: public; Owner: game_app
--

ALTER TABLE ONLY public.admin_audit_log
    ADD CONSTRAINT "PK_admin_audit_log" PRIMARY KEY (id);


--
-- Name: admin_user PK_admin_user; Type: CONSTRAINT; Schema: public; Owner: game_app
--

ALTER TABLE ONLY public.admin_user
    ADD CONSTRAINT "PK_admin_user" PRIMARY KEY (id);


--
-- Name: ban_record PK_ban_record; Type: CONSTRAINT; Schema: public; Owner: game_app
--

ALTER TABLE ONLY public.ban_record
    ADD CONSTRAINT "PK_ban_record" PRIMARY KEY (id);


--
-- Name: crash_report PK_crash_report; Type: CONSTRAINT; Schema: public; Owner: game_app
--

ALTER TABLE ONLY public.crash_report
    ADD CONSTRAINT "PK_crash_report" PRIMARY KEY (id);


--
-- Name: daily_stats PK_daily_stats; Type: CONSTRAINT; Schema: public; Owner: game_app
--

ALTER TABLE ONLY public.daily_stats
    ADD CONSTRAINT "PK_daily_stats" PRIMARY KEY (date);


--
-- Name: device_login PK_device_login; Type: CONSTRAINT; Schema: public; Owner: game_app
--

ALTER TABLE ONLY public.device_login
    ADD CONSTRAINT "PK_device_login" PRIMARY KEY (id);


--
-- Name: game_config PK_game_config; Type: CONSTRAINT; Schema: public; Owner: game_app
--

ALTER TABLE ONLY public.game_config
    ADD CONSTRAINT "PK_game_config" PRIMARY KEY (id);


--
-- Name: game_config_publish_log PK_game_config_publish_log; Type: CONSTRAINT; Schema: public; Owner: game_app
--

ALTER TABLE ONLY public.game_config_publish_log
    ADD CONSTRAINT "PK_game_config_publish_log" PRIMARY KEY (id);


--
-- Name: game_room PK_game_room; Type: CONSTRAINT; Schema: public; Owner: game_app
--

ALTER TABLE ONLY public.game_room
    ADD CONSTRAINT "PK_game_room" PRIMARY KEY (id);


--
-- Name: game_room_player PK_game_room_player; Type: CONSTRAINT; Schema: public; Owner: game_app
--

ALTER TABLE ONLY public.game_room_player
    ADD CONSTRAINT "PK_game_room_player" PRIMARY KEY (id);


--
-- Name: game_server_event PK_game_server_event; Type: CONSTRAINT; Schema: public; Owner: game_app
--

ALTER TABLE ONLY public.game_server_event
    ADD CONSTRAINT "PK_game_server_event" PRIMARY KEY (id);


--
-- Name: game_server_instance PK_game_server_instance; Type: CONSTRAINT; Schema: public; Owner: game_app
--

ALTER TABLE ONLY public.game_server_instance
    ADD CONSTRAINT "PK_game_server_instance" PRIMARY KEY (id);


--
-- Name: game_session PK_game_session; Type: CONSTRAINT; Schema: public; Owner: game_app
--

ALTER TABLE ONLY public.game_session
    ADD CONSTRAINT "PK_game_session" PRIMARY KEY (id);


--
-- Name: inventory_item PK_inventory_item; Type: CONSTRAINT; Schema: public; Owner: game_app
--

ALTER TABLE ONLY public.inventory_item
    ADD CONSTRAINT "PK_inventory_item" PRIMARY KEY (id);


--
-- Name: inventory_log PK_inventory_log; Type: CONSTRAINT; Schema: public; Owner: game_app
--

ALTER TABLE ONLY public.inventory_log
    ADD CONSTRAINT "PK_inventory_log" PRIMARY KEY (id);


--
-- Name: match_player_result PK_match_player_result; Type: CONSTRAINT; Schema: public; Owner: game_app
--

ALTER TABLE ONLY public.match_player_result
    ADD CONSTRAINT "PK_match_player_result" PRIMARY KEY (id);


--
-- Name: match_result PK_match_result; Type: CONSTRAINT; Schema: public; Owner: game_app
--

ALTER TABLE ONLY public.match_result
    ADD CONSTRAINT "PK_match_result" PRIMARY KEY (id);


--
-- Name: matchmaking_ticket PK_matchmaking_ticket; Type: CONSTRAINT; Schema: public; Owner: game_app
--

ALTER TABLE ONLY public.matchmaking_ticket
    ADD CONSTRAINT "PK_matchmaking_ticket" PRIMARY KEY (id);


--
-- Name: order_record PK_order_record; Type: CONSTRAINT; Schema: public; Owner: game_app
--

ALTER TABLE ONLY public.order_record
    ADD CONSTRAINT "PK_order_record" PRIMARY KEY (id);


--
-- Name: player_character PK_player_character; Type: CONSTRAINT; Schema: public; Owner: game_app
--

ALTER TABLE ONLY public.player_character
    ADD CONSTRAINT "PK_player_character" PRIMARY KEY (id);


--
-- Name: player_event_log PK_player_event_log; Type: CONSTRAINT; Schema: public; Owner: game_app
--

ALTER TABLE ONLY public.player_event_log
    ADD CONSTRAINT "PK_player_event_log" PRIMARY KEY (id);


--
-- Name: player_feedback PK_player_feedback; Type: CONSTRAINT; Schema: public; Owner: game_app
--

ALTER TABLE ONLY public.player_feedback
    ADD CONSTRAINT "PK_player_feedback" PRIMARY KEY (id);


--
-- Name: player_identity PK_player_identity; Type: CONSTRAINT; Schema: public; Owner: game_app
--

ALTER TABLE ONLY public.player_identity
    ADD CONSTRAINT "PK_player_identity" PRIMARY KEY (id);


--
-- Name: player_profile PK_player_profile; Type: CONSTRAINT; Schema: public; Owner: game_app
--

ALTER TABLE ONLY public.player_profile
    ADD CONSTRAINT "PK_player_profile" PRIMARY KEY (player_id);


--
-- Name: player_session PK_player_session; Type: CONSTRAINT; Schema: public; Owner: game_app
--

ALTER TABLE ONLY public.player_session
    ADD CONSTRAINT "PK_player_session" PRIMARY KEY (id);


--
-- Name: player_settings PK_player_settings; Type: CONSTRAINT; Schema: public; Owner: game_app
--

ALTER TABLE ONLY public.player_settings
    ADD CONSTRAINT "PK_player_settings" PRIMARY KEY (player_id);


--
-- Name: player_statistics PK_player_statistics; Type: CONSTRAINT; Schema: public; Owner: game_app
--

ALTER TABLE ONLY public.player_statistics
    ADD CONSTRAINT "PK_player_statistics" PRIMARY KEY (player_id);


--
-- Name: player_unlock PK_player_unlock; Type: CONSTRAINT; Schema: public; Owner: game_app
--

ALTER TABLE ONLY public.player_unlock
    ADD CONSTRAINT "PK_player_unlock" PRIMARY KEY (id);


--
-- Name: port_allocation PK_port_allocation; Type: CONSTRAINT; Schema: public; Owner: game_app
--

ALTER TABLE ONLY public.port_allocation
    ADD CONSTRAINT "PK_port_allocation" PRIMARY KEY (port);


--
-- Name: refresh_token PK_refresh_token; Type: CONSTRAINT; Schema: public; Owner: game_app
--

ALTER TABLE ONLY public.refresh_token
    ADD CONSTRAINT "PK_refresh_token" PRIMARY KEY (id);


--
-- Name: retention_cohort PK_retention_cohort; Type: CONSTRAINT; Schema: public; Owner: game_app
--

ALTER TABLE ONLY public.retention_cohort
    ADD CONSTRAINT "PK_retention_cohort" PRIMARY KEY (id);


--
-- Name: session_event PK_session_event; Type: CONSTRAINT; Schema: public; Owner: game_app
--

ALTER TABLE ONLY public.session_event
    ADD CONSTRAINT "PK_session_event" PRIMARY KEY (id);


--
-- Name: wallet_balance PK_wallet_balance; Type: CONSTRAINT; Schema: public; Owner: game_app
--

ALTER TABLE ONLY public.wallet_balance
    ADD CONSTRAINT "PK_wallet_balance" PRIMARY KEY (id);


--
-- Name: wallet_ledger PK_wallet_ledger; Type: CONSTRAINT; Schema: public; Owner: game_app
--

ALTER TABLE ONLY public.wallet_ledger
    ADD CONSTRAINT "PK_wallet_ledger" PRIMARY KEY (id);


--
-- Name: IX_FriendRelations_PlayerId; Type: INDEX; Schema: public; Owner: game_app
--

CREATE INDEX "IX_FriendRelations_PlayerId" ON public."FriendRelations" USING btree ("PlayerId");


--
-- Name: IX_MailAttachments_MailId; Type: INDEX; Schema: public; Owner: game_app
--

CREATE INDEX "IX_MailAttachments_MailId" ON public."MailAttachments" USING btree ("MailId");


--
-- Name: IX_Mails_ReceiverId; Type: INDEX; Schema: public; Owner: game_app
--

CREATE INDEX "IX_Mails_ReceiverId" ON public."Mails" USING btree ("ReceiverId");


--
-- Name: IX_PlayerAchievements_AchievementId; Type: INDEX; Schema: public; Owner: game_app
--

CREATE INDEX "IX_PlayerAchievements_AchievementId" ON public."PlayerAchievements" USING btree ("AchievementId");


--
-- Name: IX_PlayerAchievements_PlayerId; Type: INDEX; Schema: public; Owner: game_app
--

CREATE INDEX "IX_PlayerAchievements_PlayerId" ON public."PlayerAchievements" USING btree ("PlayerId");


--
-- Name: IX_PlayerEventProgresses_EventId; Type: INDEX; Schema: public; Owner: game_app
--

CREATE INDEX "IX_PlayerEventProgresses_EventId" ON public."PlayerEventProgresses" USING btree ("EventId");


--
-- Name: IX_PlayerEventProgresses_PlayerId; Type: INDEX; Schema: public; Owner: game_app
--

CREATE INDEX "IX_PlayerEventProgresses_PlayerId" ON public."PlayerEventProgresses" USING btree ("PlayerId");


--
-- Name: IX_PlayerMatchHistories_PlayerId; Type: INDEX; Schema: public; Owner: game_app
--

CREATE INDEX "IX_PlayerMatchHistories_PlayerId" ON public."PlayerMatchHistories" USING btree ("PlayerId");


--
-- Name: IX_PlayerRankings_PlayerId; Type: INDEX; Schema: public; Owner: game_app
--

CREATE INDEX "IX_PlayerRankings_PlayerId" ON public."PlayerRankings" USING btree ("PlayerId");


--
-- Name: IX_Reports_ReporterId; Type: INDEX; Schema: public; Owner: game_app
--

CREATE INDEX "IX_Reports_ReporterId" ON public."Reports" USING btree ("ReporterId");


--
-- Name: IX_SupportTickets_AssignedAdminId; Type: INDEX; Schema: public; Owner: game_app
--

CREATE INDEX "IX_SupportTickets_AssignedAdminId" ON public."SupportTickets" USING btree ("AssignedAdminId");


--
-- Name: IX_SupportTickets_PlayerId; Type: INDEX; Schema: public; Owner: game_app
--

CREATE INDEX "IX_SupportTickets_PlayerId" ON public."SupportTickets" USING btree ("PlayerId");


--
-- Name: IX_TicketReplies_TicketId; Type: INDEX; Schema: public; Owner: game_app
--

CREATE INDEX "IX_TicketReplies_TicketId" ON public."TicketReplies" USING btree ("TicketId");


--
-- Name: IX_account_created_at; Type: INDEX; Schema: public; Owner: game_app
--

CREATE INDEX "IX_account_created_at" ON public.account USING btree (created_at);


--
-- Name: IX_account_email; Type: INDEX; Schema: public; Owner: game_app
--

CREATE UNIQUE INDEX "IX_account_email" ON public.account USING btree (email) WHERE (email IS NOT NULL);


--
-- Name: IX_account_eos_id; Type: INDEX; Schema: public; Owner: game_app
--

CREATE UNIQUE INDEX "IX_account_eos_id" ON public.account USING btree (eos_id) WHERE (eos_id IS NOT NULL);


--
-- Name: IX_account_status; Type: INDEX; Schema: public; Owner: game_app
--

CREATE INDEX "IX_account_status" ON public.account USING btree (status);


--
-- Name: IX_account_steam_id; Type: INDEX; Schema: public; Owner: game_app
--

CREATE UNIQUE INDEX "IX_account_steam_id" ON public.account USING btree (steam_id) WHERE (steam_id IS NOT NULL);


--
-- Name: IX_admin_audit_log_action; Type: INDEX; Schema: public; Owner: game_app
--

CREATE INDEX "IX_admin_audit_log_action" ON public.admin_audit_log USING btree (action);


--
-- Name: IX_admin_audit_log_admin_user_id; Type: INDEX; Schema: public; Owner: game_app
--

CREATE INDEX "IX_admin_audit_log_admin_user_id" ON public.admin_audit_log USING btree (admin_user_id);


--
-- Name: IX_admin_audit_log_created_at; Type: INDEX; Schema: public; Owner: game_app
--

CREATE INDEX "IX_admin_audit_log_created_at" ON public.admin_audit_log USING btree (created_at);


--
-- Name: IX_admin_user_username; Type: INDEX; Schema: public; Owner: game_app
--

CREATE UNIQUE INDEX "IX_admin_user_username" ON public.admin_user USING btree (username);


--
-- Name: IX_ban_record_account_id; Type: INDEX; Schema: public; Owner: game_app
--

CREATE INDEX "IX_ban_record_account_id" ON public.ban_record USING btree (account_id);


--
-- Name: IX_ban_record_player_id; Type: INDEX; Schema: public; Owner: game_app
--

CREATE INDEX "IX_ban_record_player_id" ON public.ban_record USING btree (player_id);


--
-- Name: IX_device_login_account_id_device_id_hash; Type: INDEX; Schema: public; Owner: game_app
--

CREATE UNIQUE INDEX "IX_device_login_account_id_device_id_hash" ON public.device_login USING btree (account_id, device_id_hash);


--
-- Name: IX_game_config_config_key; Type: INDEX; Schema: public; Owner: game_app
--

CREATE INDEX "IX_game_config_config_key" ON public.game_config USING btree (config_key);


--
-- Name: IX_game_config_config_key_version_channel_region; Type: INDEX; Schema: public; Owner: game_app
--

CREATE UNIQUE INDEX "IX_game_config_config_key_version_channel_region" ON public.game_config USING btree (config_key, version, channel, region);


--
-- Name: IX_game_config_publish_log_config_key; Type: INDEX; Schema: public; Owner: game_app
--

CREATE INDEX "IX_game_config_publish_log_config_key" ON public.game_config_publish_log USING btree (config_key);


--
-- Name: IX_game_config_publish_log_created_at; Type: INDEX; Schema: public; Owner: game_app
--

CREATE INDEX "IX_game_config_publish_log_created_at" ON public.game_config_publish_log USING btree (created_at);


--
-- Name: IX_game_config_status; Type: INDEX; Schema: public; Owner: game_app
--

CREATE INDEX "IX_game_config_status" ON public.game_config USING btree (status);


--
-- Name: IX_game_room_created_at; Type: INDEX; Schema: public; Owner: game_app
--

CREATE INDEX "IX_game_room_created_at" ON public.game_room USING btree (created_at);


--
-- Name: IX_game_room_mode_region; Type: INDEX; Schema: public; Owner: game_app
--

CREATE INDEX "IX_game_room_mode_region" ON public.game_room USING btree (mode, region);


--
-- Name: IX_game_room_player_room_id_player_id; Type: INDEX; Schema: public; Owner: game_app
--

CREATE INDEX "IX_game_room_player_room_id_player_id" ON public.game_room_player USING btree (room_id, player_id) WHERE (left_at IS NULL);


--
-- Name: IX_game_room_status; Type: INDEX; Schema: public; Owner: game_app
--

CREATE INDEX "IX_game_room_status" ON public.game_room USING btree (status);


--
-- Name: IX_game_server_event_server_id; Type: INDEX; Schema: public; Owner: game_app
--

CREATE INDEX "IX_game_server_event_server_id" ON public.game_server_event USING btree (server_id);


--
-- Name: IX_game_server_instance_last_heartbeat_at; Type: INDEX; Schema: public; Owner: game_app
--

CREATE INDEX "IX_game_server_instance_last_heartbeat_at" ON public.game_server_instance USING btree (last_heartbeat_at);


--
-- Name: IX_game_server_instance_session_id; Type: INDEX; Schema: public; Owner: game_app
--

CREATE INDEX "IX_game_server_instance_session_id" ON public.game_server_instance USING btree (session_id);


--
-- Name: IX_game_server_instance_status; Type: INDEX; Schema: public; Owner: game_app
--

CREATE INDEX "IX_game_server_instance_status" ON public.game_server_instance USING btree (status);


--
-- Name: IX_game_session_created_at; Type: INDEX; Schema: public; Owner: game_app
--

CREATE INDEX "IX_game_session_created_at" ON public.game_session USING btree (created_at);


--
-- Name: IX_game_session_mode_region; Type: INDEX; Schema: public; Owner: game_app
--

CREATE INDEX "IX_game_session_mode_region" ON public.game_session USING btree (mode, region);


--
-- Name: IX_game_session_status; Type: INDEX; Schema: public; Owner: game_app
--

CREATE INDEX "IX_game_session_status" ON public.game_session USING btree (status);


--
-- Name: IX_inventory_item_player_id; Type: INDEX; Schema: public; Owner: game_app
--

CREATE INDEX "IX_inventory_item_player_id" ON public.inventory_item USING btree (player_id);


--
-- Name: IX_inventory_log_biz_type; Type: INDEX; Schema: public; Owner: game_app
--

CREATE INDEX "IX_inventory_log_biz_type" ON public.inventory_log USING btree (biz_type);


--
-- Name: IX_inventory_log_player_id; Type: INDEX; Schema: public; Owner: game_app
--

CREATE INDEX "IX_inventory_log_player_id" ON public.inventory_log USING btree (player_id);


--
-- Name: IX_match_player_result_match_result_id_player_id; Type: INDEX; Schema: public; Owner: game_app
--

CREATE UNIQUE INDEX "IX_match_player_result_match_result_id_player_id" ON public.match_player_result USING btree (match_result_id, player_id);


--
-- Name: IX_match_result_GameSessionId; Type: INDEX; Schema: public; Owner: game_app
--

CREATE INDEX "IX_match_result_GameSessionId" ON public.match_result USING btree ("GameSessionId");


--
-- Name: IX_match_result_idempotency_key; Type: INDEX; Schema: public; Owner: game_app
--

CREATE UNIQUE INDEX "IX_match_result_idempotency_key" ON public.match_result USING btree (idempotency_key);


--
-- Name: IX_match_result_session_id; Type: INDEX; Schema: public; Owner: game_app
--

CREATE UNIQUE INDEX "IX_match_result_session_id" ON public.match_result USING btree (session_id);


--
-- Name: IX_matchmaking_ticket_mode_region_status; Type: INDEX; Schema: public; Owner: game_app
--

CREATE INDEX "IX_matchmaking_ticket_mode_region_status" ON public.matchmaking_ticket USING btree (mode, region, status);


--
-- Name: IX_matchmaking_ticket_player_id; Type: INDEX; Schema: public; Owner: game_app
--

CREATE INDEX "IX_matchmaking_ticket_player_id" ON public.matchmaking_ticket USING btree (player_id);


--
-- Name: IX_matchmaking_ticket_status; Type: INDEX; Schema: public; Owner: game_app
--

CREATE INDEX "IX_matchmaking_ticket_status" ON public.matchmaking_ticket USING btree (status);


--
-- Name: IX_order_record_player_id; Type: INDEX; Schema: public; Owner: game_app
--

CREATE INDEX "IX_order_record_player_id" ON public.order_record USING btree (player_id);


--
-- Name: IX_order_record_status; Type: INDEX; Schema: public; Owner: game_app
--

CREATE INDEX "IX_order_record_status" ON public.order_record USING btree (status);


--
-- Name: IX_player_character_player_id; Type: INDEX; Schema: public; Owner: game_app
--

CREATE INDEX "IX_player_character_player_id" ON public.player_character USING btree (player_id);


--
-- Name: IX_player_character_player_id_character_name; Type: INDEX; Schema: public; Owner: game_app
--

CREATE UNIQUE INDEX "IX_player_character_player_id_character_name" ON public.player_character USING btree (player_id, character_name);


--
-- Name: IX_player_character_player_id_is_selected; Type: INDEX; Schema: public; Owner: game_app
--

CREATE INDEX "IX_player_character_player_id_is_selected" ON public.player_character USING btree (player_id, is_selected);


--
-- Name: IX_player_event_log_created_at; Type: INDEX; Schema: public; Owner: game_app
--

CREATE INDEX "IX_player_event_log_created_at" ON public.player_event_log USING btree (created_at);


--
-- Name: IX_player_event_log_event_type; Type: INDEX; Schema: public; Owner: game_app
--

CREATE INDEX "IX_player_event_log_event_type" ON public.player_event_log USING btree (event_type);


--
-- Name: IX_player_event_log_player_id; Type: INDEX; Schema: public; Owner: game_app
--

CREATE INDEX "IX_player_event_log_player_id" ON public.player_event_log USING btree (player_id);


--
-- Name: IX_player_identity_account_id; Type: INDEX; Schema: public; Owner: game_app
--

CREATE UNIQUE INDEX "IX_player_identity_account_id" ON public.player_identity USING btree (account_id);


--
-- Name: IX_player_identity_display_name; Type: INDEX; Schema: public; Owner: game_app
--

CREATE INDEX "IX_player_identity_display_name" ON public.player_identity USING btree (display_name);


--
-- Name: IX_player_identity_player_id; Type: INDEX; Schema: public; Owner: game_app
--

CREATE UNIQUE INDEX "IX_player_identity_player_id" ON public.player_identity USING btree (player_id);


--
-- Name: IX_player_profile_last_login_at; Type: INDEX; Schema: public; Owner: game_app
--

CREATE INDEX "IX_player_profile_last_login_at" ON public.player_profile USING btree (last_login_at);


--
-- Name: IX_player_profile_level; Type: INDEX; Schema: public; Owner: game_app
--

CREATE INDEX "IX_player_profile_level" ON public.player_profile USING btree (level);


--
-- Name: IX_player_profile_nickname; Type: INDEX; Schema: public; Owner: game_app
--

CREATE UNIQUE INDEX "IX_player_profile_nickname" ON public.player_profile USING btree (nickname);


--
-- Name: IX_player_session_game_session_id_player_id; Type: INDEX; Schema: public; Owner: game_app
--

CREATE UNIQUE INDEX "IX_player_session_game_session_id_player_id" ON public.player_session USING btree (game_session_id, player_id);


--
-- Name: IX_player_session_session_token_hash; Type: INDEX; Schema: public; Owner: game_app
--

CREATE UNIQUE INDEX "IX_player_session_session_token_hash" ON public.player_session USING btree (session_token_hash);


--
-- Name: IX_player_unlock_player_id_unlock_type_unlock_id; Type: INDEX; Schema: public; Owner: game_app
--

CREATE UNIQUE INDEX "IX_player_unlock_player_id_unlock_type_unlock_id" ON public.player_unlock USING btree (player_id, unlock_type, unlock_id);


--
-- Name: IX_refresh_token_account_id; Type: INDEX; Schema: public; Owner: game_app
--

CREATE INDEX "IX_refresh_token_account_id" ON public.refresh_token USING btree (account_id);


--
-- Name: IX_refresh_token_expires_at; Type: INDEX; Schema: public; Owner: game_app
--

CREATE INDEX "IX_refresh_token_expires_at" ON public.refresh_token USING btree (expires_at);


--
-- Name: IX_refresh_token_token_hash; Type: INDEX; Schema: public; Owner: game_app
--

CREATE UNIQUE INDEX "IX_refresh_token_token_hash" ON public.refresh_token USING btree (token_hash);


--
-- Name: IX_retention_cohort_cohort_date; Type: INDEX; Schema: public; Owner: game_app
--

CREATE INDEX "IX_retention_cohort_cohort_date" ON public.retention_cohort USING btree (cohort_date);


--
-- Name: IX_retention_cohort_region; Type: INDEX; Schema: public; Owner: game_app
--

CREATE INDEX "IX_retention_cohort_region" ON public.retention_cohort USING btree (region);


--
-- Name: IX_session_event_game_session_id; Type: INDEX; Schema: public; Owner: game_app
--

CREATE INDEX "IX_session_event_game_session_id" ON public.session_event USING btree (game_session_id);


--
-- Name: IX_wallet_balance_player_id_currency_type; Type: INDEX; Schema: public; Owner: game_app
--

CREATE UNIQUE INDEX "IX_wallet_balance_player_id_currency_type" ON public.wallet_balance USING btree (player_id, currency_type);


--
-- Name: IX_wallet_ledger_idempotency_key; Type: INDEX; Schema: public; Owner: game_app
--

CREATE UNIQUE INDEX "IX_wallet_ledger_idempotency_key" ON public.wallet_ledger USING btree (idempotency_key);


--
-- Name: IX_wallet_ledger_player_id; Type: INDEX; Schema: public; Owner: game_app
--

CREATE INDEX "IX_wallet_ledger_player_id" ON public.wallet_ledger USING btree (player_id);


--
-- Name: FriendRelations FK_FriendRelations_player_profile_PlayerId; Type: FK CONSTRAINT; Schema: public; Owner: game_app
--

ALTER TABLE ONLY public."FriendRelations"
    ADD CONSTRAINT "FK_FriendRelations_player_profile_PlayerId" FOREIGN KEY ("PlayerId") REFERENCES public.player_profile(player_id) ON DELETE CASCADE;


--
-- Name: MailAttachments FK_MailAttachments_Mails_MailId; Type: FK CONSTRAINT; Schema: public; Owner: game_app
--

ALTER TABLE ONLY public."MailAttachments"
    ADD CONSTRAINT "FK_MailAttachments_Mails_MailId" FOREIGN KEY ("MailId") REFERENCES public."Mails"("Id") ON DELETE CASCADE;


--
-- Name: Mails FK_Mails_player_profile_ReceiverId; Type: FK CONSTRAINT; Schema: public; Owner: game_app
--

ALTER TABLE ONLY public."Mails"
    ADD CONSTRAINT "FK_Mails_player_profile_ReceiverId" FOREIGN KEY ("ReceiverId") REFERENCES public.player_profile(player_id);


--
-- Name: PlayerAchievements FK_PlayerAchievements_Achievements_AchievementId; Type: FK CONSTRAINT; Schema: public; Owner: game_app
--

ALTER TABLE ONLY public."PlayerAchievements"
    ADD CONSTRAINT "FK_PlayerAchievements_Achievements_AchievementId" FOREIGN KEY ("AchievementId") REFERENCES public."Achievements"("Id") ON DELETE CASCADE;


--
-- Name: PlayerAchievements FK_PlayerAchievements_player_profile_PlayerId; Type: FK CONSTRAINT; Schema: public; Owner: game_app
--

ALTER TABLE ONLY public."PlayerAchievements"
    ADD CONSTRAINT "FK_PlayerAchievements_player_profile_PlayerId" FOREIGN KEY ("PlayerId") REFERENCES public.player_profile(player_id) ON DELETE CASCADE;


--
-- Name: PlayerEventProgresses FK_PlayerEventProgresses_GameEvents_EventId; Type: FK CONSTRAINT; Schema: public; Owner: game_app
--

ALTER TABLE ONLY public."PlayerEventProgresses"
    ADD CONSTRAINT "FK_PlayerEventProgresses_GameEvents_EventId" FOREIGN KEY ("EventId") REFERENCES public."GameEvents"("Id") ON DELETE CASCADE;


--
-- Name: PlayerEventProgresses FK_PlayerEventProgresses_player_profile_PlayerId; Type: FK CONSTRAINT; Schema: public; Owner: game_app
--

ALTER TABLE ONLY public."PlayerEventProgresses"
    ADD CONSTRAINT "FK_PlayerEventProgresses_player_profile_PlayerId" FOREIGN KEY ("PlayerId") REFERENCES public.player_profile(player_id) ON DELETE CASCADE;


--
-- Name: PlayerMatchHistories FK_PlayerMatchHistories_player_profile_PlayerId; Type: FK CONSTRAINT; Schema: public; Owner: game_app
--

ALTER TABLE ONLY public."PlayerMatchHistories"
    ADD CONSTRAINT "FK_PlayerMatchHistories_player_profile_PlayerId" FOREIGN KEY ("PlayerId") REFERENCES public.player_profile(player_id) ON DELETE CASCADE;


--
-- Name: PlayerRankings FK_PlayerRankings_player_profile_PlayerId; Type: FK CONSTRAINT; Schema: public; Owner: game_app
--

ALTER TABLE ONLY public."PlayerRankings"
    ADD CONSTRAINT "FK_PlayerRankings_player_profile_PlayerId" FOREIGN KEY ("PlayerId") REFERENCES public.player_profile(player_id) ON DELETE CASCADE;


--
-- Name: Reports FK_Reports_player_profile_ReporterId; Type: FK CONSTRAINT; Schema: public; Owner: game_app
--

ALTER TABLE ONLY public."Reports"
    ADD CONSTRAINT "FK_Reports_player_profile_ReporterId" FOREIGN KEY ("ReporterId") REFERENCES public.player_profile(player_id) ON DELETE CASCADE;


--
-- Name: SupportTickets FK_SupportTickets_admin_user_AssignedAdminId; Type: FK CONSTRAINT; Schema: public; Owner: game_app
--

ALTER TABLE ONLY public."SupportTickets"
    ADD CONSTRAINT "FK_SupportTickets_admin_user_AssignedAdminId" FOREIGN KEY ("AssignedAdminId") REFERENCES public.admin_user(id);


--
-- Name: SupportTickets FK_SupportTickets_player_profile_PlayerId; Type: FK CONSTRAINT; Schema: public; Owner: game_app
--

ALTER TABLE ONLY public."SupportTickets"
    ADD CONSTRAINT "FK_SupportTickets_player_profile_PlayerId" FOREIGN KEY ("PlayerId") REFERENCES public.player_profile(player_id);


--
-- Name: TicketReplies FK_TicketReplies_SupportTickets_TicketId; Type: FK CONSTRAINT; Schema: public; Owner: game_app
--

ALTER TABLE ONLY public."TicketReplies"
    ADD CONSTRAINT "FK_TicketReplies_SupportTickets_TicketId" FOREIGN KEY ("TicketId") REFERENCES public."SupportTickets"("Id") ON DELETE CASCADE;


--
-- Name: ban_record FK_ban_record_account_account_id; Type: FK CONSTRAINT; Schema: public; Owner: game_app
--

ALTER TABLE ONLY public.ban_record
    ADD CONSTRAINT "FK_ban_record_account_account_id" FOREIGN KEY (account_id) REFERENCES public.account(id) ON DELETE CASCADE;


--
-- Name: device_login FK_device_login_account_account_id; Type: FK CONSTRAINT; Schema: public; Owner: game_app
--

ALTER TABLE ONLY public.device_login
    ADD CONSTRAINT "FK_device_login_account_account_id" FOREIGN KEY (account_id) REFERENCES public.account(id) ON DELETE CASCADE;


--
-- Name: game_room_player FK_game_room_player_game_room_room_id; Type: FK CONSTRAINT; Schema: public; Owner: game_app
--

ALTER TABLE ONLY public.game_room_player
    ADD CONSTRAINT "FK_game_room_player_game_room_room_id" FOREIGN KEY (room_id) REFERENCES public.game_room(id) ON DELETE CASCADE;


--
-- Name: game_server_event FK_game_server_event_game_server_instance_server_id; Type: FK CONSTRAINT; Schema: public; Owner: game_app
--

ALTER TABLE ONLY public.game_server_event
    ADD CONSTRAINT "FK_game_server_event_game_server_instance_server_id" FOREIGN KEY (server_id) REFERENCES public.game_server_instance(id) ON DELETE CASCADE;


--
-- Name: inventory_item FK_inventory_item_player_profile_player_id; Type: FK CONSTRAINT; Schema: public; Owner: game_app
--

ALTER TABLE ONLY public.inventory_item
    ADD CONSTRAINT "FK_inventory_item_player_profile_player_id" FOREIGN KEY (player_id) REFERENCES public.player_profile(player_id) ON DELETE CASCADE;


--
-- Name: match_player_result FK_match_player_result_match_result_match_result_id; Type: FK CONSTRAINT; Schema: public; Owner: game_app
--

ALTER TABLE ONLY public.match_player_result
    ADD CONSTRAINT "FK_match_player_result_match_result_match_result_id" FOREIGN KEY (match_result_id) REFERENCES public.match_result(id) ON DELETE CASCADE;


--
-- Name: match_result FK_match_result_game_session_GameSessionId; Type: FK CONSTRAINT; Schema: public; Owner: game_app
--

ALTER TABLE ONLY public.match_result
    ADD CONSTRAINT "FK_match_result_game_session_GameSessionId" FOREIGN KEY ("GameSessionId") REFERENCES public.game_session(id);


--
-- Name: player_character FK_player_character_player_profile_player_id; Type: FK CONSTRAINT; Schema: public; Owner: game_app
--

ALTER TABLE ONLY public.player_character
    ADD CONSTRAINT "FK_player_character_player_profile_player_id" FOREIGN KEY (player_id) REFERENCES public.player_profile(player_id) ON DELETE CASCADE;


--
-- Name: player_identity FK_player_identity_account_account_id; Type: FK CONSTRAINT; Schema: public; Owner: game_app
--

ALTER TABLE ONLY public.player_identity
    ADD CONSTRAINT "FK_player_identity_account_account_id" FOREIGN KEY (account_id) REFERENCES public.account(id) ON DELETE CASCADE;


--
-- Name: player_identity FK_player_identity_player_profile_player_id; Type: FK CONSTRAINT; Schema: public; Owner: game_app
--

ALTER TABLE ONLY public.player_identity
    ADD CONSTRAINT "FK_player_identity_player_profile_player_id" FOREIGN KEY (player_id) REFERENCES public.player_profile(player_id) ON DELETE CASCADE;


--
-- Name: player_session FK_player_session_game_session_game_session_id; Type: FK CONSTRAINT; Schema: public; Owner: game_app
--

ALTER TABLE ONLY public.player_session
    ADD CONSTRAINT "FK_player_session_game_session_game_session_id" FOREIGN KEY (game_session_id) REFERENCES public.game_session(id) ON DELETE CASCADE;


--
-- Name: player_settings FK_player_settings_player_profile_player_id; Type: FK CONSTRAINT; Schema: public; Owner: game_app
--

ALTER TABLE ONLY public.player_settings
    ADD CONSTRAINT "FK_player_settings_player_profile_player_id" FOREIGN KEY (player_id) REFERENCES public.player_profile(player_id) ON DELETE CASCADE;


--
-- Name: player_statistics FK_player_statistics_player_profile_player_id; Type: FK CONSTRAINT; Schema: public; Owner: game_app
--

ALTER TABLE ONLY public.player_statistics
    ADD CONSTRAINT "FK_player_statistics_player_profile_player_id" FOREIGN KEY (player_id) REFERENCES public.player_profile(player_id) ON DELETE CASCADE;


--
-- Name: player_unlock FK_player_unlock_player_profile_player_id; Type: FK CONSTRAINT; Schema: public; Owner: game_app
--

ALTER TABLE ONLY public.player_unlock
    ADD CONSTRAINT "FK_player_unlock_player_profile_player_id" FOREIGN KEY (player_id) REFERENCES public.player_profile(player_id) ON DELETE CASCADE;


--
-- Name: refresh_token FK_refresh_token_account_account_id; Type: FK CONSTRAINT; Schema: public; Owner: game_app
--

ALTER TABLE ONLY public.refresh_token
    ADD CONSTRAINT "FK_refresh_token_account_account_id" FOREIGN KEY (account_id) REFERENCES public.account(id) ON DELETE CASCADE;


--
-- Name: session_event FK_session_event_game_session_game_session_id; Type: FK CONSTRAINT; Schema: public; Owner: game_app
--

ALTER TABLE ONLY public.session_event
    ADD CONSTRAINT "FK_session_event_game_session_game_session_id" FOREIGN KEY (game_session_id) REFERENCES public.game_session(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict h5a6lqTPO6VljiuTpIfJ0IkMjwm9nEXnk5CYNCNCgV56eVdqDDnz3CczCbSEqnw

